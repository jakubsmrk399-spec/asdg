# Credits

Map: This work is based on "de_dust2 - CS map" (https://sketchfab.com/3d-models/de-dust2-cs-map-056008d59eb849a29c0ab6884c0c3d87) by vrchris (https://sketchfab.com/vrchris) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)

Changes made to the original model: converted/re-centred for the game (`tools/build-map.js`), a stray floating box was removed, materials are rendered with a simple lit shader.

The author must stay credited wherever the game is shared (CC-BY-4.0). The credit is shown in the game on the join card, on the "click to play" card and as a small text in the corner while playing (`public/index.html`, `#creditcorner` / `.credit`); keep it there.

Characters: "Tm Phoenix V2 - csgo terrorist characters" by ErhanMatur (https://sketchfab.com/ErhanMatur) licensed under Creative Commons Attribution (CC-BY, https://creativecommons.org/licenses/by/4.0/). Replace the profile link with the exact model URL / the text of Sketchfab's "Copy credits" button if you want it more precise.

Changes made to the original model: converted FBX -> GLB by Sketchfab, then repacked for the game (`public/models/phoenix.glb`): only the 5 base colour textures kept, downscaled to 512 px JPEG, normal maps dropped (7.8 MB -> 1.1 MB). Geometry and skeleton are untouched. Pose and walk cycle are done in code (`public/index.html`, "CS:GO character model").

The credit is shown in the game on the join card, on the "click to play" card and in the bottom right corner (`#creditcorner`); keep it there.

Character "noob": "roblox Noob rig" by Modelsforgame (https://sketchfab.com/Modelsforgame) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/), source https://sketchfab.com/3d-models/roblox-noob-rig-95163fb22fb9432e8e364e79fa7fc2f6

Changes made to the original model: rebuilt as a joint hierarchy with the pivots at the neck, shoulders and hips (`tools/build-noob.py` -> `public/models/noob.glb`), turned 90 degrees to face +z, scaled to metres (1.8 m tall), and given two looping animation clips ("idle", "walk") with the right arm raised to hold the gun. Geometry, UVs and the texture are untouched.

The credit line (set in `public/models/characters.json`) appears in the bottom right corner of the game once a player with the noob model is in use; keep it there.

Character "ct_gign": "CT Gign" by davidthe19th (https://sketchfab.com/davidthe19th) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/), source https://sketchfab.com/3d-models/ct-gign-23826fc3da8847098263db13bc2a55c1

Changes made to the original model: repacked for the game (`tools/build-ct.py` -> `public/models/ct_gign.glb`): the materials used the KHR_materials_pbrSpecularGlossiness extension, which the game's three.js version no longer supports, so they were converted to plain base colour materials; only the two base colour textures were kept (the 1024 px body texture re-encoded as JPEG, specular-glossiness and normal maps dropped): 2.7 MB -> 0.5 MB. Geometry, skeleton and bind pose are untouched. Pose and walk cycle are done in code using the bone mapping in `public/models/characters.json`. The model is used for players named "CT", "GIGN", "counter terrorist", ... (see `players` in `characters.json`).

The credit line (set in `public/models/characters.json`) appears in the bottom right corner of the game once a player with this model is in use, and in the News page and on the join card; keep it there.

Weapon: "RIFLE | M4A1-S Weapon Model (CS2)" by 6lucius (https://sketchfab.com/6lucius) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/), source https://sketchfab.com/3d-models/rifle-m4a1-s-weapon-model-cs2-4ced85fd77e04b71ade5ab11cb28c529

Changes made to the original model: repacked for the game (`tools/build-m4a1.py` -> `public/models/m4a1-s.glb`): 7.7 MB -> 2.7 MB by keeping only the base colour texture (1024 px JPEG) and the position/normal/UV/skin data, 3 of the first-person animation clips kept (draw, reload, inspect), the mesh node moved to the scene root. Geometry, skeleton and bind pose are untouched. It is rotated/scaled/centred in code (`makeWeapon` in `public/index.html`) so the muzzle points forward. It replaces the box gun in first person and in the hands of other players.

The credit is shown in the game on the join card, on the "click to play" card and in the bottom right corner; keep it there.

Character "spongebob": "Spongebob Squarepants Fortnite (Cel)" by Guilherme Navarro (https://sketchfab.com/guinavarro.al) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/), source https://sketchfab.com/3d-models/spongebob-squarepants-fortnite-cel-e1023a183a124f89a17db304e72641e0

Changes made to the original model: none to the file (`public/models/spongebob.glb` is the downloaded GLB). Pose and walk cycle are done in code using the bone mapping in `public/models/characters.json`.

The credit line (set in `public/models/characters.json`) appears in the bottom right corner of the game once a player with the spongebob model is in use; keep it there.

Character "squidward": "Handsome Squidward" by Weasel On A Stick (https://sketchfab.com/woas) licensed under CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0/), source https://sketchfab.com/3d-models/handsome-squidward-5f1513ff8d8d4ee485cf7c4da6b75cb6

NOTE: this licence is NonCommercial. Do not use this game commercially (ads, paid access, sales) while this model is included; remove the "squidward" entries from `public/models/characters.json` first.

Changes made to the original model: none (`public/models/squidward.glb` is the downloaded GLB). The model has no skeleton, so the game just bobs and sways it while walking.

The credit line (set in `public/models/characters.json`) appears in the bottom right corner of the game once a player with the squidward model is in use; keep it there.

Character "patrick": "Realistic Patrick Star" by Malaya Yu (https://sketchfab.com/malayayu) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/), source https://sketchfab.com/3d-models/realistic-patrick-star-ac5fd3f65d594a2cabb4b0551c9e655c

Changes made to the original model: repacked for the game (`public/models/patrick.glb`): 5.3 MB -> 0.9 MB by keeping only the base colour texture (downscaled from 1024 px PNG to 512 px JPEG) and dropping the normal and metallic/roughness maps. Geometry is untouched. The model has no skeleton, so the game just bobs and sways it while walking.

The credit line (set in `public/models/characters.json`) appears in the bottom right corner of the game once a player with the patrick model is in use; keep it there.
