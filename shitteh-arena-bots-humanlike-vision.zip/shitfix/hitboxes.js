'use strict';
// Model-accurate hit shapes (server side, no dependencies).
//
// The old hit areas were two spheres (head + body) that were the same for every character, so a wide Patrick or a tiny Noob was hit
// where the sphere was, not where the model is. This module reads each character's .glb (the same file the clients draw), takes its
// rest-pose triangles and builds a stack of thin horizontal slices ("prisms"): every slice is the convex hull of the model's
// cross-section at that height. A bullet is tested against those prisms, so it hits exactly where the visible model is: between the
// legs is a miss, the gap beside the neck is a miss, a pointy Patrick head is only hit where it is. Slices that belong to the head
// (found through the head / neck bones or mesh names) give headshots.
//
// Placement mirrors the client (makeChar in public/index.html): the model is scaled so its bind-pose bounding box is playerHeight
// tall, its feet are on the floor, its origin stays on the player's x/z, and it is turned by PI unless "facing": "-z".
//
// Optional per-model settings in characters.json  ("hitbox": { ... }):
//   "arms":     "exclude" | "include"   models whose arms are posed in code (rigs without animation clips) are T-posed in the file, so
//                                       their arm triangles are left out by default; models with clips / no rig keep their arms.
//   "headFrom": 0.8                     treat everything above this fraction of the height as head (overrides the bone/mesh names)
//   "enabled":  false                   keep the old spheres for this model
//
// The result for a model is cached; it is rebuilt when the .glb or characters.json changes (checked at most once a second).

const fs = require('fs');
const path = require('path');

const SLABS = 32;            // horizontal slices over the model's height
const GAP = 0.012;           // (fraction of the height) x-gap that splits a slice into separate parts (the two legs)
const ARM_RE = /arm|hand|shoulder|clavicle|elbow|wrist|finger|thumb|index\d|middle\d|ring\d|pinky\d/i;   // mesh names of models without a skeleton
// skeleton families (same presets as the client): the arm starts at these bones and everything below them (forearm, hand, fingers) is arm
const ARM_ROOTS = [/^arm_upper_[RL](_\d+)?$/i, /^mixamorig\d*(Left|Right)Arm(_\d+)?$/i];
const ARM_ROOT_FALLBACK = /(^|_)(upperarm|upper_arm|arm_upper|arm)(_|\d|$)/i;
const HEAD_RE = /head|neck|jaw|face|skull|brow|eye|lip|nose|cheek|hair|teeth|tongue|mouth/i;
const C_BODY = 0, C_ARM = 1, C_HEAD = 2;

// ---- tiny 4x4 matrix helpers (column major, like glTF) ----
function m4mul(a, b) {
  const o = new Array(16).fill(0);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; }
  return o;
}
function fromTRS(t, q, s) {
  const [x, y, z, w] = q, [sx, sy, sz] = s;
  const x2 = x + x, y2 = y + y, z2 = z + z, xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
  return [(1 - (yy + zz)) * sx, (xy + wz) * sx, (xz - wy) * sx, 0, (xy - wz) * sy, (1 - (xx + zz)) * sy, (yz + wx) * sy, 0,
    (xz + wy) * sz, (yz - wx) * sz, (1 - (xx + yy)) * sz, 0, t[0], t[1], t[2], 1];
}
const sanitize = (n) => String(n || '').replace(/\s/g, '_').replace(/[\[\]\.:\/]/g, '');   // what three.js GLTFLoader does to node names

// ---- GLB: rest-pose world-space triangles, each vertex tagged by what it belongs to ----
function readGlb(file, def) {
  const buf = fs.readFileSync(file);
  if (buf.readUInt32LE(0) !== 0x46546c67) throw new Error('not a .glb');
  const jl = buf.readUInt32LE(12);
  const j = JSON.parse(buf.slice(20, 20 + jl).toString('utf8'));
  const bin = buf.slice(20 + jl + 8);
  const used = j.extensionsUsed || [];
  if (used.includes('KHR_draco_mesh_compression') || used.includes('EXT_meshopt_compression')) throw new Error('compressed meshes are not supported');
  const dv = new DataView(bin.buffer, bin.byteOffset, bin.byteLength);
  const CT = { 5120: [1, 'getInt8', 127], 5121: [1, 'getUint8', 255], 5122: [2, 'getInt16', 32767], 5123: [2, 'getUint16', 65535], 5125: [4, 'getUint32', 1], 5126: [4, 'getFloat32', 1] };
  const NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
  const readAcc = (i) => {
    const a = j.accessors[i], n = NC[a.type], [sz, fn, norm] = CT[a.componentType];
    const out = new Float64Array(a.count * n);
    if (a.bufferView == null) return { data: out, n, count: a.count };
    const bv = j.bufferViews[a.bufferView], stride = bv.byteStride || n * sz, base = (bv.byteOffset || 0) + (a.byteOffset || 0);
    for (let e = 0; e < a.count; e++) for (let k = 0; k < n; k++) {
      let v = dv[fn](base + e * stride + k * sz, true);
      if (a.normalized) v = Math.max(v / norm, -1);
      out[e * n + k] = v;
    }
    return { data: out, n, count: a.count };
  };

  const nodes = j.nodes || [];
  const parent = new Array(nodes.length).fill(-1);
  nodes.forEach((nd, i) => (nd.children || []).forEach((c) => { parent[c] = i; }));
  const local = nodes.map((nd) => nd.matrix ? nd.matrix.slice() : fromTRS(nd.translation || [0, 0, 0], nd.rotation || [0, 0, 0, 1], nd.scale || [1, 1, 1]));
  const world = new Array(nodes.length);
  const gw = (i) => world[i] || (world[i] = parent[i] < 0 ? local[i] : m4mul(gw(parent[i]), local[i]));
  nodes.forEach((_, i) => gw(i));
  const names = nodes.map((nd) => sanitize(nd.name));

  // arm joints: the roots named in characters.json ("bones": armUpR / armUpL), else a known skeleton family, else a name guess, plus all their children
  const armRoots = new Set();
  const given = def && def.bones ? [def.bones.armUpR, def.bones.armUpL].filter(Boolean).map(sanitize) : [];
  const jointNodes = new Set();
  for (const sk of j.skins || []) for (const n of sk.joints) jointNodes.add(n);
  if (given.length) jointNodes.forEach((n) => { if (given.includes(names[n])) armRoots.add(n); });
  if (!armRoots.size) for (const re of ARM_ROOTS) { jointNodes.forEach((n) => { if (re.test(names[n])) armRoots.add(n); }); if (armRoots.size) break; }
  if (!armRoots.size) jointNodes.forEach((n) => { if (ARM_ROOT_FALLBACK.test(names[n])) armRoots.add(n); });
  const armNode = new Set();
  const mark = (n) => { if (armNode.has(n)) return; armNode.add(n); (nodes[n].children || []).forEach(mark); };
  armRoots.forEach(mark);

  const pos = [], cls = [], idx = [];
  let skinned = false;
  nodes.forEach((nd, ni) => {
    if (nd.mesh == null) return;
    const W = world[ni];
    const skin = nd.skin != null ? j.skins[nd.skin] : null;
    for (const pr of j.meshes[nd.mesh].primitives) {
      if (pr.mode != null && pr.mode !== 4) continue;
      if (pr.attributes.POSITION == null) continue;
      const P = readAcc(pr.attributes.POSITION);
      let J = null, WT = null, IBM = null;
      if (skin && pr.attributes.JOINTS_0 != null && pr.attributes.WEIGHTS_0 != null && skin.inverseBindMatrices != null) {
        J = readAcc(pr.attributes.JOINTS_0); WT = readAcc(pr.attributes.WEIGHTS_0); IBM = readAcc(skin.inverseBindMatrices); skinned = true;
      }
      const joint = J ? skin.joints.map((n, k) => m4mul(world[n], Array.from(IBM.data.slice(k * 16, k * 16 + 16)))) : null;
      const base = pos.length / 3;
      for (let v = 0; v < P.count; v++) {
        let x = P.data[v * 3], y = P.data[v * 3 + 1], z = P.data[v * 3 + 2], c = C_BODY;
        if (J) {   // skinned: glTF spec, mesh node transform ignored; at rest pose this is the bind pose the game draws
          let sx = 0, sy = 0, sz = 0, arm = 0, head = 0, tot = 0;
          for (let k = 0; k < 4; k++) {
            const w = WT.data[v * 4 + k]; if (!(w > 0)) continue;
            const ji = J.data[v * 4 + k], M = joint[ji], bn = names[skin.joints[ji]];
            sx += w * (M[0] * x + M[4] * y + M[8] * z + M[12]); sy += w * (M[1] * x + M[5] * y + M[9] * z + M[13]); sz += w * (M[2] * x + M[6] * y + M[10] * z + M[14]);
            tot += w;
            if (armNode.has(skin.joints[ji])) arm += w; else if (HEAD_RE.test(bn)) head += w;
          }
          x = sx; y = sy; z = sz;
          if (arm > 0.5 * tot) c = C_ARM; else if (head > 0.5 * tot) c = C_HEAD;
        } else {
          const X = W[0] * x + W[4] * y + W[8] * z + W[12], Y = W[1] * x + W[5] * y + W[9] * z + W[13], Z = W[2] * x + W[6] * y + W[10] * z + W[14];
          x = X; y = Y; z = Z;
          const mn = names[ni];
          c = ARM_RE.test(mn) ? C_ARM : (HEAD_RE.test(mn) ? C_HEAD : C_BODY);
        }
        pos.push(x, y, z); cls.push(c);
      }
      if (pr.indices != null) { const I = readAcc(pr.indices).data; for (let i = 0; i + 2 < I.length; i += 3) idx.push(base + I[i], base + I[i + 1], base + I[i + 2]); }
      else for (let i = 0; i + 2 < P.count; i += 3) idx.push(base + i, base + i + 1, base + i + 2);
    }
  });
  return { pos, cls, idx, skinned, hasClips: (j.animations || []).length > 0 };
}

// ---- 2D convex hull (monotone chain), counter-clockwise in (x, z) ----
function hull(pts) {   // pts: [[x, z], ...]
  const seen = new Set(), p = [];
  for (const q of pts) { const k = Math.round(q[0] * 1e5) + ',' + Math.round(q[1] * 1e5); if (!seen.has(k)) { seen.add(k); p.push(q); } }
  if (p.length < 3) return null;
  p.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo = [];
  for (const q of p) { while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); }
  const up = [];
  for (let i = p.length - 1; i >= 0; i--) { const q = p[i]; while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
  lo.pop(); up.pop();
  const h = lo.concat(up);
  return h.length >= 3 ? h : null;
}
function polyArea(h) { let a = 0; for (let i = 0; i < h.length; i++) { const p = h[i], q = h[(i + 1) % h.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; }
function polyCentroid(h) {
  let a = 0, cx = 0, cz = 0;
  for (let i = 0; i < h.length; i++) { const p = h[i], q = h[(i + 1) % h.length], f = p[0] * q[1] - q[0] * p[1]; a += f; cx += (p[0] + q[0]) * f; cz += (p[1] + q[1]) * f; }
  return a ? [cx / (3 * a), cz / (3 * a)] : [h[0][0], h[0][1]];
}
function inHull(h, x, z) { for (let i = 0; i < h.length; i++) { const p = h[i], q = h[(i + 1) % h.length]; if ((q[0] - p[0]) * (z - p[1]) - (q[1] - p[1]) * (x - p[0]) < 0) return false; } return true; }

// clip the triangle to the band ya <= y <= yb and return the (x, z) of the polygon that is left
function clipBand(t, ya, yb) {
  let poly = t;
  for (const [sign, lim] of [[1, ya], [-1, yb]]) {
    const out = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length];
      const da = sign * (a[1] - lim), db = sign * (b[1] - lim);
      if (da >= 0) out.push(a);
      if ((da >= 0) !== (db >= 0)) { const u = da / (da - db); out.push([a[0] + (b[0] - a[0]) * u, lim, a[2] + (b[2] - a[2]) * u]); }
    }
    poly = out;
    if (!poly.length) return null;
  }
  return poly;
}

// ---- build the hit shape of one model ----
// def = the model's entry in characters.json. Result is in "model units": 1 = the player's height, feet at y = 0, x/z already turned into
// the player's frame (forward = -z), so the server only has to scale by the player height and rotate by the player's yaw.
function build(file, def) {
  const g = readGlb(file, def);
  const n = g.pos.length / 3;
  let minY = Infinity, maxY = -Infinity;
  for (let i = 0; i < n; i++) { const y = g.pos[i * 3 + 1]; if (y < minY) minY = y; if (y > maxY) maxY = y; }
  const H = Number(def.height) > 0 ? Number(def.height) : maxY - minY;   // same height the client scales by
  if (!(H > 0) || !Number.isFinite(H)) throw new Error('model has no height');
  const hb = def.hitbox || {};
  const turn = def.facing === '-z' ? 1 : -1;                              // the client turns models that face +z by PI
  const procedural = g.skinned && !g.hasClips && def.rig !== 'none';     // arms are posed in code, the file's T-pose arms are not what is drawn
  const dropArms = hb.arms ? hb.arms === 'exclude' : procedural;

  const X = (i) => turn * g.pos[i * 3] / H, Y = (i) => (g.pos[i * 3 + 1] - minY) / H, Z = (i) => turn * g.pos[i * 3 + 2] / H;
  const tris = [];   // [cls, [[x, y, z] x3]]
  for (let t = 0; t + 2 < g.idx.length; t += 3) {
    const a = g.idx[t], b = g.idx[t + 1], c = g.idx[t + 2];
    let arm = 0, head = 0;
    for (const v of [a, b, c]) { if (g.cls[v] === C_ARM) arm++; else if (g.cls[v] === C_HEAD) head++; }
    let k = arm >= 2 ? C_ARM : (head >= 2 ? C_HEAD : C_BODY);
    if (k === C_ARM && !dropArms) k = C_BODY;
    if (k === C_ARM) continue;
    tris.push([k, [[X(a), Y(a), Z(a)], [X(b), Y(b), Z(b)], [X(c), Y(c), Z(c)]]]);
  }
  if (!tris.length) throw new Error('model has no triangles');

  // the head zone: everything above a height. The head/neck bones (or mesh names) say where the head starts, but cartoon characters
  // (SpongeBob's face is only part of his sponge) make that unreliable, so it is kept between 62% and 90% of the height.
  // "hitbox": { "headFrom": 0.8 } in characters.json sets it by hand.
  const cy = (t) => (t[1][0][1] + t[1][1][1] + t[1][2][1]) / 3;
  let headFrom = Number(hb.headFrom) > 0 ? Number(hb.headFrom) : 0;
  if (!headFrom) {
    const hy = tris.filter((t) => t[0] === C_HEAD).map(cy).sort((p, q) => p - q);
    headFrom = hy.length < 10 ? 0.86 : Math.min(0.9, Math.max(0.62, hy[Math.floor(hy.length * 0.05)]));
  }
  for (const t of tris) t[0] = cy(t) >= headFrom ? C_HEAD : C_BODY;

  // horizontal slices: the convex hull of everything inside each slice (split where there is a gap, e.g. between the legs)
  const prisms = [];
  const dy = 1 / SLABS;
  const buckets = Array.from({ length: SLABS }, () => [[], []]);   // [body entries, head entries]
  for (const [k, tri] of tris) {
    let lo = Infinity, hi = -Infinity;
    for (const p of tri) { if (p[1] < lo) lo = p[1]; if (p[1] > hi) hi = p[1]; }
    for (let s = Math.max(0, Math.floor(lo / dy)); s <= Math.min(SLABS - 1, Math.floor(hi / dy)); s++) {
      const poly = clipBand(tri, s * dy, (s + 1) * dy);
      if (!poly) continue;
      let x0 = Infinity, x1 = -Infinity;
      const pts = poly.map((p) => { if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0]; return [p[0], p[2]]; });
      buckets[s][k === C_HEAD ? 1 : 0].push({ x0, x1, pts });
    }
  }
  for (let s = 0; s < SLABS; s++) for (const kind of [0, 1]) {
    const list = buckets[s][kind].sort((p, q) => p.x0 - q.x0);
    const groups = [];
    for (const e of list) {
      const last = groups[groups.length - 1];
      if (last && e.x0 <= last.x1 + GAP) { last.x1 = Math.max(last.x1, e.x1); last.pts.push(...e.pts); }
      else groups.push({ x1: e.x1, pts: e.pts.slice() });
    }
    for (const gp of groups) {
      const h = hull(gp.pts);
      if (!h || polyArea(h) < 1e-6) continue;
      prisms.push({ y0: s * dy, y1: (s + 1) * dy, head: kind, pts: h });
    }
  }
  if (!prisms.length) throw new Error('no hit shape could be built');

  // overall bounds and aim points (assist / aimbot): volume weighted centres of the head and of the body
  let bx0 = Infinity, bx1 = -Infinity, bz0 = Infinity, bz1 = -Infinity, by1 = 0;
  const cen = [{ w: 0, x: 0, y: 0, z: 0 }, { w: 0, x: 0, y: 0, z: 0 }];
  for (const p of prisms) {
    const a = polyArea(p.pts) * (p.y1 - p.y0), c = polyCentroid(p.pts), acc = cen[p.head];
    acc.w += a; acc.x += a * c[0]; acc.y += a * (p.y0 + p.y1) / 2; acc.z += a * c[1];
    for (const q of p.pts) { if (q[0] < bx0) bx0 = q[0]; if (q[0] > bx1) bx1 = q[0]; if (q[1] < bz0) bz0 = q[1]; if (q[1] > bz1) bz1 = q[1]; }
    if (p.y1 > by1) by1 = p.y1;
  }
  const inside = (pt) => prisms.some((p) => pt[1] >= p.y0 && pt[1] <= p.y1 && inHull(p.pts, pt[0], pt[2]));
  const aim = (acc, fallback) => {
    if (acc.w <= 0) return fallback;
    const pt = [acc.x / acc.w, acc.y / acc.w, acc.z / acc.w];
    return inside(pt) ? pt : fallback;
  };
  const centreOf = (p) => { const c = polyCentroid(p.pts); return [c[0], (p.y0 + p.y1) / 2, c[1]]; };
  // body aim point: the volume centre of the torso zone (25%..75% of the height), or the middle of its biggest slice
  let tw = 0, tx = 0, ty = 0, tz = 0, biggest = null, bigA = -1;
  for (const p of prisms) {
    if (p.head || p.y1 < 0.25 || p.y0 > 0.75) continue;
    const a = polyArea(p.pts), c = polyCentroid(p.pts), v = a * (p.y1 - p.y0);
    tw += v; tx += v * c[0]; ty += v * (p.y0 + p.y1) / 2; tz += v * c[1];
    if (a > bigA) { bigA = a; biggest = p; }
  }
  const anyBody = prisms.find((p) => !p.head) || prisms[0];
  const bodyFallback = centreOf(biggest || anyBody);
  const bodyAim = tw > 0 && inside([tx / tw, ty / tw, tz / tw]) ? [tx / tw, ty / tw, tz / tw] : bodyFallback;
  let headBig = null, headA = -1;
  for (const p of prisms) if (p.head) { const a = polyArea(p.pts); if (a > headA) { headA = a; headBig = p; } }
  const headFallback = centreOf(headBig || anyBody);
  const headAim = aim(cen[1], headFallback);
  return {
    prisms,
    bbox: [bx0, bx1, 0, by1, bz0, bz1],
    headAim,
    bodyAim,
    info: { height: H, procedural, droppedArms: dropArms, headFrom: headFrom || null, prisms: prisms.length, headPrisms: prisms.filter((p) => p.head).length },
  };
}

// ---- ray test (model space; the caller scales / rotates the ray into the player's frame) ----
// o, d: origin and (not necessarily unit) direction in model space. Returns the entry parameter t (>= 0) and whether it was the head.
function rayModel(hb, ox, oy, oz, dx, dy, dz, maxT) {
  // quick reject: ray vs the overall bounding box
  const B = hb.bbox;
  let t0 = 0, t1 = maxT;
  const o3 = [ox, oy, oz], d3 = [dx, dy, dz];
  for (let a = 0; a < 3; a++) {
    const lo = B[a * 2], hi = B[a * 2 + 1];
    if (Math.abs(d3[a]) < 1e-12) { if (o3[a] < lo || o3[a] > hi) return null; continue; }
    let u = (lo - o3[a]) / d3[a], v = (hi - o3[a]) / d3[a];
    if (u > v) { const tmp = u; u = v; v = tmp; }
    if (u > t0) t0 = u; if (v < t1) t1 = v;
    if (t0 > t1) return null;
  }
  let best = Infinity, head = false;
  for (const p of hb.prisms) {
    let lo = 0, hi = Math.min(maxT, best);
    if (Math.abs(dy) < 1e-12) { if (oy < p.y0 || oy > p.y1) continue; }
    else { let u = (p.y0 - oy) / dy, v = (p.y1 - oy) / dy; if (u > v) { const tmp = u; u = v; v = tmp; } if (u > lo) lo = u; if (v < hi) hi = v; }
    if (lo > hi) continue;
    const h = p.pts;
    let ok = true;
    for (let i = 0; i < h.length && ok; i++) {
      const a = h[i], b = h[(i + 1) % h.length];
      const ex = b[0] - a[0], ez = b[1] - a[1];
      const A = ex * (oz - a[1]) - ez * (ox - a[0]);   // inside: A + B t >= 0
      const Bt = ex * dz - ez * dx;
      if (Math.abs(Bt) < 1e-12) { if (A < 0) ok = false; continue; }
      const t = -A / Bt;
      if (Bt > 0) { if (t > lo) lo = t; } else if (t < hi) hi = t;
      if (lo > hi) ok = false;
    }
    if (!ok || lo > hi) continue;
    if (lo < best) { best = lo; head = !!p.head; }
  }
  return best === Infinity ? null : { t: best, head };
}

// ---- registry: which model does a player have, and its (cached) hit shape ----
function create(opts) {
  const dir = path.join(opts.publicDir, 'models');
  const cfgFile = path.join(dir, 'characters.json');
  const log = opts.log || (() => {});
  let cfg = { default: null, models: {}, players: {} };
  let cfgMtime = -1, lastCheck = 0;
  const players = new Map();   // normalised name -> model id
  const cache = new Map();     // model id -> { key, hb | null }
  const key = (nm) => String(nm == null ? '' : nm).trim().replace(/\s+/g, ' ').toLowerCase();   // same as charKey() in public/index.html

  function reload() {
    const now = Date.now();
    if (now - lastCheck < 1000) return;
    lastCheck = now;
    let st;
    try { st = fs.statSync(cfgFile); } catch { return; }
    if (st.mtimeMs === cfgMtime) return;
    cfgMtime = st.mtimeMs;
    try {
      const c = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
      cfg = { default: c.default || null, models: c.models || {}, players: c.players || {} };
      players.clear();
      for (const [nm, id] of Object.entries(cfg.players)) players.set(key(nm), id);
    } catch (e) { log(`[hitbox] characters.json not readable (${e.message}); keeping the previous list`); }
  }
  function modelId(name) {
    reload();
    const id = players.get(key(name));
    return id && cfg.models[id] ? id : cfg.default;
  }
  function shape(id) {
    const def = id && cfg.models[id];
    if (!def || !def.file || (def.hitbox && def.hitbox.enabled === false)) return null;
    const file = path.join(dir, def.file);
    let stamp;
    try { stamp = fs.statSync(file).mtimeMs + ':' + JSON.stringify(def); } catch { return null; }
    const c = cache.get(id);
    if (c && c.key === stamp) return c.hb;
    let hb = null;
    try {
      hb = build(file, def);
      const i = hb.info;
      log(`[hitbox] ${id}: ${i.prisms} slices (${i.headPrisms} head)${i.droppedArms ? ', arms left out (posed in code)' : ''}${i.headFrom ? `, head = top ${Math.round((1 - i.headFrom) * 100)}%` : ''}`);
    } catch (e) { log(`[hitbox] ${id}: ${e.message}; using the simple spheres for this model`); }
    cache.set(id, { key: stamp, hb });
    return hb;
  }
  return {
    forName: (name) => shape(modelId(name)),
    modelId,
    preload() { reload(); for (const id of Object.keys(cfg.models)) shape(id); },
  };
}

module.exports = { create, build, rayModel, readGlb };
