'use strict';
// Candidate spawn points [x,z] for both supported maps. server.js verifies each against the active collision mesh.
const NEON_T_SPAWNS = [[-6,-10],[-3,-10],[0,-10],[3,-10],[6,-10],[-6,-5],[-3,-5],[3,-5],[6,-5]];
const NEON_CT_SPAWNS = [[-6,10],[-3,10],[0,10],[3,10],[6,10],[-6,5],[-3,5],[3,5],[6,5]];
// Dust 2: verified open-floor points on the T and CT sides of the original map.
const DUST2_T_SPAWNS = [[-17,23],[-13,23],[-17,26],[-13,26],[-21,25],[-19,21],[-11,22],[-15,21]];
const DUST2_CT_SPAWNS = [[19,-24],[22,-24],[24,-24],[19,-21],[22,-21],[24,-21],[19,-19],[22,-19],[24,-19],[20,-23]];
const NEON_SITES = [];
const DUST2_SITES = [['A',19.7,-17.2,1.2],['B',-17.4,-20.9,1.2]];
const ARENA = 40;
const FLAT_SPAWNS = [[-20,-20],[20,-20],[-20,20],[20,20],[0,-25],[0,25],[-25,0],[25,0]];
module.exports = { NEON_T_SPAWNS, NEON_CT_SPAWNS, DUST2_T_SPAWNS, DUST2_CT_SPAWNS, NEON_SITES, DUST2_SITES, ARENA, FLAT_SPAWNS };
