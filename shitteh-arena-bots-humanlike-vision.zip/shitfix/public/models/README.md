# Character models

Everything is set in **`characters.json`** (this folder). Reload the game page after changing it; the server does not need a restart.

```json
{
  "default": "phoenix",
  "models": {
    "phoenix": { "file": "phoenix.glb" },
    "noob":    { "file": "my-noob.glb", "credit": "Model: \"Noob\" by Someone (CC-BY)" }
  },
  "players": {
    "NOOB": "noob",
    "Some Friend": "phoenix"
  }
}
```

* `players`: **player name -> model id**. Names are matched without caring about capital letters or extra spaces. Everyone who is not listed gets `default`. To change the name that triggers a model, just edit the key (`"NOOB"`).
* `models`: model id -> settings. Only `file` is needed; put the `.glb` in this folder.
* A model is only downloaded when the first player that uses it appears. If a model fails to load, that player gets the default model; if even that fails, a capsule.

## Adding a model

1. Get a **.glb** (Sketchfab: Download -> glTF / GLB). Keep it small: it is sent to every player. Under ~3 MB is good; 512 px textures are plenty.
2. Put it in `public/models/`.
3. Run `node tools/inspect-glb.js public/models/yourmodel.glb`. (If the file REQUIRES `KHR_materials_pbrSpecularGlossiness` it would come out untextured: repack it first, `tools/build-ct.py` does that.) It lists the animation clips and bones, tells you how the game will animate it, prints the embedded credit and a suggested `models` entry.
4. Add the entry to `models`, then add `"Player Name": "yourid"` to `players`.
5. If the model is CC-BY (most Sketchfab ones), put the credit in `CREDITS.md` and add `"credit": "..."` to the entry: that line is shown bottom right in the game once the model is used.

## How a model is animated (automatic)

| The file has | What the game does |
|---|---|
| animation clips | plays an idle clip when standing and a walk/run clip when moving (clips are found by name: idle/stand/breath, walk, run/jog). Use "in place" clips (no root motion). |
| a skeleton, no clips | holds the (box) gun in both hands and swings legs in code. Works for **valve** (CS:GO) skeletons and **mixamo** skeletons out of the box. |
| no skeleton | stands there and bobs/sways while walking. |

## Settings per model (all optional)

| key | meaning |
|---|---|
| `file` | the .glb in this folder (required) |
| `rig` | `"auto"` (default), `"clips"`, `"valve"`, `"mixamo"`, `"custom"` or `"none"` (force no animation) |
| `bones` | for a skeleton the game does not recognise: `{ "armUpR": "bone name", "armLoR": ..., "handR": ..., "legUpR": ..., "legLoR": ..., "footR": ..., "toeR": ... }` and the same with `L`. Right/Left = the character's own right/left. Use the names printed by `inspect-glb.js`. All 14 are needed. |
| `anims` | `{ "idle": "clip name", "walk": "clip name" }` if the automatic choice is wrong |
| `walkSpeed` | metres/second at which the walk clip plays at normal speed (default 3.5) |
| `facing` | `"-z"` if the model looks the wrong way (default `"+z"`) |
| `height` | model height in the file's own units; normally measured automatically |
| `gun` | `[x, y, z]` position of the box gun in metres (x right, y up, z negative = forward), or `false` for no gun. Default: between the hands, or the old spot for models without a skeleton |
| `material` | `"keep"` to keep the file's own (PBR) materials. Default: simple lit materials like the map |
| `fpArms` | colours of YOUR arms in first person for models without `Arm_R` / `Arm_L` parts: `{ "sleeve": "#3a3d33", "hand": "#c49a74" }`. A model that has meshes named `Arm_R` and `Arm_L` (like the noob) uses those instead |
| `credit` | text added to the bottom-right credit corner once the model is used |

The player's size setting (`playerHeight` in `config.json`) still scales every model. Movement is the same for everybody, but **hit areas follow the model**: the server reads the same `.glb` and shoots against slices of its real shape (see "Hit areas" below).

## Hit areas

`hitboxes.js` (next to `server.js`) builds the hit shape of each character from its `.glb` the first time it is needed: 32 horizontal slices, each the outline of the model at that height. A bullet hits where the visible model is: the gap between the legs, the air beside the neck and the space above the head are misses. The upper part of the model (the head/neck bones tell where it starts, kept between 62% and 90% of the height) is the head: a headshot. The shape follows the player's yaw and crouch, and the aimbot / aim assist aim at the middle of the model's head or body. It is rebuilt when the `.glb` or `characters.json` changes. Check what a bullet would hit with `node tools/test-hitboxes.js [modelId]`.

Models whose arms are posed in code (a skeleton without animation clips) are stored in a T-pose, which is not what is drawn, so their arms are left out of the hit shape; models with clips or without a skeleton keep their arms. Optional per-model settings:

| key | meaning |
|---|---|
| `hitbox.arms` | `"include"` or `"exclude"` to override the arm rule above |
| `hitbox.headFrom` | height (0-1, fraction of the model) above which a hit counts as a headshot, e.g. `0.8` |
| `hitbox.enabled` | `false` keeps the old head + body spheres for this model |

The old spheres for everybody: `HITBOXES=spheres` (env) or `"hitboxes": "spheres"` in `config.json`.

Models are expected to face **+z** with the character's right side at **-x** (the glTF/Sketchfab standard). Pose and bone-direction maths assume that.
