/*
 * Shared triangle-mesh collision + movement for Shitteh Arena (client AND server).
 * Plain JS, no dependencies. UMD: `require('./public/shared/collision.js')` under Node,
 * `window.Collision` in the browser (load with a classic <script src="/shared/collision.js">).
 *
 * Data: the contents of public/maps/dust2.collision.json  { verts:[x,y,z,...], tris:[i,j,k,...] }
 * in GAME coordinates (Y up, 1 unit = 1 m).
 *
 * API
 *   const C = Collision;                    // constants: C.R, C.HEIGHT, C.STEP, C.SPEED, C.GRAV, C.JUMP, C.MIN_Y ...
 *   const col = Collision.create(data);     // builds the spatial index (~10 ms)
 *   col.bounds                              // {minx,maxx,minz,maxz,miny,maxy} of the mesh
 *
 *   col.floorY(x, z, y, stepUp)  -> highest floor surface at (x,z) that is <= y + stepUp, or -Infinity if none.
 *                                   (Picks the floor BELOW the feet, so stacked floors in tunnels work.)
 *   col.ceilY(x, z, from, to)    -> lowest flat surface at (x,z) with from <= h <= to, or Infinity if none.
 *   col.moveXZ(x, y, z, nx, nz, out) -> slides the player circle (radius R) from (x,z) to the wanted (nx,nz),
 *                                   pushing it out of every wall triangle that overlaps the body band
 *                                   [y+STEP, y+HEIGHT]. Writes out.x, out.z, out.hit (true if a wall touched it).
 *                                   Intended for steps <= ~0.2 m (step() and sweepXZ() do the sub-stepping).
 *   col.penetration(x, y, z)     -> deepest wall penetration (metres) of a circle at (x,y,z); 0 = free.
 *   col.isSolid(x, y, z)         -> penetration(x,y,z) > 0.02
 *   col.sweepXZ(x0,z0,y0, x1,z1,y1, out) -> moves along the straight chord in <=0.15 m sub-steps with sliding.
 *                                   out.x,out.z = where it ended, out.hit = a wall was touched on the way.
 *   col.step(s, dt, mx, mz, jump) -> the player mover, used by the CLIENT every frame. s = {x,y,z,vy,ground}
 *                                   is changed in place. (mx,mz) = wish direction, length <= 1 (times C.SPEED).
 *                                   Does sub-stepping, wall sliding, auto step-up (<= STEP), slopes, falling with GRAV,
 *                                   jumping with JUMP (apex ~1.33 m), head bumps on ceilings, a safety floor at MIN_Y,
 *                                   and keeps the player inside the mesh bounds. Sets s.lost = true if the player fell out
 *                                   of the world (reached MIN_Y with no floor); the caller then waits for / forces a respawn.
 *   col.validatePose(st, cx, cy, cz, dt, out) -> SERVER side check of a claimed pose. st = {x,y,z,gy,air} is the last
 *                                   accepted state (gy / air are bookkeeping fields this function maintains).
 *                                   Writes the accepted pose to out.x/y/z, out.corrected = it differs from the claim,
 *                                   out.lost = fell out of the world (no floor, at MIN_Y) -> the server should respawn the player.
 *                                   Sweeps from the last accepted position to the claim (so walls cannot be crossed),
 *                                   accepts the claim if it is within TOL of that swept result, limits upward speed and
 *                                   hover height, and keeps y between the floor below and a jump above it.
 *
 *   col.raycast(ox,oy,oz, dx,dy,dz, maxT) -> distance t (0 <= t <= maxT) to the NEAREST triangle hit along the ray, or
 *                                   Infinity if nothing is hit within maxT. (dx,dy,dz) must be normalized. EVERY triangle
 *                                   blocks (flat and steep, both sides: winding ignored). Grid DDA + Moller-Trumbore.
 *   col.visible(ax,ay,az, bx,by,bz) -> true when nothing blocks the straight line a -> b (stops 2 cm short of b).
 *
 * Triangle classes: |ny| > FLOOR_NY (0.6) = flat surface (floor for the feet, ceiling for the head; winding is ignored
 * because the mesh is double sided), everything steeper = wall. Walls lower than y+STEP do not block (that is the
 * auto step-up); walls whose bottom is above y+HEIGHT do not block either.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Collision = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const K = {
    R: 0.2,            // player radius        (== PLAYER_R / R in server.js / index.html)
    EYE: 1.6,          // eye height           (== EYE)
    SPEED: 5.5,        // walking speed m/s    (== SPEED)
    GRAV: 24,          // client gravity       (== GRAV)
    JUMP: 8,           // client jump speed    (== JUMP)
    HEIGHT: 1.8,       // body height
    STEP: 0.5,         // auto step-up / step-down height
    ROOF: 3.2,         // "roof line": nothing above this height can be stood on, and walls that reach above it count as infinitely
                       // tall, so nobody can climb onto wall tops / roofs / the outside of the map. The real floors top out at ~3.0.
    MIN_Y: -3,         // safety floor (the mesh bottom is about -2.56)
    FLOOR_NY: 0.6,     // |normal.y| above this = flat surface (walkable up to ~53 degrees)
    MAXSTEP: 0.15,     // max horizontal distance per collision sub-step
    TOL: 0.35,         // server: accept a claim this close to the swept result (must stay < 2*R)
    CELL: 2,           // grid cell size
    UNSTICK: 0.19,     // max distance step() may nudge a wedged player to a free spot. MUST stay < R (0.2): a move shorter
                       // than R cannot cross a thin wall, so the server's swept path (validatePose) always agrees with it
    PEN_OK: 0.12,      // server: a claim may overlap a wall by this much (client/server path differences)
    SWEEP_CAP: 40,     // server: max sub-steps of one validated move
    STEP_CAP: 16,      // client: max sub-steps of one frame
    PEN_WEDGE: 0.05,   // overlap above this = wedged in a corner / slot (shrinks with R when R < 0.1, see configure)
    PEN_FREE: 0.02,    // overlap below this = free (a spot you may be nudged to; isSolid threshold)
  };
  K.JUMP_H = (K.JUMP * K.JUMP) / (2 * K.GRAV); // 1.333 m
  const EPS_EDGE = 0.003; // floor triangle edge tolerance (hides cracks between triangles)

  function create(data) {
    const verts = data.verts, tris = data.tris;
    const nT = (tris.length / 3) | 0;
    const kind = new Uint8Array(nT);          // 0 skip, 1 flat, 2 wall
    const P = new Float64Array(nT * 6);       // xz of the 3 corners: ax,az,bx,bz,cx,cz
    const H = new Float64Array(nT * 3);       // y of the 3 corners
    const minY = new Float64Array(nT), maxY = new Float64Array(nT);
    const wTop = new Float64Array(nT);        // top of a wall for blocking: infinite when the wall reaches above the roof line
    const fnx = new Float64Array(nT), fnz = new Float64Array(nT); // flat: height = ay - (fnx*(x-ax)+fnz*(z-az))
    const tminx = new Float64Array(nT), tmaxx = new Float64Array(nT), tminz = new Float64Array(nT), tmaxz = new Float64Array(nT);

    let bminx = Infinity, bmaxx = -Infinity, bminz = Infinity, bmaxz = -Infinity, bminy = Infinity, bmaxy = -Infinity;
    for (let i = 0; i < verts.length; i += 3) {
      const x = verts[i], y = verts[i + 1], z = verts[i + 2];
      if (x < bminx) bminx = x; if (x > bmaxx) bmaxx = x;
      if (y < bminy) bminy = y; if (y > bmaxy) bmaxy = y;
      if (z < bminz) bminz = z; if (z > bmaxz) bmaxz = z;
    }
    const gx0 = bminx - 1, gz0 = bminz - 1;
    const gw = Math.max(1, Math.ceil((bmaxx + 1 - gx0) / K.CELL)), gh = Math.max(1, Math.ceil((bmaxz + 1 - gz0) / K.CELL));
    const fcells = new Array(gw * gh), wcells = new Array(gw * gh);
    for (let i = 0; i < gw * gh; i++) { fcells[i] = []; wcells[i] = []; }

    for (let t = 0; t < nT; t++) {
      const a = tris[t * 3] * 3, b = tris[t * 3 + 1] * 3, c = tris[t * 3 + 2] * 3;
      const ax = verts[a], ay = verts[a + 1], az = verts[a + 2];
      const bx = verts[b], by = verts[b + 1], bz = verts[b + 2];
      const cx = verts[c], cy = verts[c + 1], cz = verts[c + 2];
      const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const len = Math.hypot(nx, ny, nz);
      if (!(len > 1e-9)) continue;
      P[t * 6] = ax; P[t * 6 + 1] = az; P[t * 6 + 2] = bx; P[t * 6 + 3] = bz; P[t * 6 + 4] = cx; P[t * 6 + 5] = cz;
      H[t * 3] = ay; H[t * 3 + 1] = by; H[t * 3 + 2] = cy;
      minY[t] = Math.min(ay, by, cy); maxY[t] = Math.max(ay, by, cy);
      wTop[t] = maxY[t] > K.ROOF ? Infinity : maxY[t];
      tminx[t] = Math.min(ax, bx, cx); tmaxx[t] = Math.max(ax, bx, cx);
      tminz[t] = Math.min(az, bz, cz); tmaxz[t] = Math.max(az, bz, cz);
      const flat = Math.abs(ny) / len > K.FLOOR_NY;
      kind[t] = flat ? 1 : 2;
      if (flat) { fnx[t] = nx / ny; fnz[t] = nz / ny; }
      const list = flat ? fcells : wcells;
      const pad = flat ? EPS_EDGE : 0;
      const c0 = Math.max(0, Math.floor((tminx[t] - pad - gx0) / K.CELL)), c1 = Math.min(gw - 1, Math.floor((tmaxx[t] + pad - gx0) / K.CELL));
      const r0 = Math.max(0, Math.floor((tminz[t] - pad - gz0) / K.CELL)), r1 = Math.min(gh - 1, Math.floor((tmaxz[t] + pad - gz0) / K.CELL));
      for (let r = r0; r <= r1; r++) for (let q = c0; q <= c1; q++) list[r * gw + q].push(t);
    }

    const stamp = new Int32Array(nT);
    let stampN = 0;
    const tmp = { x: 0, z: 0, hit: false };

    function cellOf(x, z) {
      const c = Math.floor((x - gx0) / K.CELL), r = Math.floor((z - gz0) / K.CELL);
      if (!(c >= 0 && c < gw && r >= 0 && r < gh)) return -1;
      return r * gw + c;
    }

    // is (x,z) inside the XZ projection of flat triangle t (with a tiny tolerance)?
    function inTri(t, x, z) {
      const o = t * 6;
      const ax = P[o], az = P[o + 1], bx = P[o + 2], bz = P[o + 3], cx = P[o + 4], cz = P[o + 5];
      const e1 = (bx - ax) * (z - az) - (bz - az) * (x - ax);
      const e2 = (cx - bx) * (z - bz) - (cz - bz) * (x - bx);
      const e3 = (ax - cx) * (z - cz) - (az - cz) * (x - cx);
      const t1 = EPS_EDGE * Math.hypot(bx - ax, bz - az), t2 = EPS_EDGE * Math.hypot(cx - bx, cz - bz), t3 = EPS_EDGE * Math.hypot(ax - cx, az - cz);
      return (e1 >= -t1 && e2 >= -t2 && e3 >= -t3) || (e1 <= t1 && e2 <= t2 && e3 <= t3);
    }

    function floorY(x, z, y, stepUp) {
      const ci = cellOf(x, z);
      if (ci < 0) return -Infinity;
      const lim = y + stepUp + 1e-4;
      let best = -Infinity;
      const list = fcells[ci];
      for (let i = 0; i < list.length; i++) {
        const t = list[i];
        if (minY[t] > lim || minY[t] > K.ROOF) continue;
        if (x < tminx[t] - EPS_EDGE || x > tmaxx[t] + EPS_EDGE || z < tminz[t] - EPS_EDGE || z > tmaxz[t] + EPS_EDGE) continue;
        if (!inTri(t, x, z)) continue;
        const o = t * 6;
        let h = H[t * 3] - (fnx[t] * (x - P[o]) + fnz[t] * (z - P[o + 1]));
        if (h < minY[t]) h = minY[t]; else if (h > maxY[t]) h = maxY[t];
        if (h <= lim && h > best) best = h;
      }
      return best;
    }

    function ceilY(x, z, from, to) {
      const ci = cellOf(x, z);
      if (ci < 0) return Infinity;
      let best = Infinity;
      const list = fcells[ci];
      for (let i = 0; i < list.length; i++) {
        const t = list[i];
        if (maxY[t] < from || minY[t] > to) continue;
        if (x < tminx[t] - EPS_EDGE || x > tmaxx[t] + EPS_EDGE || z < tminz[t] - EPS_EDGE || z > tmaxz[t] + EPS_EDGE) continue;
        if (!inTri(t, x, z)) continue;
        const o = t * 6;
        let h = H[t * 3] - (fnx[t] * (x - P[o]) + fnz[t] * (z - P[o + 1]));
        if (h < minY[t]) h = minY[t]; else if (h > maxY[t]) h = maxY[t];
        if (h >= from && h <= to && h < best) best = h;
      }
      return best;
    }

    // closest point on the XZ triangle t to (px,pz); result in cp (x,z); returns distance, negative if inside
    const cp = { x: 0, z: 0 };
    function segClosest(ax, az, bx, bz, px, pz, best) {
      const dx = bx - ax, dz = bz - az;
      const l2 = dx * dx + dz * dz;
      let u = l2 > 1e-14 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0;
      u = u < 0 ? 0 : u > 1 ? 1 : u;
      const qx = ax + dx * u, qz = az + dz * u;
      const d = Math.hypot(px - qx, pz - qz);
      if (d < best) { cp.x = qx; cp.z = qz; return d; }
      return best;
    }
    function triDist(t, px, pz) {
      const o = t * 6;
      const ax = P[o], az = P[o + 1], bx = P[o + 2], bz = P[o + 3], cx = P[o + 4], cz = P[o + 5];
      let d = Infinity;
      d = segClosest(ax, az, bx, bz, px, pz, d);
      d = segClosest(bx, bz, cx, cz, px, pz, d);
      d = segClosest(cx, cz, ax, az, px, pz, d);
      // inside test (only meaningful for non-degenerate projections = leaning walls)
      const area = (bx - ax) * (cz - az) - (bz - az) * (cx - ax);
      if (Math.abs(area) > 1e-9) {
        const e1 = (bx - ax) * (pz - az) - (bz - az) * (px - ax);
        const e2 = (cx - bx) * (pz - bz) - (cz - bz) * (px - bx);
        const e3 = (ax - cx) * (pz - cz) - (az - cz) * (px - cx);
        if ((e1 >= 0 && e2 >= 0 && e3 >= 0) || (e1 <= 0 && e2 <= 0 && e3 <= 0)) return -d;
      }
      return d;
    }

    // visit wall triangles that may touch a circle at (x,z), band [lo,hi]
    function gatherWalls(x, z, lo, hi, fn) {
      const c0 = Math.max(0, Math.floor((x - K.R - gx0) / K.CELL)), c1 = Math.min(gw - 1, Math.floor((x + K.R - gx0) / K.CELL));
      const r0 = Math.max(0, Math.floor((z - K.R - gz0) / K.CELL)), r1 = Math.min(gh - 1, Math.floor((z + K.R - gz0) / K.CELL));
      stampN++;
      for (let r = r0; r <= r1; r++) {
        for (let c = c0; c <= c1; c++) {
          const list = wcells[r * gw + c];
          for (let i = 0; i < list.length; i++) {
            const t = list[i];
            if (stamp[t] === stampN) continue;
            stamp[t] = stampN;
            if (wTop[t] <= lo || minY[t] >= hi) continue;
            if (x < tminx[t] - K.R || x > tmaxx[t] + K.R || z < tminz[t] - K.R || z > tmaxz[t] + K.R) continue;
            fn(t);
          }
        }
      }
    }

    function penetration(x, y, z) {
      const lo = y + K.STEP + 0.001, hi = y + K.HEIGHT;
      let worst = 0;
      gatherWalls(x, z, lo, hi, (t) => {
        const d = triDist(t, x, z);
        const pen = d < 0 ? K.R + (-d) : K.R - d;
        if (pen > worst) worst = pen;
      });
      return worst;
    }

    // visit wall triangles whose XZ bounding box touches the box [x0,x1] x [z0,z1], band [lo,hi]
    function gatherBox(x0, x1, z0, z1, lo, hi, fn) {
      const c0 = Math.max(0, Math.floor((x0 - gx0) / K.CELL)), c1 = Math.min(gw - 1, Math.floor((x1 - gx0) / K.CELL));
      const r0 = Math.max(0, Math.floor((z0 - gz0) / K.CELL)), r1 = Math.min(gh - 1, Math.floor((z1 - gz0) / K.CELL));
      stampN++;
      for (let r = r0; r <= r1; r++) {
        for (let c = c0; c <= c1; c++) {
          const list = wcells[r * gw + c];
          for (let i = 0; i < list.length; i++) {
            const t = list[i];
            if (stamp[t] === stampN) continue;
            stamp[t] = stampN;
            if (wTop[t] <= lo || minY[t] >= hi) continue;
            if (x1 < tminx[t] || x0 > tmaxx[t] || z1 < tminz[t] || z0 > tmaxz[t]) continue;
            fn(t);
          }
        }
      }
    }

    // Swept ("continuous") wall check for moves LONGER than the body radius. The map's walls are zero-thickness surfaces, so a
    // body whose radius is smaller than the step length could hop over one between two steps. Only used when the move is
    // longer than R (never for normal sizes: steps there are <= 0.15 <= R), so default behaviour is unchanged.
    // Finds the first wall footprint edge the path crosses, stops just before it and slides along it (collide and slide).
    const swp = { x: 0, z: 0, hit: false };
    function sweepClamp(x, y, z, nx, nz) {
      const lo = y + K.STEP + 0.001, hi = y + K.HEIGHT;
      let px = x, pz = z, dx = nx - x, dz = nz - z, hit = false;
      for (let it = 0; it < 4; it++) {
        const len = Math.hypot(dx, dz);
        if (!(len > 1e-12)) break;
        let bestT = 2, bex = 0, bez = 0;
        const qx = px, qz = pz, ddx = dx, ddz = dz;
        gatherBox(Math.min(qx, qx + ddx) - K.R, Math.max(qx, qx + ddx) + K.R, Math.min(qz, qz + ddz) - K.R, Math.max(qz, qz + ddz) + K.R, lo, hi, (t) => {
          if (triDist(t, qx, qz) < 0) return; // already inside this footprint: the normal push-out deals with it
          const o = t * 6;
          for (let e = 0; e < 3; e++) {
            const ax = P[o + e * 2], az = P[o + e * 2 + 1], bx = P[o + ((e + 1) % 3) * 2], bz = P[o + ((e + 1) % 3) * 2 + 1];
            const ex = bx - ax, ez = bz - az;
            const den = ddx * ez - ddz * ex;
            if (Math.abs(den) < 1e-18) continue; // parallel
            const wx = ax - qx, wz = az - qz;
            const tt = (wx * ez - wz * ex) / den, uu = (wx * ddz - wz * ddx) / den;
            if (tt < 0 || tt > 1 || uu < -1e-6 || uu > 1 + 1e-6) continue;
            if (tt < bestT) { bestT = tt; bex = ex; bez = ez; }
          }
        });
        if (bestT > 1) { px += dx; pz += dz; break; }
        hit = true;
        const back = Math.min(K.R, bestT * len);
        px += dx * bestT - (dx / len) * back; pz += dz * bestT - (dz / len) * back;
        const el = Math.hypot(bex, bez);
        if (!(el > 1e-12)) break;
        const tx = bex / el, tz = bez / el, dot = (dx * tx + dz * tz) * (1 - bestT);
        dx = tx * dot; dz = tz * dot;
      }
      swp.x = px; swp.z = pz; swp.hit = hit;
      return swp;
    }

    function moveXZ(x, y, z, nx, nz, out) {
      const lo = y + K.STEP + 0.001, hi = y + K.HEIGHT;
      let cx = nx, cz = nz, hit = false;
      if (Math.hypot(nx - x, nz - z) > K.R) {
        sweepClamp(x, y, z, nx, nz);
        if (swp.hit) { cx = swp.x; cz = swp.z; hit = true; }
      }
      for (let pass = 0; pass < 4; pass++) {
        let moved = false;
        gatherWalls(cx, cz, lo, hi, (t) => {
          const d = triDist(t, cx, cz);
          if (d >= K.R - Math.min(1e-5, K.R * 1e-3)) return;
          let dirx, dirz, qx, qz;
          if (d >= 0) {
            // recompute closest point (triDist leaves it in cp for the best segment)
            qx = cp.x; qz = cp.z;
            const dx = cx - qx, dz = cz - qz, l = Math.hypot(dx, dz);
            if (l > 1e-9) { dirx = dx / l; dirz = dz / l; } else { dirx = 0; dirz = 0; }
          } else {
            // centre inside a leaning wall's footprint: leave through the nearest edge
            qx = cp.x; qz = cp.z;
            const dx = qx - cx, dz = qz - cz, l = Math.hypot(dx, dz);
            if (l > 1e-9) { dirx = dx / l; dirz = dz / l; } else { dirx = 0; dirz = 0; }
          }
          if (dirx === 0 && dirz === 0) return;
          cx = qx + dirx * K.R; cz = qz + dirz * K.R;
          moved = true; hit = true;
        });
        if (!moved) break;
      }
      if (hit && penetration(cx, y, cz) > K.PEN_WEDGE) { cx = x; cz = z; } // wedged in a corner: stay put
      out.x = cx; out.z = cz; out.hit = hit;
      return out;
    }

    // a flat surface passing through the body band at the centre point = inside a slab / under a too-low overhang
    const inSlab = (x, y, z) => ceilY(x, z, y + K.STEP + 0.01, y + K.HEIGHT - 0.01) < Infinity;
    const mb = { x: 0, z: 0, hit: false };
    // moveXZ + refuse to move the centre into a slab (tries the x-only and z-only slide before giving up)
    function moveBody(x, y, z, nx, nz, out) {
      moveXZ(x, y, z, nx, nz, out);
      if (!inSlab(out.x, y, out.z) || inSlab(x, y, z)) return out;
      const hit = out.hit, tx = out.x, tz = out.z;
      moveXZ(x, y, z, tx, z, mb);
      if (!inSlab(mb.x, y, mb.z)) { out.x = mb.x; out.z = mb.z; out.hit = true; return out; }
      moveXZ(x, y, z, x, tz, mb);
      if (!inSlab(mb.x, y, mb.z)) { out.x = mb.x; out.z = mb.z; out.hit = true; return out; }
      out.x = x; out.z = z; out.hit = true;
      return out;
    }

    function sweepXZ(x0, z0, y0, x1, z1, y1, out) {
      const dx = x1 - x0, dz = z1 - z0;
      const n = Math.min(K.SWEEP_CAP, Math.max(1, Math.ceil(Math.hypot(dx, dz) / K.MAXSTEP)));
      let x = x0, z = z0, hit = false;
      for (let i = 1; i <= n; i++) {
        const f = i / n;
        // advance by one chord step from the CURRENT (possibly slid) position, like the client mover does,
        // so a wall can never be skipped because the target jumped past it
        moveBody(x, y0 + (y1 - y0) * f, z, x + dx / n, z + dz / n, tmp);
        x = tmp.x; z = tmp.z; if (tmp.hit) hit = true;
      }
      out.x = x; out.z = z; out.hit = hit;
      return out;
    }

    const bounds = { minx: bminx, maxx: bmaxx, minz: bminz, maxz: bmaxz, miny: bminy, maxy: bmaxy };
    const clampX = (x) => (x < bminx + K.R ? bminx + K.R : x > bmaxx - K.R ? bmaxx - K.R : x);
    const clampZ = (z) => (z < bminz + K.R ? bminz + K.R : z > bmaxz - K.R ? bmaxz - K.R : z);
    const mv = { x: 0, z: 0, hit: false };

    // Called after the body moved up/down without moving sideways (landing, step up/down, head bump): push out of walls
    // that now overlap the body band. If that fails (dropped into a slot narrower than the body, the push-out would only
    // end up in the next wall) look for the nearest free spot within UNSTICK metres (kept < R so a thin wall can never be crossed,
    // which would desync client and server) on a floor at about the same height. Slots narrower than the body stay
    // slightly overlapped; the player can always walk out of them (tools/test-reach.js checks this).
    function settle(s) {
      moveXZ(s.x, s.y, s.z, s.x, s.z, mv); s.x = mv.x; s.z = mv.z;
      if (penetration(s.x, s.y, s.z) <= K.PEN_WEDGE) return;
      const rStep = K.UNSTICK >= 0.13 ? 0.13 : K.UNSTICK / 2; // 0.13 for normal sizes; tiny bodies need tiny rings
      for (let r = rStep; r <= K.UNSTICK + 1e-12; r += rStep) {
        for (let k = 0; k < 24; k++) {
          const a = k * (Math.PI / 12), px = clampX(s.x + Math.cos(a) * r), pz = clampZ(s.z + Math.sin(a) * r);
          if (penetration(px, s.y, pz) > K.PEN_FREE) continue;
          if (floorY(px, pz, s.y, K.STEP) < s.y - K.STEP) continue; // must be a floor at about this height
          s.x = px; s.z = pz; return;
        }
      }
    }

    // ---- client mover ----
    function step(s, dt, mx, mz, jump) {
      const ml = Math.hypot(mx, mz);
      const dist = Math.min(ml, 1) * K.SPEED * dt;
      const n = Math.min(K.STEP_CAP, Math.max(1, Math.ceil(dist / K.MAXSTEP), Math.ceil(Math.abs(s.vy) * dt / 0.3)));
      const h = dt / n;
      const k = ml > 1 ? 1 / ml : 1;          // never faster than SPEED
      const sx = mx * k * K.SPEED * h, sz = mz * k * K.SPEED * h;
      for (let i = 0; i < n; i++) {
        if (jump && s.ground) { s.vy = K.JUMP; s.ground = false; }
        if (sx !== 0 || sz !== 0) {
          moveBody(s.x, s.y, s.z, clampX(s.x + sx), clampZ(s.z + sz), mv);
          s.x = clampX(mv.x); s.z = clampZ(mv.z);
        }
        const f = floorY(s.x, s.z, s.y, K.STEP);
        if (s.ground) {
          if (f > -Infinity && f >= s.y - K.STEP) {
            s.y = f; s.vy = 0;
            settle(s); // step up/down changed the body band
            continue;
          }
          s.ground = false;                   // walked off an edge
          s.vy = 0;
        }
        s.vy -= K.GRAV * h;
        let ny = s.y + s.vy * h;
        if (s.vy > 0) {
          const c = ceilY(s.x, s.z, s.y + K.HEIGHT - 0.01, ny + K.HEIGHT);
          if (c < Infinity) { ny = c - K.HEIGHT; s.vy = 0; }
        }
        if (f > -Infinity && ny <= f) {       // landed (or stepped up onto a ledge while rising)
          ny = f;
          if (s.vy <= 0) { s.vy = 0; s.ground = true; }
        }
        s.y = ny;
        // the body band moved up/down: push out of walls that now overlap it (low roofs, curbs after a step-down)
        settle(s);
        if (s.y < K.MIN_Y) { s.y = K.MIN_Y; s.vy = 0; s.ground = true; s.lost = true; } // fell out of the world
      }
      return s;
    }

    // ---- server validation ----
    const sw = { x: 0, z: 0, hit: false };
    function validatePose(st, cx, cy, cz, dt, out) {
      dt = Math.max(0.001, Math.min(dt, 0.25));
      const rise = Math.min(1.6, K.JUMP * dt + 0.6);
      let y1 = Math.min(cy, st.y + rise);
      if (y1 < K.MIN_Y) y1 = K.MIN_Y;
      cx = clampX(cx); cz = clampZ(cz);
      sweepXZ(st.x, st.z, st.y, cx, cz, y1, sw);
      let x = sw.x, z = sw.z;
      if (Math.hypot(x - cx, z - cz) <= K.TOL && penetration(cx, y1, cz) <= K.PEN_OK && !inSlab(cx, y1, cz)) { x = cx; z = cz; }
      if (y1 > st.y) {                                  // rising: the head cannot pass a ceiling/roof at the NEW position
        const c = ceilY(x, z, st.y + K.HEIGHT - 0.01, y1 + K.HEIGHT + 0.05);
        if (c < Infinity) y1 = Math.max(st.y, Math.min(y1, c - K.HEIGHT + 0.05));
      }
      // the floor under the last accepted height is solid: you cannot be below it
      const f = floorY(x, z, Math.max(st.y, y1), K.STEP + 0.01);
      const lo = f > -Infinity ? f : K.MIN_Y;
      let hi;
      if (st.air < 0.9) hi = Math.max(lo + K.JUMP_H + 0.4, st.gy + K.JUMP_H + 0.4, st.y - 2 * dt); // normal jump envelope
      else hi = st.y - 2 * dt;                           // airborne too long: must be coming down
      let y = Math.min(Math.max(y1, lo), Math.max(hi, lo));
      if (y < K.MIN_Y) y = K.MIN_Y;
      if (y <= lo + 0.15) { st.air = 0; st.gy = y; } else st.air += dt;
      out.x = x; out.y = y; out.z = z;
      out.lost = f === -Infinity && y <= K.MIN_Y + 0.05;  // fell through a hole / off the map edge
      out.corrected = Math.hypot(x - cx, z - cz) > 0.05 || Math.abs(y - cy) > 0.3;
      return out;
    }

    // ---- ray cast (bullets, line of sight) ----
    // Double sided: every triangle (flat or steep, any winding) blocks. 2D grid DDA over the XZ cells, both lists.
    const RAY_EPS = 1e-7;
    const gx1 = gx0 + gw * K.CELL, gz1 = gz0 + gh * K.CELL;
    function rayCell(ci, ox, oy, oz, dx, dy, dz, best) {
      for (let k = 0; k < 2; k++) {
        const list = k === 0 ? wcells[ci] : fcells[ci];
        for (let i = 0; i < list.length; i++) {
          const t = list[i];
          if (stamp[t] === stampN) continue;       // already tested via another cell
          stamp[t] = stampN;
          const o = t * 6, h = t * 3;
          const ax = P[o], az = P[o + 1], ay = H[h];
          const e1x = P[o + 2] - ax, e1y = H[h + 1] - ay, e1z = P[o + 3] - az;
          const e2x = P[o + 4] - ax, e2y = H[h + 2] - ay, e2z = P[o + 5] - az;
          const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
          const det = e1x * px + e1y * py + e1z * pz;
          if (det > -1e-12 && det < 1e-12) continue;   // parallel to the triangle plane
          const inv = 1 / det;
          const sx = ox - ax, sy = oy - ay, sz = oz - az;
          const u = (sx * px + sy * py + sz * pz) * inv;
          if (u < -RAY_EPS || u > 1 + RAY_EPS) continue;
          const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
          const v = (dx * qx + dy * qy + dz * qz) * inv;
          if (v < -RAY_EPS || u + v > 1 + RAY_EPS) continue;
          const tt = (e2x * qx + e2y * qy + e2z * qz) * inv;
          if (tt >= 0 && tt < best) best = tt;
        }
      }
      return best;
    }

    function raycast(ox, oy, oz, dx, dy, dz, maxT) {
      if (!(maxT > 0)) return Infinity;
      if (!(Math.abs(ox) < 1e7 && Math.abs(oy) < 1e7 && Math.abs(oz) < 1e7 && Math.abs(dx) <= 1.0001 && Math.abs(dy) <= 1.0001 && Math.abs(dz) <= 1.0001)) return Infinity; // also rejects NaN
      if (++stampN > 2000000000) { stamp.fill(0); stampN = 1; }
      // clip the ray against the grid rectangle (nothing exists outside it)
      let t0 = 0, t1 = maxT;
      if (Math.abs(dx) < 1e-12) { if (ox < gx0 || ox > gx1) return Infinity; }
      else {
        let a = (gx0 - ox) / dx, b = (gx1 - ox) / dx;
        if (a > b) { const q = a; a = b; b = q; }
        if (a > t0) t0 = a; if (b < t1) t1 = b;
      }
      if (Math.abs(dz) < 1e-12) { if (oz < gz0 || oz > gz1) return Infinity; }
      else {
        let a = (gz0 - oz) / dz, b = (gz1 - oz) / dz;
        if (a > b) { const q = a; a = b; b = q; }
        if (a > t0) t0 = a; if (b < t1) t1 = b;
      }
      if (t0 > t1) return Infinity;
      const sxp = ox + dx * t0, szp = oz + dz * t0;
      let c = Math.floor((sxp - gx0) / K.CELL), r = Math.floor((szp - gz0) / K.CELL);
      c = c < 0 ? 0 : c >= gw ? gw - 1 : c; r = r < 0 ? 0 : r >= gh ? gh - 1 : r;
      let best = Infinity;
      if (Math.abs(dx) < 1e-12 && Math.abs(dz) < 1e-12) {          // vertical ray: one cell
        best = rayCell(r * gw + c, ox, oy, oz, dx, dy, dz, best);
        return best <= maxT ? best : Infinity;
      }
      const stX = dx > 0 ? 1 : -1, stZ = dz > 0 ? 1 : -1;
      const tdX = Math.abs(dx) < 1e-12 ? Infinity : K.CELL / Math.abs(dx);
      const tdZ = Math.abs(dz) < 1e-12 ? Infinity : K.CELL / Math.abs(dz);
      let tmX = tdX === Infinity ? Infinity : (dx > 0 ? (gx0 + (c + 1) * K.CELL - ox) : (ox - (gx0 + c * K.CELL))) / Math.abs(dx);
      let tmZ = tdZ === Infinity ? Infinity : (dz > 0 ? (gz0 + (r + 1) * K.CELL - oz) : (oz - (gz0 + r * K.CELL))) / Math.abs(dz);
      for (;;) {
        best = rayCell(r * gw + c, ox, oy, oz, dx, dy, dz, best);
        const exit = tmX < tmZ ? tmX : tmZ;
        if (best <= exit || exit > t1) break;                        // nothing nearer can be in a later cell
        if (tmX < tmZ) { c += stX; tmX += tdX; if (c < 0 || c >= gw) break; }
        else { r += stZ; tmZ += tdZ; if (r < 0 || r >= gh) break; }
      }
      return best <= maxT ? best : Infinity;
    }

    // true when nothing blocks the straight line a -> b
    function visible(ax, ay, az, bx, by, bz) {
      const dx = bx - ax, dy = by - ay, dz = bz - az;
      const L = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (!(L > 1e-6)) return true;
      return raycast(ax, ay, az, dx / L, dy / L, dz / L, L - 0.02) === Infinity;
    }

    return { floorY, ceilY, moveXZ, penetration, isSolid: (x, y, z) => penetration(x, y, z) > K.PEN_FREE, sweepXZ, step, validatePose, raycast, visible, bounds, triangles: nT };
  }

  // Change the player radius (metres). The ONLY place the size is derived: server.js reads config.json / PLAYER_RADIUS and
  // calls this, and the server sends the value to every client (welcome.world.r) which calls it too, so both always agree.
  // Everything that depends on R is re-derived here: UNSTICK must stay < R, TOL must stay < 2*R, MAXSTEP must stay < R.
  const R_MIN = 0.00001, R_MAX = 0.5;
  // Height: configure(radius, height). EYE (the camera) and STEP (auto step-up) follow the height, so the whole body scales.
  const H_MIN = 0.05, H_MAX = 3;
  function configure(radius, height) {
    const rr = radius === undefined || radius === null ? K.R : Number(radius);
    const r = Math.min(R_MAX, Math.max(R_MIN, rr));
    if (!Number.isFinite(r)) return K.R;
    const hh = height === undefined || height === null ? K.HEIGHT : Number(height);
    const h = Math.min(H_MAX, Math.max(H_MIN, hh));
    if (Number.isFinite(h)) {
      K.HEIGHT = h;
      K.EYE = Math.round(h * (1.6 / 1.8) * 1e9) / 1e9;       // eye / camera height (1.6 at the default 1.8)
      K.STEP = Math.min(0.5, h * (0.5 / 1.8));               // step-up must stay well below the body height
    }
    K.R = r;
    K.UNSTICK = r * 0.95;
    K.TOL = Math.min(0.5, r * 1.75);
    K.MAXSTEP = Math.min(0.15, r * 0.75);
    K.PEN_OK = Math.min(0.12, r * 0.6);
    K.PEN_WEDGE = Math.min(0.05, r * 0.5);
    K.PEN_FREE = Math.min(0.02, r * 0.2);
    for (const k of ['HEIGHT', 'EYE', 'STEP', 'R', 'UNSTICK', 'TOL', 'MAXSTEP', 'PEN_OK', 'PEN_WEDGE', 'PEN_FREE']) api[k] = K[k];
    return K.R;
  }
  // how many steps per metre a pose is rounded to on the wire: 100 (1 cm) for normal sizes, finer for tiny bodies
  function wirePrecision() {
    return K.R >= 0.1 ? 100 : Math.pow(10, Math.min(9, Math.ceil(-Math.log10(K.R)) + 2));
  }
  // Body proportions shared by server (hit areas, aim) and client (blocking, aim assist): everything derives from HEIGHT and R.
  function dims() {
    const s = K.HEIGHT / 1.8, R = K.R;
    return {
      s,
      headY: 1.55 * s, headR: Math.min(0.13 * s + 0.35 * R, 0.3 * s),     // head hit sphere
      bodyY: 0.85 * s, bodyR: Math.min(Math.max(1.5 * R, 0.15 * s), 0.55 * s), // body hit sphere
      aimY: 1.15 * s, aimLowY: 1.0 * s,                                    // aim assist targets (chest)
      deadEye: 0.5 * s,                                                    // camera height while dead
    };
  }
  const api = Object.assign({ create, configure, wirePrecision, dims }, K);
  return api;
});
