'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');

// ---- config -------------------------------------------------------------
// Port: PORT, or SERVER_PORT (set by Pelican/Pterodactyl to the allocation port), else 27043.
const PORT = parseInt(process.env.PORT || process.env.SERVER_PORT, 10) || 27043;
// Bare metal: bind to localhost only (cloudflared runs on the same machine).
// Inside a Pelican/Pterodactyl container 127.0.0.1 is unreachable from outside,
// so bind to all interfaces there. Override anytime with HOST=...
const IN_PANEL = !!(process.env.SERVER_PORT || process.env.P_SERVER_UUID);
const HOST = process.env.HOST || (IN_PANEL ? '0.0.0.0' : '127.0.0.1');
const PUBLIC_DIR = path.join(__dirname, 'public');

// Download authentic CS:GO M4A1 WAVs from SourceSounds once, then serve them locally.
// The browser never fetches audio from GitHub; all playback uses /sounds/m4a1/.
function ensureOfficialM4Sounds() {
  const https = require('https');
  const soundDir = path.join(PUBLIC_DIR, 'sounds', 'm4a1');
  const base = 'https://raw.githubusercontent.com/sourcesounds/csgo/master/sound/weapons/m4a1/';
  const names = [
    'm4a1_silencer_01.wav',
    'm4a1_clipout.wav',
    'm4a1_clipin.wav',
    'm4a1_boltforward.wav',
  ];
  fs.mkdirSync(soundDir, { recursive: true });
  return Promise.all(names.map((name) => new Promise((resolve) => {
    const target = path.join(soundDir, name);
    const temp = target + '.download';
    const req = https.get(base + encodeURIComponent(name), (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        console.warn(`[audio] Could not fetch official ${name} (HTTP ${res.statusCode}); keeping existing local file if present.`);
        return resolve();
      }
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        const data = Buffer.concat(chunks);
        if (data.length < 44 || data.toString('ascii', 0, 4) !== 'RIFF' || data.toString('ascii', 8, 12) !== 'WAVE') {
          console.warn(`[audio] Invalid WAV for ${name}; keeping existing local file if present.`);
          return resolve();
        }
        try {
          fs.writeFileSync(temp, data);
          fs.renameSync(temp, target);
          console.log(`[audio] Installed official CS:GO sound: ${name} (${data.length} bytes)`);
        } catch (err) {
          console.warn(`[audio] Could not save ${name}: ${err.message}`);
        }
        resolve();
      });
    });
    req.setTimeout(10000, () => req.destroy(new Error('download timeout')));
    req.on('error', (err) => {
      console.warn(`[audio] Download failed for ${name}: ${err.message}; keeping existing local file if present.`);
      resolve();
    });
  })));
}
ensureOfficialM4Sounds();


// Admin panel password. Set ADMIN_PASSWORD in the environment to choose your own.
// If you don't, a random one is generated and printed in the console at startup.
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || crypto.randomBytes(4).toString('hex');
const ADMIN_PW_GENERATED = !process.env.ADMIN_PASSWORD;

// ---- game constants (1 unit ~ 1 metre) ----------------------------------
const TICK_RATE = 20;          // state broadcasts per second
const ARENA = 40;              // arena is [-40, 40] on x and z
const SPEED = 5.5;             // walking speed, m/s (CS-like: a rifle carrier runs ~5.5 m/s)
// Player size: collision radius in metres (0.4 = original fat body, 0.2 = slim). Set it ONE of these ways (first wins):
//   1. environment variable PLAYER_RADIUS=0.25
//   2. "playerRadius" in config.json next to server.js
//   3. default below
// Allowed 0.00001 - 0.5. The server sends it to every client, so nobody has to edit anything else.
const DEFAULT_PLAYER_R = 0.2;
function readSetting(envName, key, dflt, lo, hi, label) {
  let v = parseFloat(process.env[envName]);
  let from = envName + ' env';
  if (!Number.isFinite(v)) {
    try {
      v = parseFloat(JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'))[key]);
      from = 'config.json';
    } catch (e) { v = NaN; }
  }
  if (!Number.isFinite(v)) { v = dflt; from = 'default'; }
  const c = Math.min(hi, Math.max(lo, v));
  if (c !== v) console.warn(`[config] ${key} ${v} out of range, using ${c} (allowed ${lo} - ${hi})`);
  console.log(`[config] ${label} ${c} m (${from})`);
  return c;
}
// Player height (metres, default 1.8). The camera (eye height 8/9 of it), step-up height, avatar, hit areas and aim points all follow it.
//   PLAYER_HEIGHT env or "playerHeight" in config.json, allowed 0.05 - 3.
const PLAYER_R = readSetting('PLAYER_RADIUS', 'playerRadius', DEFAULT_PLAYER_R, 0.00001, 0.5, 'player radius');   // collision radius
const PLAYER_H = readSetting('PLAYER_HEIGHT', 'playerHeight', 1.8, 0.05, 3, 'player height');
let EYE = 1.6;                 // eye height above feet (set from PLAYER_H below)
const MAX_HP = 100;
const BODY_DMG = 25;
const HEAD_DMG = 50;
const FIRE_MS = 140;           // minimum time between shots
const RANGE = 150;
const RESPAWN_MS = 3000;
const ROUND_MS = 10 * 60 * 1000;
const WEAPON_PICKUP_RADIUS = 2.0;
const WEAPON_FREEZE_DELAY = 1000;
const WEAPON_LIFETIME = 90 * 1000;
const MAX_PLAYERS = 16;
const BOT_TARGET = 10; // fill empty slots with bots until the match has ten combatants
const MAX_MSGS_PER_SEC = 120;  // simple per-connection flood protection

// Spawn candidates, site markers and the flat fallback arena live in map.js; the level itself is the real de_dust2 mesh.
const MAPS = require('./map');
let ACTIVE_MAP = 'dust2';
try {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
  if (String(cfg.activeMap || '').toLowerCase() === 'neon') ACTIVE_MAP = 'neon';
} catch (e) {}
const T_SPAWNS = ACTIVE_MAP === 'dust2' ? MAPS.DUST2_T_SPAWNS : MAPS.NEON_T_SPAWNS;
const CT_SPAWNS = ACTIVE_MAP === 'dust2' ? MAPS.DUST2_CT_SPAWNS : MAPS.NEON_CT_SPAWNS;
const SITES = ACTIVE_MAP === 'dust2' ? MAPS.DUST2_SITES : MAPS.NEON_SITES;
const { FLAT_SPAWNS } = MAPS;

// ---- real de_dust2 collision -------------------------------------------------
// Shared with the client: public/shared/collision.js + public/maps/dust2.collision.json.
// FAILURE PATH: if either is missing or broken the server logs a loud error and runs a tiny FLAT-FLOOR arena instead
// (floor y 0, outer walls at +-ARENA, FLAT_SPAWNS from map.js) so it still starts. world.map is then 'flat'.
const Collision = require('./public/shared/collision.js');
Collision.configure(PLAYER_R, PLAYER_H);
EYE = Collision.EYE;
const DIMS = Collision.dims();

// Hit areas. "model" (default): every character is hit exactly where its .glb model is (hitboxes.js builds slices from the mesh; head
// slices give headshots). "spheres": the old head + body spheres, the same for everybody. Set HITBOXES=spheres or "hitboxes": "spheres"
// in config.json to go back; one model can opt out with "hitbox": { "enabled": false } in characters.json.
const { create: createHitboxes, rayModel } = require('./hitboxes.js');
let HITBOX_MODE = String(process.env.HITBOXES || '').toLowerCase();
if (!HITBOX_MODE) { try { HITBOX_MODE = String(JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')).hitboxes || '').toLowerCase(); } catch (e) {} }
if (HITBOX_MODE !== 'spheres') HITBOX_MODE = 'model';
const HB = HITBOX_MODE === 'model' ? createHitboxes({ publicDir: PUBLIC_DIR, log: (m) => console.log(m) }) : null;
console.log(`[hitbox] mode: ${HITBOX_MODE}`);
if (HB) HB.preload();
let COL = null;
try {
  const collisionFile = ACTIVE_MAP === 'dust2' ? 'dust2.collision.json' : 'map.collision.json';
  const data = JSON.parse(fs.readFileSync(path.join(PUBLIC_DIR, 'maps', collisionFile), 'utf8'));
  COL = Collision.create(data);
  if (Collision.SPEED !== SPEED) console.warn('[collision] WARNING: SPEED in server.js differs from public/shared/collision.js');
  console.log(`[collision] ${ACTIVE_MAP === 'dust2' ? 'Dust 2' : 'Neon Arena'} mesh loaded: ${COL.triangles} triangles`);
} catch (err) {
  COL = null;
  console.error('################################################################');
  console.error(`[collision] ERROR: could not load the ${ACTIVE_MAP} collision mesh:`, err.message);
  console.error('[collision] Running the FLAT FALLBACK arena (no walls, no real map). Check the collision JSON for the selected map.');
  console.error('################################################################');
}

// Spawn points: every candidate is re-checked against the mesh (a floor must exist, body not inside a wall). [x, z, y]
function verifySpawns(list) {
  const out = [];
  for (const [x, z] of list) {
    const y = COL.floorY(x, z, 3.0, 0);
    if (y === -Infinity || COL.isSolid(x, y, z)) { console.warn(`[spawns:${ACTIVE_MAP}] dropped (${x}, ${z}): no floor or inside a wall`); continue; }
    out.push([x, z, y]);
  }
  return out;
}
const MESH_T_SPAWNS = COL ? verifySpawns(T_SPAWNS) : [];
const MESH_CT_SPAWNS = COL ? verifySpawns(CT_SPAWNS) : [];
const MESH_SPAWNS = MESH_T_SPAWNS.concat(MESH_CT_SPAWNS);
const USE_MESH = !!(COL && MESH_SPAWNS.length);
if (COL && !USE_MESH) console.error(`[spawns] ERROR: no valid ${ACTIVE_MAP} spawn point, running the FLAT FALLBACK arena`);
const SPAWN_LIST = USE_MESH ? MESH_SPAWNS : FLAT_SPAWNS.map(([x, z]) => [x, z, 0]);
if (USE_MESH) console.log(`[spawns] ${SPAWN_LIST.length} verified spawn points`);
// site markers with their floor height: [label, x, y, z, size]
const SITES_OUT = SITES.map(([label, x, z, size]) => [label, x, USE_MESH ? Math.max(COL.floorY(x, z, 4, 0.2), -2) : 0, z, size]);

// ---- static file server -------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.glb': 'model/gltf-binary',
  '.json': 'application/json; charset=utf-8',
};

const server = http.createServer((req, res) => {
  let urlPath;
  try {
    urlPath = decodeURIComponent(req.url.split('?')[0]);
  } catch {
    res.writeHead(400).end('Bad request');
    return;
  }
  if (urlPath === '/') urlPath = '/index.html';
  if (urlPath === '/info.json') { // tiny status for the join card: which level this server runs
    res.writeHead(200, { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ map: USE_MESH ? ACTIVE_MAP : 'flat', players: players.size, max: MAX_PLAYERS, teams: teamCounts() }));
    return;
  }
  if (urlPath === '/select-map' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => { body += chunk; if (body.length > 1024) req.destroy(); });
    req.on('end', () => {
      let requested;
      try { requested = JSON.parse(body).map; } catch (e) { res.writeHead(400).end('Invalid JSON'); return; }
      if (requested !== 'dust2' && requested !== 'neon') { res.writeHead(400).end('Unsupported map'); return; }
      if (requested === ACTIVE_MAP) { res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ ok: true, map: ACTIVE_MAP, changed: false })); return; }
      try {
        const configPath = path.join(__dirname, 'config.json');
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        config.activeMap = requested;
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n');
      } catch (err) { res.writeHead(500).end('Could not save map selection'); return; }
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({ ok: true, map: requested, restarting: true }));
      // Map collision, spawns and world state are initialized at process start.
      // Under a hosting panel, exit cleanly and let the supervisor restart this process;
      // self-spawning there causes two processes to race for the same port and can take the site down.
      // On a standalone install, start a delayed replacement before exiting this listener.
      setTimeout(() => {
        if (IN_PANEL) {
          console.log('[map] selection saved; exiting for hosting supervisor restart');
          process.exit(0);
          return;
        }
        const script = `setTimeout(() => require(${JSON.stringify(__filename)}), 1500)`;
        const child = spawn(process.execPath, ['-e', script], { cwd: __dirname, env: process.env, stdio: 'inherit', windowsHide: true });
        child.on('error', (err) => console.error('[map] failed to relaunch server:', err));
        setTimeout(() => process.exit(0), 100);
      }, 100);
    });
    return;
  }

  const filePath = path.join(PUBLIC_DIR, path.normalize(urlPath));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep)) {
    res.writeHead(403).end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
});

// ---- helpers ------------------------------------------------------------
const players = new Map(); // id -> player
const droppedWeapons = new Map();
let nextWeaponId = 1;
let nextPlayerId = 1;
let roundStartedAt = Date.now();
let roundNumber = 1;
function teamCounts() { let t = 0, ct = 0; for (const p of players.values()) p.team === 'T' ? t++ : ct++; return { T: t, CT: ct }; }
function assignTeam(requested) { const c = teamCounts(); if (requested === 'T' && c.T <= c.CT) return 'T'; if (requested === 'CT' && c.CT <= c.T) return 'CT'; return c.T <= c.CT ? 'T' : 'CT'; }
function setPlayerTeam(p, requested) { if (requested !== 'T' && requested !== 'CT') return false; const c = teamCounts(); const other = requested === 'T' ? c.CT : c.T; const own = requested === 'T' ? c.T : c.CT; if (own > other) { send(p.ws, { t:'teamDenied', team:p.team, counts:c, message:'Teams must stay balanced. Choose the team with fewer players.' }); return false; } p.team=requested; const [sx,sz,sy]=pickSpawn(p); p.x=sx; p.z=sz; p.y=sy; p.gy=sy; p.hp=MAX_HP; p.dead=false; p.seq++; p.hasWeapon=true; p.ammo=30; p.reserve=90; broadcast({t:'team',id:p.id,team:p.team}); send(p.ws,{t:'teamChanged',team:p.team,counts:teamCounts()}); return true; }
function botCount() { let n=0; for (const p of players.values()) if (p.isBot) n++; return n; }
function addBot(team) {
  if (players.size >= MAX_PLAYERS) return null;
  const id = nextPlayerId++;
  const names = ['Wesley','Tony','Panama','Oli','Greymouth','York','Telsen','Larry','Colin','Mason','Rook','Viper','Bishop','Echo','Ranger','Ghost'];
  const used = new Set([...players.values()].filter(p=>p.isBot).map(p=>p.name));
  const name = names.find(n=>!used.has(n)) || `Bot${id}`;
  const p={id,ws:null,isBot:true,team:team || assignTeam(),hasWeapon:true,name:`[BOT] ${name}`,hue:Math.floor(rand(0,360)),x:0,y:0,z:0,yaw:0,pitch:0,gy:0,air:0,hp:MAX_HP,ammo:30,reserve:90,reloadUntil:0,kills:0,deaths:0,dead:false,seq:0,lastMove:Date.now(),lastFire:0,respawnTimer:null,aim:null,isAdmin:false,adminTries:0,lastDamaged:0,lastStuck:0,ax:0,ay:0,az:0,stillSince:Date.now(),botThinkAt:0,botSeenAt:0,botTargetId:null,botLastSeen:null,botReactAt:0,botPauseUntil:0,botNextPause:Date.now()+2000+Math.random()*5000,botAimError:0,botStrafeUntil:0};
  const [sx,sz,sy]=pickSpawn(p); p.x=p.ax=sx;p.z=p.az=sz;p.y=p.gy=p.ay=sy;p.yaw=Math.atan2(sx,sz);players.set(id,p);broadcast({t:'join',id,name:p.name,hue:p.hue,team:p.team});return p;
}
function maintainBots() {
  while (players.size < Math.min(BOT_TARGET, MAX_PLAYERS) && botCount() < MAX_PLAYERS-players.size) addBot();
}
function replaceBotForJoin(requested) {
  const bots=[...players.values()].filter(p=>p.isBot).sort((a,b)=> (a.team===requested?-1:0)-(b.team===requested?-1:0));
  if (!bots.length) return;
  const b=bots[0]; if(b.respawnTimer)clearTimeout(b.respawnTimer);players.delete(b.id);broadcast({t:'leave',id:b.id});
}
// Collision-mesh navigation grid. Nodes are created only where the real map has a floor
// and the player capsule is not intersecting a wall. Bots use A* over this grid rather than
// walking directly toward targets (which made them push into walls indefinitely).
const NAV_CELL = 0.75;
let NAV = null;
function buildNavGrid() {
  if (!COL || !USE_MESH) return null;
  const bounds = COL.bounds;
  const minX = Math.floor(bounds.minx / NAV_CELL) * NAV_CELL;
  const maxX = Math.ceil(bounds.maxx / NAV_CELL) * NAV_CELL;
  const minZ = Math.floor(bounds.minz / NAV_CELL) * NAV_CELL;
  const maxZ = Math.ceil(bounds.maxz / NAV_CELL) * NAV_CELL;
  const cols = Math.round((maxX-minX)/NAV_CELL)+1, rows = Math.round((maxZ-minZ)/NAV_CELL)+1;
  const nodes = new Array(cols*rows).fill(null);
  for (let iz=0; iz<rows; iz++) for(let ix=0; ix<cols; ix++) {
    const x=minX+ix*NAV_CELL, z=minZ+iz*NAV_CELL;
    const y=COL.floorY(x,z,Math.min(bounds.maxy, 4.5),0.05);
    if(y===-Infinity || y < -1.5 || y > 3.5 || COL.isSolid(x,y,z)) continue;
    nodes[iz*cols+ix]={id:iz*cols+ix,ix,iz,x,y,z,edges:[]};
  }
  const dirs=[[-1,0,1],[1,0,1],[0,-1,1],[0,1,1],[-1,-1,Math.SQRT2],[-1,1,Math.SQRT2],[1,-1,Math.SQRT2],[1,1,Math.SQRT2]];
  for(const n of nodes) if(n) for(const [dx,dz,cost] of dirs) {
    const xx=n.ix+dx, zz=n.iz+dz; if(xx<0||zz<0||xx>=cols||zz>=rows)continue;
    const q=nodes[zz*cols+xx]; if(!q || Math.abs(q.y-n.y)>0.55)continue;
    if(dx&&dz && (!nodes[n.iz*cols+xx] || !nodes[zz*cols+n.ix]))continue;
    const out={x:0,z:0}; COL.sweepXZ(n.x,n.z,n.y,q.x,q.z,q.y,out);
    if(Math.hypot(out.x-q.x,out.z-q.z)>0.22)continue;
    n.edges.push({to:q,cost:cost*Math.hypot(q.x-n.x,q.z-n.z)+Math.abs(q.y-n.y)*1.5});
  }
  NAV={nodes,cols,rows,minX,minZ,cell:NAV_CELL};
  console.log(`[bot-nav] collision navigation grid: ${cols}x${rows}, ${nodes.filter(Boolean).length} walkable nodes`);
  return NAV;
}
function navNode(x,z) {
  if(!NAV)return null;
  const ix=Math.round((x-NAV.minX)/NAV.cell), iz=Math.round((z-NAV.minZ)/NAV.cell);
  let best=null,bd=Infinity;
  for(let r=0;r<=5&&!best;r++) for(let dz=-r;dz<=r;dz++)for(let dx=-r;dx<=r;dx++){
    if(Math.max(Math.abs(dx),Math.abs(dz))!==r)continue;
    const xx=ix+dx,zz=iz+dz;if(xx<0||zz<0||xx>=NAV.cols||zz>=NAV.rows)continue;
    const n=NAV.nodes[zz*NAV.cols+xx];if(!n)continue;
    const d=Math.hypot(n.x-x,n.z-z);if(d<bd){best=n;bd=d;}
  }
  return best;
}
function findBotPath(b,target) {
  const start=navNode(b.x,b.z), goal=navNode(target.x,target.z);
  if(!start||!goal)return [];
  const open=[start], came=new Map(), g=new Map([[start.id,0]]), f=new Map([[start.id,Math.hypot(goal.x-start.x,goal.z-start.z)]]), closed=new Set();
  while(open.length){
    let bi=0;for(let i=1;i<open.length;i++)if((f.get(open[i].id)??Infinity)<(f.get(open[bi].id)??Infinity))bi=i;
    const cur=open.splice(bi,1)[0];if(cur.id===goal.id){const path=[cur];let id=cur.id;while(came.has(id)){id=came.get(id);path.push(NAV.nodes[id]);}path.reverse();return path.slice(1);}
    if(closed.has(cur.id))continue;closed.add(cur.id);
    for(const e of cur.edges){const q=e.to;if(closed.has(q.id))continue;const ng=g.get(cur.id)+e.cost;if(ng<(g.get(q.id)??Infinity)){came.set(q.id,cur.id);g.set(q.id,ng);f.set(q.id,ng+Math.hypot(goal.x-q.x,goal.z-q.z));if(!open.some(n=>n.id===q.id))open.push(q);}}
  }
  return [];
}
try { if (COL && USE_MESH) buildNavGrid(); } catch(e) { console.error('[bot-nav] Could not build collision navigation grid:',e.message); NAV=null; }
function stepBots() {
  const now=Date.now();
  for(const b of players.values()) {
    if(!b.isBot||b.dead)continue;
    if(now < (b.botThinkAt||0))continue;
    b.botThinkAt=now+180+Math.random()*220;

    // Bots only acquire enemies they could plausibly see: limited field of view and a clear ray through map collision.
    const eye=[b.x,b.y+EYE,b.z], facing=[-Math.sin(b.yaw),0,-Math.cos(b.yaw)];
    let seen=null, seenDist=Infinity;
    for(const q of players.values()) {
      if(q===b||q.dead||q.team===b.team)continue;
      const dx=q.x-b.x,dz=q.z-b.z,d=Math.hypot(dx,dz);
      if(d>72 || d<0.1 || d>=seenDist)continue;
      const dot=(facing[0]*dx+facing[2]*dz)/d;
      // peripheral awareness is possible nearby; distant enemies must be in front.
      if(dot < (d<7 ? -0.15 : 0.22))continue;
      const aim=aimPoint(q,false);
      if(!lineClear(eye,aim))continue;
      seen=q;seenDist=d;
    }
    if(seen) {
      if(b.botTargetId!==seen.id) {
        b.botTargetId=seen.id;
        b.botReactAt=now+450+Math.random()*1050; // human-like reaction time; never fire on first sight
        b.botAimError=0.035+Math.random()*0.11;
      }
      b.botSeenAt=now;
      b.botLastSeen={x:seen.x,y:seen.y,z:seen.z,id:seen.id};
    }

    // Forget stale sightings. They may investigate the last known position, but never track a hidden enemy's live position.
    const memoryValid=b.botLastSeen && now-(b.botSeenAt||0)<4500;
    const target=seen || (memoryValid ? b.botLastSeen : null);
    if(!target) {
      b.botTargetId=null;b.botLastSeen=null;
      // Patrol in small independent bursts rather than all converging on a shared point.
      if(now>(b.botPauseUntil||0)) {
        if(now>(b.botNextPause||0) && Math.random()<0.45) {
          b.botPauseUntil=now+500+Math.random()*1800;
          b.botNextPause=now+3500+Math.random()*7500;
        } else {
          const here=navNode(b.x,b.z);
          if(here && NAV && (!b.navPath||!b.navPath.length||now>(b.navRepathAt||0))) {
            const candidates=[];
            for(let i=0;i<18;i++) { const n=NAV.nodes[Math.floor(Math.random()*NAV.nodes.length)]; if(n&&Math.hypot(n.x-b.x,n.z-b.z)>4)candidates.push(n); }
            if(candidates.length){const n=candidates[Math.floor(Math.random()*candidates.length)];b.navPath=findBotPath(b,n);b.navPathIndex=0;b.navRepathAt=now+2500+Math.random()*2500;}
          }
        }
      }
      let wp=b.navPath&&b.navPath[b.navPathIndex||0];
      if(wp&&Math.hypot(wp.x-b.x,wp.z-b.z)<0.65){b.navPathIndex=(b.navPathIndex||0)+1;wp=b.navPath[b.navPathIndex];}
      if(wp&&now>(b.botPauseUntil||0)) {
        const dx=wp.x-b.x,dz=wp.z-b.z,d=Math.hypot(dx,dz)||1;
        b.yaw=Math.atan2(-dx,-dz);
        const step=Math.min(SPEED*0.20,d);
        applyPose(b,{t:'m',x:b.x+dx/d*step,y:wp.y,z:b.z+dz/d*step,yaw:b.yaw,pitch:0,seq:++b.seq});
      }
      continue;
    }

    const dx=target.x-b.x,dz=target.z-b.z,dist=Math.hypot(dx,dz)||1;
    const canSee=!!seen;
    // Individual combat spacing: bots approach different offsets around the last known enemy position.
    let goalX=target.x,goalZ=target.z;
    if(seen) {
      const angle=(b.id*2.399963229728653) + Math.sin(now/2400+b.id)*0.5;
      const ring=4.5+(b.id%4)*1.4;
      goalX=seen.x+Math.cos(angle)*ring;goalZ=seen.z+Math.sin(angle)*ring;
    }
    if(canSee) {
      const aim=aimPoint(seen,false), ax=aim[0]-b.x, az=aim[2]-b.z;
      const idealYaw=Math.atan2(-ax,-az);
      const idealPitch=Math.atan2(aim[1]-(b.y+EYE),Math.max(.01,Math.hypot(ax,az)));
      // Aim gradually, with error that improves a little during sustained tracking but never becomes perfect.
      const err=b.botAimError||0.08;
      let yawDiff=((idealYaw-b.yaw+Math.PI*3)%(Math.PI*2))-Math.PI;
      b.yaw += clamp(yawDiff,-0.65,0.65);
      b.pitch=clamp(idealPitch+(Math.random()-0.5)*err,-1.25,1.25);
      b.yaw += (Math.random()-0.5)*err*0.28;
      b.botAimError=Math.max(0.025,err-(0.001+Math.random()*0.003));
    } else {
      // Search toward last seen position, not the target's current hidden position.
      b.yaw=Math.atan2(-dx,-dz);
      b.pitch=0;
    }

    if(now>(b.botPauseUntil||0)) {
      if(now>(b.botNextPause||0)&&Math.random()<0.13) {
        b.botPauseUntil=now+350+Math.random()*1100;
        b.botNextPause=now+2200+Math.random()*5000;
      }
      const gx=goalX-b.x,gz=goalZ-b.z,gd=Math.hypot(gx,gz)||1;
      const wantMove=(!canSee || dist>8) && gd>1.3;
      if(wantMove) {
        let wp=b.navPath&&b.navPath[b.navPathIndex||0];
        if(!b.navPath || now>(b.navRepathAt||0) || b.navTargetId!==target.id) {
          const navGoal={x:goalX,y:target.y,z:goalZ};
          b.navPath=findBotPath(b,navGoal);b.navPathIndex=0;b.navTargetId=target.id;b.navRepathAt=now+900+Math.random()*800;
          wp=b.navPath&&b.navPath[0];
        }
        if(wp&&Math.hypot(wp.x-b.x,wp.z-b.z)<0.65){b.navPathIndex=(b.navPathIndex||0)+1;wp=b.navPath[b.navPathIndex];}
        if(wp) {
          const wx=wp.x-b.x,wz=wp.z-b.z,wd=Math.hypot(wx,wz)||1;
          const step=Math.min(SPEED*0.18,wd);
          const beforeX=b.x,beforeZ=b.z;
          applyPose(b,{t:'m',x:b.x+wx/wd*step,y:wp.y,z:b.z+wz/wd*step,yaw:b.yaw,pitch:b.pitch,seq:++b.seq});
          if(Math.hypot(b.x-beforeX,b.z-beforeZ)<0.035)b.navRepathAt=now;
        }
      }
    }
    // Fire only at a currently visible enemy, after the reaction delay, and with deliberately imperfect aim.
    if(canSee && now>=(b.botReactAt||Infinity) && seenDist<RANGE && Math.random()<(seenDist<12?0.48:0.26)) {
      // Occasional bursts and pauses, with a small additional shot-to-shot miss offset.
      b.yaw+=(Math.random()-0.5)*(seenDist<10?0.10:0.19);
      b.pitch+=(Math.random()-0.5)*(seenDist<10?0.07:0.14);
      fire(b);
    }
  }
}
setInterval(stepBots, 100);
function roundInfo() { return { number: roundNumber, endsAt: roundStartedAt + ROUND_MS, remaining: Math.max(0, ROUND_MS - (Date.now() - roundStartedAt)) }; }

const rand = (min, max) => min + Math.random() * (max - min);
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const r2 = (v) => Math.round(v * 100) / 100;
const r3 = (v) => Math.round(v * 1000) / 1000;

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function cleanName(raw, id) {
  let name = typeof raw === 'string' ? raw : '';
  name = name.replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16);
  return name || `player${id}`;
}

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

function broadcast(obj, except) {
  const data = JSON.stringify(obj);
  for (const p of players.values()) {
    if (p !== except && p.ws && p.ws.readyState === 1) p.ws.send(data);
  }
}

// spawn point farthest from every living player
// returns [x, z, y]
function pickSpawn(self) {
  // never spawn on top of a living player while a free spot exists (the jitter below could otherwise pick an occupied one)
  const fallbackT = ACTIVE_MAP === 'dust2' ? MAPS.DUST2_T_SPAWNS : MAPS.NEON_T_SPAWNS;
  const fallbackCT = ACTIVE_MAP === 'dust2' ? MAPS.DUST2_CT_SPAWNS : MAPS.NEON_CT_SPAWNS;
  const teamSpawns = USE_MESH ? (self && self.team === 'CT' ? MESH_CT_SPAWNS : MESH_T_SPAWNS) : (self && self.team === 'CT' ? fallbackCT : fallbackT).map(([x,z]) => [x,z,0]);
  const preferred = teamSpawns.length ? teamSpawns : SPAWN_LIST;
  const free = preferred.filter((s) => {
    for (const q of players.values()) if (q !== self && !q.dead && Math.hypot(q.x - s[0], q.z - s[1]) < 1.2) return false;
    return true;
  });
  const list = free.length ? free : preferred;
  let best = list[0];
  let bestScore = -1;
  for (const s of list) {
    let nearest = Infinity;
    for (const q of players.values()) {
      if (q === self || q.dead) continue;
      nearest = Math.min(nearest, Math.hypot(q.x - s[0], q.z - s[1]));
    }
    const score = (nearest === Infinity ? 100 : nearest) + Math.random() * 8;
    if (score > bestScore) { bestScore = score; best = s; }
  }
  return best;
}

function respawn(p, keepHp) {
  const [x, z, y] = pickSpawn(p);
  p.x = x; p.y = y; p.z = z;
  p.gy = y; p.air = 0;
  p.yaw = Math.atan2(x, z); // face the arena centre
  p.pitch = 0;
  if (!keepHp) p.hp = MAX_HP; // the stuck rescue keeps your hp (no free heal)
  p.dead = false;
  p.ammo = 30; p.reserve = 90; p.reloadUntil = 0; p.hasWeapon = true;
  p.seq++;                  // invalidates stale pose messages still in flight
  p.lastMove = Date.now();
  p.ax = x; p.ay = y; p.az = z; p.stillSince = p.lastMove; // "has not moved" bookkeeping for the stuck rescue
  send(p.ws, { t: 'rs', x, y, z, yaw: r3(p.yaw), seq: p.seq, hp: p.hp });
}

// ---- stuck rescue ---------------------------------------------------------------
// Known problem of the real mesh: ~0.06% of moves end wedged in a slot narrower than the body. The client notices
// "movement keys held but no movement" and sends {t:'stuck'}; the server then respawns that player (same flow as a
// normal respawn, hp is kept). Refused when: dead, within 10 s of the last rescue, damaged in the last 5 s (cannot be
// used to dodge a fight), or the server itself has seen the player move in the last 1.5 s (not stuck).
const STUCK_COOLDOWN_MS = 10000, STUCK_DAMAGE_MS = 5000, STUCK_STILL_MS = 1500, STUCK_MOVE = 0.2;
function rescueStuck(p) {
  const now = Date.now();
  let why = null;
  if (p.dead) why = 'dead';
  else if (now - p.lastStuck < STUCK_COOLDOWN_MS) why = 'cooldown';
  else if (now - p.lastDamaged < STUCK_DAMAGE_MS) why = 'damaged';
  else if (now - p.stillSince < STUCK_STILL_MS) why = 'moving';
  if (why) { send(p.ws, { t: 'stuckno', why }); return false; }
  p.lastStuck = now;
  console.log(`[stuck] ${p.name} (#${p.id}) rescued at (${r2(p.x)}, ${r2(p.y)}, ${r2(p.z)})`);
  respawn(p, true);
  return true;
}

// The client owns its own movement (so it feels instant); the server just
// sanity-checks it: arena bounds, the mesh walls/floors, max speed.
const MESH_OUT = { x: 0, y: 0, z: 0, corrected: false, lost: false };
function applyPose(p, m) {
  if (p.dead || m.seq !== p.seq) return false;
  const x = num(m.x), y = num(m.y), z = num(m.z), yaw = num(m.yaw), pitch = num(m.pitch);
  if (x === null || y === null || z === null || yaw === null || pitch === null) return false;

  const now = Date.now();
  const dt = Math.min((now - p.lastMove) / 1000, 0.25);
  p.lastMove = now;

  let nx = clamp(x, -ARENA + PLAYER_R, ARENA - PLAYER_R);
  let nz = clamp(z, -ARENA + PLAYER_R, ARENA - PLAYER_R);
  const dx = nx - p.x, dz = nz - p.z;
  const d = Math.hypot(dx, dz);
  const maxD = SPEED * 1.5 * dt + 1.0;
  if (d > maxD) { nx = p.x + (dx / d) * maxD; nz = p.z + (dz / d) * maxD; }

  let ny;
  if (USE_MESH) {
    // real map: sweep from the last accepted position (walls can't be crossed), accept the client's position when it
    // is within tolerance of that, and keep y between the floor below and a jump above it (see collision.js)
    const o = MESH_OUT;
    COL.validatePose(p, nx, y, nz, dt, o);
    nx = o.x; ny = o.y; nz = o.z;
    if (o.lost) { // fell off the map edge / through a hole: put the player back on a spawn point
      p.lastMove = now;
      respawn(p);
      return false;
    }
  } else {
    ny = clamp(y, 0, 3); // flat fallback arena: floor at 0, jump up to 3
  }

  p.x = nx; p.z = nz;
  p.y = ny;
  if (Math.hypot(nx - p.ax, nz - p.az) > STUCK_MOVE || Math.abs(ny - p.ay) > STUCK_MOVE) { p.ax = nx; p.ay = ny; p.az = nz; p.stillSince = now; }
  p.yaw = yaw;
  p.pitch = clamp(pitch, -1.55, 1.55);
  p.pad = m.pad === 1;
  p.crouch = m.c === 1 ? 1 : 0;   // crouching: lower eye and hit areas (CROUCH below)
  return true;
}

const CROUCH = 0.6;    // crouched eye height and hit-area height relative to standing (client: 1 - CROUCH_EYE)
const crouchF = (q) => (q.crouch ? CROUCH : 1);

// model hit shapes: model units -> metres, and the avatar is drawn at 1 - 0.36 of its height while crouching (client: r.g.scale.y)
const HIT_SCALE = DIMS.s * 1.8;
const HIT_CROUCH = 0.64;
const hitShape = (q) => (HB ? HB.forName(q.name) : null);

// First hit of the ray o + t*d (d unit length) on player q before t = maxT: { t, head } or null.
function hitPlayer(o, d, q, maxT) {
  const hb = hitShape(q);
  if (!hb) {   // old spheres (also used when a model has no usable mesh)
    const th = raySphere(o, d, [q.x, q.y + DIMS.headY * crouchF(q), q.z], DIMS.headR);
    const tb = raySphere(o, d, [q.x, q.y + DIMS.bodyY * crouchF(q), q.z], DIMS.bodyR);
    const t = Math.min(th, tb);
    return t < maxT ? { t, head: th <= tb } : null;
  }
  // into the player's frame (undo the yaw), then into model units; t stays the same because the map is affine
  const S = HIT_SCALE, cf = q.crouch ? HIT_CROUCH : 1, c = Math.cos(q.yaw), s = Math.sin(q.yaw);
  const rx = o[0] - q.x, ry = o[1] - q.y, rz = o[2] - q.z;
  return rayModel(hb, (rx * c - rz * s) / S, ry / (S * cf), (rx * s + rz * c) / S,
    (d[0] * c - d[2] * s) / S, d[1] / (S * cf), (d[0] * s + d[2] * c) / S, maxT);
}

// world position the assist / aimbot aims at: the middle of the model's head or body (the old sphere heights without a model shape)
function aimPoint(q, head) {
  const hb = hitShape(q);
  if (!hb) return [q.x, q.y + (head ? DIMS.headY : DIMS.aimLowY) * crouchF(q), q.z];
  const a = head ? hb.headAim : hb.bodyAim, S = HIT_SCALE, cf = q.crouch ? HIT_CROUCH : 1, c = Math.cos(q.yaw), s = Math.sin(q.yaw);
  const lx = a[0] * S, lz = a[2] * S;
  return [q.x + lx * c + lz * s, q.y + a[1] * S * cf, q.z - lx * s + lz * c];
}

// ---- hitscan ------------------------------------------------------------
// Distance a bullet travels from o along the normalized direction d before it hits the world (Infinity = nothing).
// Real map: nearest mesh triangle (flat or steep, double sided). Flat fallback: the floor y = 0 and the 4 outer walls.
function worldHit(o, d, maxT) {
  if (USE_MESH) return COL.raycast(o[0], o[1], o[2], d[0], d[1], d[2], maxT);
  let best = maxT;
  if (d[1] < -1e-6) best = Math.min(best, -o[1] / d[1]);
  for (let i = 0; i < 3; i += 2) {
    if (d[i] > 1e-9) best = Math.min(best, (ARENA - o[i]) / d[i]);
    else if (d[i] < -1e-9) best = Math.min(best, (-ARENA - o[i]) / d[i]);
  }
  return best;
}

// is the straight line from o to point q free of walls?
function lineClear(o, q) {
  const dx = q[0] - o[0], dy = q[1] - o[1], dz = q[2] - o[2];
  const L = Math.hypot(dx, dy, dz);
  if (!(L > 1e-6)) return true;
  return worldHit(o, [dx / L, dy / L, dz / L], L - 0.02) >= L - 0.02; // Infinity (mesh) or maxT (flat) = nothing in the way
}

function raySphere(o, d, c, r) {
  const ox = o[0] - c[0], oy = o[1] - c[1], oz = o[2] - c[2];
  const b = ox * d[0] + oy * d[1] + oz * d[2];
  const cc = ox * ox + oy * oy + oz * oz - r * r;
  const disc = b * b - cc;
  if (disc < 0) return Infinity;
  const t = -b - Math.sqrt(disc);
  return t >= 0 ? t : Infinity;
}

// ---- aim settings (controlled from the admin panel) -------------------------
// off    : shots go exactly where the player aims
// assist : shots bend toward an enemy that is already near the crosshair (upper body)
// aimbot : shots snap to the nearest enemy in line of sight (head)
// Set globally, with an optional per-player override.
const AIM_MODES = ['off', 'assist', 'aimbot'];
const settings = { mode: 'off', strength: 0.5 }; // strength (0.05-1) only affects 'assist'
const effectiveMode = (p) => p.aim || (p.pad ? 'aimbot' : settings.mode); // controller players get aimbot

function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ha = crypto.createHash('sha256').update(a).digest();
  const hb = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

const adminFails = []; // timestamps of recent wrong passwords (all connections)
function adminThrottled() {
  const now = Date.now();
  while (adminFails.length && now - adminFails[0] > 60000) adminFails.shift();
  return adminFails.length >= 10;
}

function sendAim(p) {
  send(p.ws, { t: 'aim', mode: effectiveMode(p), strength: settings.strength });
}

function adminState() {
  const over = {};
  for (const q of players.values()) if (q.aim) over[q.id] = q.aim;
  return { t: 'as', mode: settings.mode, strength: settings.strength, over };
}

function aimChanged() {
  const st = adminState();
  for (const q of players.values()) {
    sendAim(q);
    if (q.isAdmin) send(q.ws, st);
  }
}

// Returns the (possibly corrected) shot direction for this player's aim mode.
function aimCorrect(p, o, d) {
  // Bots must use their own imperfect aim; never apply player aim-assist/aimbot correction to them.
  if (p.isBot) return d;
  const mode = effectiveMode(p);
  if (mode === 'off') return d;

  let best = null;
  let bestScore = Infinity;
  for (const q of players.values()) {
    if (q === p || q.dead || q.team === p.team) continue;
    const ap = aimPoint(q, mode === 'aimbot');
    const v = [ap[0] - o[0], ap[1] - o[1], ap[2] - o[2]];
    const dist = Math.hypot(v[0], v[1], v[2]);
    if (dist < 0.5 || dist > RANGE) continue;
    const u = [v[0] / dist, v[1] / dist, v[2] / dist];

    let score;
    if (mode === 'assist') {
      const ang = Math.acos(clamp(d[0] * u[0] + d[1] * u[1] + d[2] * u[2], -1, 1));
      if (ang > 0.03 + 0.15 * settings.strength) continue; // outside the assist cone
      score = ang;
    } else {
      score = dist;                                         // aimbot: nearest wins
    }
    if (score >= bestScore) continue;

    if (!lineClear(o, [o[0] + v[0], o[1] + v[1], o[2] + v[2]])) continue; // a wall (mesh) in the way: no lock
    best = u; bestScore = score;
  }
  if (!best) return d;
  if (mode === 'aimbot') return best;

  const k = settings.strength * 0.9;                        // assist: blend toward target
  const n = [d[0] + (best[0] - d[0]) * k, d[1] + (best[1] - d[1]) * k, d[2] + (best[2] - d[2]) * k];
  const len = Math.hypot(n[0], n[1], n[2]) || 1;
  return [n[0] / len, n[1] / len, n[2] / len];
}

function dropWeapon(p, vx = 0, vy = 1.8, vz = 0) {
  if (!p.hasWeapon) return null;
  const now = Date.now();
  const w = { id: nextWeaponId++, x: p.x, y: p.y + 0.9, z: p.z, vx, vy, vz,
    yaw: p.yaw, ammo: p.ammo ?? 30, reserve: p.reserve ?? 90, team: p.team,
    createdAt: now, settledAt: 0, frozen: false, expiresAt: now + WEAPON_LIFETIME };
  droppedWeapons.set(w.id, w);
  p.hasWeapon = false; p.ammo = 0; p.reserve = 0; p.reloadUntil = 0;
  broadcast({ t: 'wd', w: weaponWire(w) });
  return w;
}
function weaponWire(w) { return { id:w.id, x:r2(w.x), y:r2(w.y), z:r2(w.z), yaw:r3(w.yaw), frozen:!!w.frozen, ammo:w.ammo, reserve:w.reserve }; }
function pickupWeapon(p, w) {
  if (!w || !droppedWeapons.has(w.id) || p.dead) return false;
  if (p.hasWeapon) {
    // Swap: the currently held gun is dropped where the player is, then the ground gun is equipped.
    const oldAmmo = p.ammo, oldReserve = p.reserve;
    const old = { ...p, ammo: oldAmmo, reserve: oldReserve };
    const now = Date.now();
    const nw = { id: nextWeaponId++, x:p.x, y:p.y + 0.9, z:p.z, vx:Math.sin(p.yaw)*1.4, vy:1.4, vz:Math.cos(p.yaw)*1.4,
      yaw:p.yaw, ammo:oldAmmo, reserve:oldReserve, team:p.team, createdAt:now, settledAt:0, frozen:false, expiresAt:now+WEAPON_LIFETIME };
    droppedWeapons.set(nw.id, nw);
    broadcast({ t:'wd', w:weaponWire(nw) });
  }
  droppedWeapons.delete(w.id);
  p.hasWeapon = true; p.ammo = w.ammo; p.reserve = w.reserve; p.reloadUntil = 0;
  broadcast({ t:'wp', id:p.id, picked:w.id, hasWeapon:true, ammo:p.ammo, reserve:p.reserve });
  return true;
}
function interactWeapon(p) {
  if (p.dead) return;
  let nearest = null, dist = WEAPON_PICKUP_RADIUS;
  for (const w of droppedWeapons.values()) {
    const d = Math.hypot(p.x-w.x, p.z-w.z);
    if (d < dist) { dist=d; nearest=w; }
  }
  if (nearest) { pickupWeapon(p, nearest); return; }
  if (p.hasWeapon) dropWeapon(p, -Math.sin(p.yaw)*1.5, 1.7, -Math.cos(p.yaw)*1.5);
}
function stepDroppedWeapons() {
  const now = Date.now(), dt = 0.05;
  for (const w of droppedWeapons.values()) {
    if (now >= w.expiresAt) { droppedWeapons.delete(w.id); broadcast({t:'wr', id:w.id}); continue; }
    if (w.frozen) continue;
    w.vy -= 9.81 * dt;
    w.x += w.vx * dt; w.y += w.vy * dt; w.z += w.vz * dt;
    w.vx *= 0.985; w.vz *= 0.985;
    let floor = USE_MESH ? COL.floorY(w.x, w.z, w.y + 1, 0) : 0;
    if (!Number.isFinite(floor) || floor === -Infinity) floor = 0;
    if (w.y <= floor + 0.12) { w.y = floor + 0.12; if (Math.abs(w.vy) > 0.8) w.vy = Math.abs(w.vy)*0.22; else w.vy=0; w.vx*=0.65; w.vz*=0.65; }
    const speed = Math.hypot(w.vx,w.vy,w.vz);
    if (speed < 0.12) { if (!w.settledAt) w.settledAt=now; if (now-w.settledAt >= WEAPON_FREEZE_DELAY) { w.frozen=true; w.vx=w.vy=w.vz=0; broadcast({t:'wf', id:w.id, frozen:true}); } }
    else w.settledAt=0;
  }
}
setInterval(stepDroppedWeapons, 50);
function finishRound() {
  const c = { T:0, CT:0 };
  for (const p of players.values()) c[p.team] += p.kills;
  const winner = c.T === c.CT ? 'draw' : c.T > c.CT ? 'T' : 'CT';
  roundNumber++; roundStartedAt = Date.now();
  broadcast({ t:'re', number:roundNumber, winner, score:c, duration:ROUND_MS });
  for (const p of players.values()) { p.kills=0; p.deaths=0; if (p.respawnTimer) { clearTimeout(p.respawnTimer); p.respawnTimer=null; } respawn(p); }
  for (const w of droppedWeapons.values()) broadcast({t:'wr',id:w.id});
  droppedWeapons.clear();
}
setInterval(() => { if (players.size && Date.now()-roundStartedAt >= ROUND_MS) finishRound(); }, 250);

function damage(victim, killer, dmg, head) {
  victim.hp -= dmg;
  victim.lastDamaged = Date.now();
  const dead = victim.hp <= 0;
  send(victim.ws, { t: 'dmg', hp: Math.max(0, victim.hp), from: killer.id });
  send(killer.ws, { t: 'hm', h: head ? 1 : 0, k: dead ? 1 : 0 });
  if (!dead) return;

  victim.hp = 0;
  dropWeapon(victim, -Math.sin(victim.yaw)*1.8, 2.2, -Math.cos(victim.yaw)*1.8);
  victim.dead = true;
  victim.deaths++;
  killer.kills++;
  broadcast({ t: 'kill', k: killer.id, v: victim.id, h: head ? 1 : 0, x:victim.x, y:victim.y, z:victim.z, yaw:victim.yaw, team:victim.team });
  victim.respawnTimer = setTimeout(() => {
    victim.respawnTimer = null;
    if (players.get(victim.id) === victim) respawn(victim);
  }, RESPAWN_MS);
}

function fire(p) {
  const now = Date.now();
  if (p.dead || !p.hasWeapon || (p.reloadUntil || 0) > now || (p.ammo ?? 30) <= 0 || now - p.lastFire < FIRE_MS - 20) return;
  p.lastFire = now;
  p.ammo = (p.ammo ?? 30) - 1;

  const cp = Math.cos(p.pitch);
  let d = [-Math.sin(p.yaw) * cp, Math.sin(p.pitch), -Math.cos(p.yaw) * cp];
  const o = [p.x, p.y + EYE * crouchF(p), p.z];
  d = aimCorrect(p, o, d);

  // how far the bullet travels before hitting the world
  let best = Math.min(RANGE, worldHit(o, d, RANGE));

  let victim = null;
  let head = false;
  for (const q of players.values()) {
    if (q === p || q.dead || q.team === p.team) continue;
    const h = hitPlayer(o, d, q, best);
    if (h && h.t < best) { best = h.t; victim = q; head = h.head; }
  }

  broadcast({
    t: 'tr',
    s: p.id,   // who fired (the client starts the tracer at that player's gun)
    f: [r2(o[0]), r2(o[1]), r2(o[2])],
    e: [r2(o[0] + d[0] * best), r2(o[1] + d[1] * best), r2(o[2] + d[2] * best)],
  });

  if (victim) damage(victim, p, head ? HEAD_DMG : BODY_DMG, head);
}

// ---- websocket ----------------------------------------------------------
const wss = new WebSocketServer({ server, maxPayload: 1024 });

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.player = null;
  let msgCount = 0;
  const rateTimer = setInterval(() => { msgCount = 0; }, 1000);

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (raw) => {
    if (++msgCount > MAX_MSGS_PER_SEC) {
      ws.close(1008, 'rate limit');
      return;
    }
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!msg || typeof msg.t !== 'string') return;

    if (msg.t === 'join' && !ws.player) {
      if (players.size >= MAX_PLAYERS && botCount()) replaceBotForJoin(msg.team);
      else if (botCount()) replaceBotForJoin(msg.team);
      if (players.size >= MAX_PLAYERS) {
        send(ws, { t: 'full' });
        ws.close();
        return;
      }
      const id = nextPlayerId++;
      if (players.size === 0) roundStartedAt = Date.now();
      const p = {
        id, ws, team: assignTeam(msg.team), hasWeapon: true,
        name: cleanName(msg.name, id),
        hue: Math.floor(rand(0, 360)),
        x: 0, y: 0, z: 0, yaw: 0, pitch: 0, gy: 0, air: 0,
        hp: MAX_HP, ammo: 30, reserve: 90, reloadUntil: 0, kills: 0, deaths: 0,
        dead: false, seq: 0, lastMove: Date.now(), lastFire: 0, respawnTimer: null,
        aim: null, isAdmin: false, adminTries: 0,
        lastDamaged: 0, lastStuck: 0, ax: 0, ay: 0, az: 0, stillSince: Date.now(),
      };
      const [sx, sz, sy] = pickSpawn(p);
      p.x = sx; p.y = sy; p.gy = sy; p.z = sz; p.yaw = Math.atan2(sx, sz);
      p.ax = sx; p.ay = sy; p.az = sz;
      players.set(id, p);
      ws.player = p;

      send(ws, {
        t: 'welcome',
        id,
        world: { arena: ARENA, r: PLAYER_R, h: PLAYER_H, sites: SITES_OUT, map: USE_MESH ? ACTIVE_MAP : 'flat' },
        you: { x: p.x, y: p.y, z: p.z, yaw: r3(p.yaw), seq: p.seq },
        cfg: { maxHp: MAX_HP, fireMs: FIRE_MS },
        aim: { mode: effectiveMode(p), strength: settings.strength },
        team: p.team, teams:teamCounts(), round: roundInfo(), weapons: [...droppedWeapons.values()].map(weaponWire),
        roster: [...players.values()].map((q) => [q.id, q.name, q.hue, q.team]),
      });
      broadcast({ t: 'join', id, name: p.name, hue: p.hue, team:p.team }, p);
      maintainBots();
    } else if (msg.t === 'team' && ws.player) {
      setPlayerTeam(ws.player, msg.team);
    } else if (msg.t === 'm' && ws.player) {
      applyPose(ws.player, msg);
    } else if (msg.t === 'f' && ws.player) {
      if (applyPose(ws.player, msg)) fire(ws.player);
    } else if (msg.t === 'r' && ws.player) {
      const p = ws.player, now = Date.now();
      if (!p.dead && p.hasWeapon && !(p.reloadUntil > now) && (p.ammo ?? 30) < 30 && (p.reserve ?? 90) > 0) {
        p.reloadUntil = now + 1900;
        const finish = p.reloadUntil;
        setTimeout(() => {
          if (players.get(p.id) !== p || p.dead || p.reloadUntil !== finish) return;
          const need = 30 - (p.ammo ?? 0), take = Math.min(need, p.reserve ?? 0);
          p.ammo = (p.ammo ?? 0) + take; p.reserve = (p.reserve ?? 0) - take; p.reloadUntil = 0;
        }, 1900);
      }
    } else if (msg.t === 'g' && ws.player) {
      interactWeapon(ws.player);
    } else if (msg.t === 'stuck' && ws.player) {
      rescueStuck(ws.player);
    } else if (msg.t === 'admin' && ws.player) {
      const p = ws.player;
      if (p.isAdmin) { send(ws, { t: 'admin', ok: true }); send(ws, adminState()); return; }
      if (adminThrottled() || p.adminTries >= 5) { send(ws, { t: 'admin', ok: false, msg: 'Too many attempts, wait a minute.' }); return; }
      if (safeEqual(msg.pw, ADMIN_PASSWORD)) {
        p.isAdmin = true;
        console.log(`[admin] ${p.name} (#${p.id}) logged in`);
        send(ws, { t: 'admin', ok: true });
        send(ws, adminState());
      } else {
        p.adminTries++;
        adminFails.push(Date.now());
        send(ws, { t: 'admin', ok: false, msg: 'Wrong password.' });
      }
    } else if (msg.t === 'aset' && ws.player && ws.player.isAdmin) {
      if (AIM_MODES.includes(msg.mode)) settings.mode = msg.mode;
      const st = num(msg.strength);
      if (st !== null) settings.strength = clamp(st, 0.05, 1);
      console.log(`[admin] aim mode=${settings.mode} strength=${settings.strength}`);
      aimChanged();
    } else if (msg.t === 'apl' && ws.player && ws.player.isAdmin) {
      const q = players.get(num(msg.id));
      if (q && (msg.mode === 'default' || AIM_MODES.includes(msg.mode))) {
        q.aim = msg.mode === 'default' ? null : msg.mode;
        console.log(`[admin] ${q.name} (#${q.id}) aim override=${q.aim || 'default'}`);
        aimChanged();
      }
    }
  });

  ws.on('close', () => {
    clearInterval(rateTimer);
    const p = ws.player;
    if (p) {
      if (p.respawnTimer) clearTimeout(p.respawnTimer);
      players.delete(p.id);
      broadcast({ t: 'leave', id: p.id });
      maintainBots();
    }
  });

  ws.on('error', () => {});
});

// drop dead connections (e.g. phone went to sleep)
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 15000);

// ---- state broadcast ----------------------------------------------------
setInterval(() => {
  if (players.size === 0) return;
  const data = JSON.stringify({
    t: 's', round:roundInfo(), weapons:[...droppedWeapons.values()].map(weaponWire),
    p: [...players.values()].map((p) => [
      p.id, r2(p.x), r2(p.y), r2(p.z), r3(p.yaw), r3(p.pitch), p.hp, p.kills, p.deaths, p.crouch ? 1 : 0, p.team, p.hasWeapon ? 1 : 0, p.dead ? 1 : 0,
    ]),
  });
  for (const p of players.values()) {
    if (p.ws && p.ws.readyState === 1) p.ws.send(data);
  }
}, 1000 / TICK_RATE);

server.listen(PORT, HOST, () => {
  // Panels mark a server "online" when the console prints a line matching the egg's
  // startup "done" string, so print the common ones.
  console.log(`Shitteh Arena running on http://${HOST}:${PORT}`);
  console.log(`Server started - listening on port ${PORT}`);
  if (ADMIN_PW_GENERATED) console.log(`Admin password (random this run, set ADMIN_PASSWORD to choose your own): ${ADMIN_PASSWORD}`);
  else console.log('Admin panel enabled (password from ADMIN_PASSWORD).');
  console.log(`Point your Cloudflare tunnel at it: play.okeyhi.com -> http://<this server's IP>:${PORT}`);
});

// exposed for tests only
module.exports = { server, players, rescueStuck };
