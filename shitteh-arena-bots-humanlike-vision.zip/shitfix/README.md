# Shitteh Arena — Neon Arena

Playable browser-based 3D free-for-all arena with a real-time WebSocket server. Neon Arena is the active map; the included GLB and collision mesh are used by the client and server.

## Start locally

Requirements: Node.js 18 or newer, plus an internet connection on first load (Three.js is loaded from jsDelivr).

1. Open a terminal in this `game` folder.
2. Run `npm install` once.
3. Run `npm start`.
4. Open `http://localhost:27043` in a browser.

To host for other players, set `HOST=0.0.0.0` and `PORT` to the port your host provides, then expose that port. The browser needs WebSocket access to the same host/port.

## Controls

- **WASD** move
- **Mouse** aim (click the game to lock the pointer)
- **Left mouse** shoot
- **Space** jump
- **C** or **Left Ctrl** crouch
- **Esc** release the mouse

Enter a player name and press **Play** to join the free-for-all match. The game server handles movement validation, hit detection, health and respawning.

## Included assets

- `public/maps/map.glb` — Neon Arena visual map
- `public/maps/map.collision.json` — server/client collision mesh
- `public/maps/map.meta.json` — map loader metadata
- `public/models/` — character and weapon models

No setup-pending placeholder is used by this build. If the page cannot load the 3D engine, check network access to jsDelivr; if the game cannot connect, confirm the Node server is running and the selected port is reachable.
\n\nMap status: Neon Arena is the active playable map. Dust 2 assets (GLB, collision JSON, metadata, and thumbnail) are preserved in `public/maps/`, but the in-game map selector does not switch gameplay maps yet.\n

## Playable maps

Both Dust 2 and Neon Arena have visual and collision meshes and are supported by the server. The server-wide active map is selected with `activeMap` in `config.json` (`dust2` or `neon`); this build defaults to `dust2`. Restart the server after changing it so collision, spawns, sites, and client visuals all match.


## Map switching

Select **Dust 2** or **Neon Arena** in the map cards, then press **GO**. If the selected map differs from the server map, the server saves the selection and relaunches itself so the collision mesh, spawn points, and world state all match. The page reloads after the restart; press **GO** again to join.
