// Entry point for panels whose Node egg defaults to index.js.
require('./server.js');
