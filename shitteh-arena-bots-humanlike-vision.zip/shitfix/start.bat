@echo off
cd /d "%~dp0"
if not exist node_modules call npm install
if errorlevel 1 exit /b %errorlevel%
call npm start
