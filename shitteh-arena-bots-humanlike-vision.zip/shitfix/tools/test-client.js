'use strict';
// Client check in headless Chromium against the REAL server and REAL public/ files.
//   NODE_PATH=<dir with ws and playwright-core> node tools/test-client.js
// three.js is loaded from a CDN, which the sandbox cannot reach, so `three` and GLTFLoader are replaced by a STUB
// (a permissive Proxy that records camera.position.set calls into window.__cam). This tests the client LOGIC
// (map + collision loading, movement through the shared module, fallback paths), NOT the real rendering.
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const Collision = require('../public/shared/collision.js');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const WebSocket = require('ws');
const { chromium } = require('playwright-core');

const PORT = 29000 + Math.floor(Math.random() * 900);
const root = path.join(__dirname, '..');
const srv = spawn('node', [path.join(root, 'server.js')], { env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', ADMIN_PASSWORD: 'x' }, stdio: ['ignore', 'pipe', 'pipe'] });
let srvLog = '';
srv.stdout.on('data', (d) => { srvLog += d; });
srv.stderr.on('data', (d) => { srvLog += d; });

// second server for the failure path: a copy of the project WITHOUT public/maps (no collision json) -> flat fallback arena
const FLAT_DIR = path.join(require('os').tmpdir(), 'shitteh-flat-' + process.pid);
fs.mkdirSync(path.join(FLAT_DIR, 'public', 'shared'), { recursive: true });
for (const f of ['server.js', 'map.js']) fs.copyFileSync(path.join(root, f), path.join(FLAT_DIR, f));
fs.copyFileSync(path.join(root, 'public', 'index.html'), path.join(FLAT_DIR, 'public', 'index.html'));
fs.copyFileSync(path.join(root, 'public', 'shared', 'collision.js'), path.join(FLAT_DIR, 'public', 'shared', 'collision.js'));
const FLAT_PORT = PORT + 1000;
const srvFlat = spawn('node', [path.join(FLAT_DIR, 'server.js')], { env: { ...process.env, PORT: String(FLAT_PORT), HOST: '127.0.0.1', ADMIN_PASSWORD: 'x' }, stdio: ['ignore', 'pipe', 'pipe'] });
let flatLog = '';
srvFlat.stdout.on('data', (d) => { flatLog += d; });
srvFlat.stderr.on('data', (d) => { flatLog += d; });

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const THREE_STUB = `
const mk = () => { const f = function () {}; return new Proxy(f, H); };
const H = {
  get(t, p) { if (p === 'then' || typeof p === 'symbol') return undefined; if (p in t && p !== 'name' && p !== 'length') return t[p]; return (t[p] = mk()); },
  set(t, p, v) { Object.defineProperty(t, p, { value: v, writable: true, configurable: true, enumerable: true }); return true; },
  apply() { return mk(); },
  construct() { return mk(); },
};
const names = 'Mesh MeshLambertMaterial BoxGeometry MeshBasicMaterial PlaneGeometry Group Vector3 LineBasicMaterial Color CanvasTexture SpriteMaterial Sprite SphereGeometry Scene LineSegments Line HemisphereLight GridHelper Fog EdgesGeometry DirectionalLight CapsuleGeometry BufferGeometry OrthographicCamera'.split(' ');
const ex = {};
for (const n of names) ex[n] = function () { return mk(); };
// Mesh and Sprite record where they were placed (window.__placed) so the test can inspect the site markers
window.__placed = [];
const HN = { ...H, get(t, p) { if (p === 'name') return t.__nm; return H.get(t, p); }, set(t, p, v) { if (p === 'name') { t.__nm = v; return true; } return H.set(t, p, v); } };
for (const n of ['Mesh', 'Sprite']) ex[n] = function () {
  const o = new Proxy(function () {}, HN);
  o.position = { x: 0, y: 0, z: 0, set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } };
  window.__placed.push(o);
  return o;
};
export const Mesh = ex.Mesh, MeshLambertMaterial = ex.MeshLambertMaterial, BoxGeometry = ex.BoxGeometry, MeshBasicMaterial = ex.MeshBasicMaterial,
  PlaneGeometry = ex.PlaneGeometry, Group = ex.Group, Vector3 = ex.Vector3, LineBasicMaterial = ex.LineBasicMaterial, Color = ex.Color,
  CanvasTexture = ex.CanvasTexture, SpriteMaterial = ex.SpriteMaterial, Sprite = ex.Sprite, SphereGeometry = ex.SphereGeometry, Scene = ex.Scene,
  LineSegments = ex.LineSegments, Line = ex.Line, HemisphereLight = ex.HemisphereLight, GridHelper = ex.GridHelper, Fog = ex.Fog,
  EdgesGeometry = ex.EdgesGeometry, DirectionalLight = ex.DirectionalLight, CapsuleGeometry = ex.CapsuleGeometry, BufferGeometry = ex.BufferGeometry, OrthographicCamera = ex.OrthographicCamera;
export const SRGBColorSpace = 'srgb', LinearMipmapLinearFilter = 1, LinearFilter = 2, DoubleSide = 2, PCFSoftShadowMap = 2;
export function PerspectiveCamera() {
  const pos = { x: 0, y: 0, z: 0, set(x, y, z) { pos.x = x; pos.y = y; pos.z = z; window.__cam = [x, y, z]; window.__camN = (window.__camN || 0) + 1; return pos; } };
  const o = mk(); o.position = pos; return o;
}
export function WebGLRenderer() {
  const c = document.createElement('canvas');
  const o = mk(); o.domElement = c; o.setSize = () => {}; o.setPixelRatio = () => {}; o.render = () => {};
  o.capabilities = { getMaxAnisotropy: () => 4, maxTextureSize: 4096 }; return o;
}
window.__three_ok = true;
`;
const GLTF_STUB = `
import { Group } from 'three';
export class GLTFLoader {
  async loadAsync(url, onProgress) {
    const r = await fetch(url); const b = await r.arrayBuffer();
    if (onProgress && window.__slowGlb) { onProgress({ lengthComputable: true, loaded: Math.floor(b.byteLength / 2), total: b.byteLength }); await new Promise((r) => setTimeout(r, 2500)); }
    if (onProgress) onProgress({ lengthComputable: true, loaded: b.byteLength, total: b.byteLength });
    window.__glbBytes = b.byteLength;
    return { scene: new Group() };
  }
}
`;

// wraps the page's WebSocket: records every non-pose message the client sends (window.__sent), counts real 'rs' messages and
// lets the test inject fake server messages (window.__inject) - used to put the player next to a wall for the stuck test
const WS_HOOK = `(() => {
  const NativeWS = window.WebSocket; window.__ws = null; window.__sent = []; window.__rsReal = 0; window.__lastSeq = 0;
  window.WebSocket = function (...a) {
    const w = new NativeWS(...a); window.__ws = w; const send = w.send.bind(w);
    w.send = (d) => { try { const j = JSON.parse(d); if (j.t !== 'm') window.__sent.push(j.t); } catch {} return send(d); };
    w.addEventListener('message', (ev) => { try { const m = JSON.parse(ev.data); 
      if (m.t === 'welcome') window.__lastSeq = m.you.seq;
      if (m.t === 'stuckno') (window.__no = window.__no || []).push(m.why);
      if (m.t === 'rs') { window.__lastSeq = m.seq; if (!m.__inj) { window.__rsReal++; window.__lastRs = m; } } } catch {} });
    return w;
  };
  window.WebSocket.prototype = NativeWS.prototype; Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });
  window.__inject = (m) => window.__ws.dispatchEvent(new MessageEvent('message', { data: JSON.stringify({ ...m, __inj: true }) }));
})();`;

async function openPage(browser, query, opts = {}) {
  const port = opts.port || PORT;
  const ctx = await browser.newContext({ viewport: { width: 800, height: 600 } });
  const page = await ctx.newPage();
  const errors = [], warns = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); if (m.type() === 'warning') warns.push(m.text()); });
  await page.route('**/cdn.jsdelivr.net/**', (route) => {
    const u = route.request().url();
    if (u.endsWith('three.module.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: THREE_STUB });
    if (u.endsWith('GLTFLoader.js')) return route.fulfill({ status: 200, contentType: 'text/javascript', body: GLTF_STUB });
    return route.fulfill({ status: 404, body: '' });
  });
  if (opts.slowGlb) await page.addInitScript('window.__slowGlb = true;');
  if (opts.wsHook) await page.addInitScript(WS_HOOK);
  if (opts.blockCollision) await page.route('**/dust2.collision.json', (r) => r.fulfill({ status: 404, body: 'no' }));
  await page.goto(`http://127.0.0.1:${port}/${query}`);
  return { ctx, page, errors, warns };
}

async function join(page, name) {
  await page.fill('#name', name);
  await page.click('#playBtn');
  await page.waitForFunction(() => document.getElementById('overlay').classList.contains('hidden') && window.__camN > 5, null, { timeout: 15000 });
}
const cam = (page) => page.evaluate(() => window.__cam.slice());

// a ws spectator that records the server's view of one player by name
function spectator() {
  const sp = { id: null, pos: null, ws: new WebSocket('ws://127.0.0.1:' + PORT), meta: new Map(), byName: {} };
  sp.ws.on('open', () => sp.ws.send(JSON.stringify({ t: 'join', name: 'spectator' })));
  sp.ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.t === 'welcome') { sp.id = m.id; for (const [id, name] of m.roster) sp.meta.set(id, name); }
    else if (m.t === 'join' || m.t === 'j') { /* ignored */ }
    else if (m.t === 's') for (const q of m.p) sp.byName[q[0]] = { x: q[1], y: q[2], z: q[3] };
    if (m.id !== undefined && m.name) sp.meta.set(m.id, m.name);
  });
  return sp;
}

(async () => {
  await sleep(600);
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] }).catch(() => chromium.launch({ args: ['--no-sandbox'] }));
  const sp = spectator();
  await sleep(300);

  // ---- 1. real map, real collision ----
  {
    const { ctx, page, errors, warns } = await openPage(browser, '');
    await join(page, 'walker');
    if (warns.length) console.log('   warnings:', warns.join(' | '));
    const glb = await page.evaluate(() => window.__glbBytes);
    ok(glb > 1e6, `real glb fetched (${glb} bytes)`);
    const c0 = await cam(page);
    {
      const fy = col.floorY(c0[0], c0[2], c0[1], 0);
      ok(Math.abs(fy + 1.6 - c0[1]) < 0.05 && !col.isSolid(c0[0], fy, c0[2]), `spawn is one of the real dust2 spawns, on a floor and not in a wall: camera ${c0.map((v) => v.toFixed(2)).join(',')} (floor ${fy.toFixed(2)})`);
      const sites = await page.evaluate(() => window.__placed.filter((o) => typeof o.name === 'string' && o.name.startsWith('site-')).map((o) => [o.name, o.position.x, o.position.y, o.position.z]));
      const A = sites.find((q) => q[0] === 'site-A'), B = sites.find((q) => q[0] === 'site-B');
      ok(A && Math.abs(A[1] - 19.7) < 0.01 && Math.abs(A[3] + 17.2) < 0.01 && A[2] > 1.28 && A[2] < 1.5, `site A decal placed on the real floor: ${JSON.stringify(A)}`);
      ok(B && Math.abs(B[1] + 17.4) < 0.01 && Math.abs(B[3] + 20.9) < 0.01 && B[2] > 0 && B[2] < 0.3, `site B decal placed on the real floor: ${JSON.stringify(B)}`);
      ok(sites.some((q) => q[0] === 'site-label-A') && sites.some((q) => q[0] === 'site-label-B'), 'floating A / B letters placed');
      const wm = await page.evaluate(() => document.getElementById('mapnote').textContent);
      ok(wm === '', 'no fallback note on the real map');
    }
    // the client's shared ray cast is wired up (same module as the server): line of sight is a real mesh test
    {
      const vis = await page.evaluate(() => typeof window.Collision.create === 'function');
      ok(vis, 'shared collision module present in the page');
    }
    // stand still 1.5 s: must not sink / drift
    await sleep(1500);
    const c1 = await cam(page);
    ok(Math.abs(c1[1] - c0[1]) < 0.05 && Math.hypot(c1[0] - c0[0], c1[2] - c0[2]) < 0.05, `standing still stays put (y ${c1[1].toFixed(2)})`);
    // walk forward (W) for 3 s: the spawn faces the centre
    await page.keyboard.down('KeyW');
    await sleep(3000);
    await page.keyboard.up('KeyW');
    const c2 = await cam(page);
    const moved = Math.hypot(c2[0] - c1[0], c2[2] - c1[2]);
    ok(moved > 3, `W moves the camera (${moved.toFixed(1)} m in 3 s)`);
    ok(c2[1] > -2 && c2[1] < 8 && c2.every(Number.isFinite), `camera stays finite and inside the map height range (y ${c2[1].toFixed(2)})`);
    // jump: camera goes up and comes back
    await sleep(400);
    const g0 = (await cam(page))[1];
    await page.keyboard.down('Space');
    let peak = g0;
    for (let i = 0; i < 20; i++) { await sleep(40); peak = Math.max(peak, (await cam(page))[1]); }
    await page.keyboard.up('Space');
    await sleep(1200);
    const g1 = (await cam(page))[1];
    ok(peak - g0 > 0.6 && peak - g0 < 1.6, `jump peak ${(peak - g0).toFixed(2)} m above the floor`);
    ok(Math.abs(g1 - g0) < 0.6, `lands again (y ${g0.toFixed(2)} -> ${g1.toFixed(2)})`);
    // server agrees with the client (give the 20 Hz broadcast a moment)
    await sleep(500);
    const cf = await cam(page);
    const sv = Object.values(sp.byName).filter((q) => Math.hypot(q.x - cf[0], q.z - cf[2]) < 1.5 && Math.abs(q.y + 1.6 - cf[1]) < 1.0);
    ok(sv.length >= 1, 'server position matches the client position (spectator saw the player within 1.5 m)');
    ok(errors.length === 0, 'no console/page errors on the real-map path' + (errors.length ? ': ' + errors.join(' | ') : ''));
    await ctx.close();
  }

  // ---- 2. server without dust2 data -> flat fallback arena (world.map = 'flat') ----
  {
    for (let i = 0; i < 50 && !/listening/.test(flatLog); i++) await sleep(100);
    ok(/ERROR: could not load the de_dust2 collision mesh/.test(flatLog) && /FLAT FALLBACK/.test(flatLog), 'server without public/maps logs a loud ERROR and runs the flat fallback');
    const { ctx, page, errors } = await openPage(browser, '', { port: FLAT_PORT });
    await page.waitForFunction(() => document.getElementById('flatnote').style.display === 'block', null, { timeout: 5000 });
    ok(true, 'flat fallback: the join card shows the "no de_dust2 map data" warning BEFORE pressing Play (from /info.json)');
    await join(page, 'flatty');
    await sleep(800);
    const c0 = await cam(page);
    ok(Math.abs(c0[1] - 1.6) < 0.05, `flat fallback: flat floor (camera y ${c0[1].toFixed(2)})`);
    await page.keyboard.down('KeyW');
    await sleep(1500);
    await page.keyboard.up('KeyW');
    const c1 = await cam(page);
    ok(Math.hypot(c1[0] - c0[0], c1[2] - c0[2]) > 2 && Math.abs(c1[1] - 1.6) < 0.05, 'flat fallback: walks on the flat floor');
    const note = await page.evaluate(() => document.getElementById('mapnote').textContent);
    ok(/flat test arena/i.test(note), `flat fallback note shown: "${note}"`);
    const sites = await page.evaluate(() => window.__placed.filter((o) => typeof o.name === 'string' && o.name.startsWith('site-')).map((o) => o.position.y));
    ok(sites.length === 4 && sites.every((y) => y < 5), 'flat fallback: site markers still placed');
    ok(errors.filter((e) => !/404|Failed to load resource|de_dust2 failed to load/.test(e)).length === 0, 'flat fallback: no page errors (404s of the missing map files are expected)' + (errors.length ? ': ' + errors.join(' | ') : ''));
    await ctx.close();
  }

  // ---- 3. real server, but this browser cannot load collision.json -> error note, does NOT enter the game ----
  {
    const { ctx, page } = await openPage(browser, '', { blockCollision: true });
    await page.fill('#name', 'blind');
    await page.click('#playBtn');
    await page.waitForFunction(() => /could not load the de_dust2/i.test(document.getElementById('status').textContent), null, { timeout: 15000 });
    const st = await page.evaluate(() => ({ status: document.getElementById('status').textContent, hidden: document.getElementById('overlay').classList.contains('hidden') }));
    ok(!st.hidden, `map load failed: join screen stays up with an error: "${st.status}"`);
    await sleep(2500);
    const players = await new Promise((res) => { const w = new WebSocket('ws://127.0.0.1:' + PORT); w.on('open', () => w.send(JSON.stringify({ t: 'join', name: 'probe' }))); w.on('message', (raw) => { const m = JSON.parse(raw); if (m.t === 'welcome') { res(m.roster.map((r) => r[1])); w.close(); } }); });
    ok(!players.includes('blind'), `the blind client left the server instead of standing around as a ghost (roster: ${players.join(', ')})`);
    ok((await page.evaluate(() => window.__camN || 0)) <= 5, 'game loop never started for the blind client');
    await ctx.close();
  }

  // ---- 3b. join card: loading bar + percent, credit line, no flat warning on the real server ----
  {
    const { ctx, page, errors } = await openPage(browser, '', { slowGlb: true });
    await page.waitForFunction(() => /Loading map… 50%/.test(document.getElementById('status').textContent), null, { timeout: 8000 });
    const ui = await page.evaluate(() => ({
      status: document.getElementById('status').textContent, loadDisplay: getComputedStyle(document.getElementById('mapload')).display,
      fill: document.getElementById('mapfill').style.width, flat: getComputedStyle(document.getElementById('flatnote')).display,
      credit: document.querySelector('#joinForm .credit').innerText, creditVisible: document.querySelector('#joinForm .credit').getBoundingClientRect().height > 0,
      color: getComputedStyle(document.getElementById('status')).color }));
    ok(ui.loadDisplay === 'block' && ui.fill === '50%', `join card shows a progress bar at 50% while the glb loads ("${ui.status}", fill ${ui.fill})`);
    ok(ui.color !== 'rgb(255, 122, 122)', `loading text is not in the error colour (${ui.color})`);
    ok(ui.flat === 'none', 'no flat-arena warning on the real server');
    ok(/de_dust2 - CS map/.test(ui.credit) && /vrchris/.test(ui.credit) && /CC-BY-4\.0/.test(ui.credit) && ui.creditVisible, `credit line on the join card: "${ui.credit}"`);
    await page.waitForFunction(() => getComputedStyle(document.getElementById('mapload')).display === 'none', null, { timeout: 8000 });
    ok(true, 'progress bar is hidden again when the map is ready');
    await join(page, 'credited');
    const g = await page.evaluate(() => ({ corner: document.getElementById('creditcorner').innerText, vis: document.getElementById('creditcorner').getBoundingClientRect().height > 0,
      start: [...document.querySelectorAll('#start .credit')].map((e) => e.innerText).join(' | ') }));
    ok(/vrchris/.test(g.corner) && /CC-BY-4\.0/.test(g.corner) && g.vis, `corner credit visible in game: "${g.corner}"`);
    ok(/vrchris/.test(g.start) && /CC-BY-4\.0/.test(g.start), 'credit line also on the click-to-play card');
    ok(errors.length === 0, 'loading UI: no console errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
    await ctx.close();
  }

  // ---- 3c. stuck rescue from the browser: stand 1.2 m in front of a wall, hold W, the client asks, the real server respawns us ----
  {
    const { ctx, page, errors } = await openPage(browser, '', { wsHook: true });
    await join(page, 'pusher');
    await sleep(1800); // the server must have seen us standing still for 1.5 s
    // find a spot next to a wall near this player's REAL spawn (so server and client agree about where we are) where the shared mover stalls
    const c0 = await cam(page);
    let spot = null;
    {
      const sx = c0[0], sz = c0[2], fy = col.floorY(sx, sz, c0[1] - 1.6 + 0.5, 0.5);
      for (let k = 0; k < 32 && !spot; k++) {
        const yaw = (k / 32) * Math.PI * 2, dx = -Math.sin(yaw), dz = -Math.cos(yaw);
        const t = col.raycast(sx, fy + 1.0, sz, dx, 0, dz, 15);
        if (!(t > 2.5 && t < 14)) continue;
        const px = sx + dx * (t - 1.2), pz = sz + dz * (t - 1.2), py = col.floorY(px, pz, fy + 0.5, 0.5);
        if (py === -Infinity || col.isSolid(px, py, pz) || Math.abs(py - fy) > 0.3) continue;
        const st = { x: px, y: py, z: pz, vy: 0, ground: true };
        for (let i = 0; i < 90; i++) col.step(st, 1 / 60, dx, dz, false);
        const a = { x: st.x, y: st.y, z: st.z };
        for (let i = 0; i < 300; i++) col.step(st, 1 / 60, dx, dz, false); // 5 s more: really stalled, no creeping
        if (Math.hypot(st.x - a.x, st.z - a.z) < 0.05 && Math.hypot(st.x - px, st.z - pz) < 1.5 && Math.abs(st.y - py) < 0.1) spot = { px, py, pz, yaw };
      }
    }
    ok(!!spot, `found a wall to push against near the spawn (${spot && spot.px.toFixed(1)}, ${spot && spot.pz.toFixed(1)}) where the shared mover stalls`);
    await page.evaluate((s) => window.__inject({ t: 'rs', x: s.px, y: s.py, z: s.pz, yaw: s.yaw, seq: window.__lastSeq, hp: 100 }), spot);
    await sleep(300);
    const cs = await cam(page);
    ok(Math.hypot(cs[0] - spot.px, cs[2] - spot.pz) < 0.1, 'test placed the player in front of the wall');
    const rs0 = await page.evaluate(() => window.__rsReal);
    await page.keyboard.down('KeyW');
    await sleep(3500);
    ok(!(await page.evaluate(() => window.__sent.includes('stuck'))), 'pushing against a wall for 3.5 s does NOT ask for a rescue yet');
    const cw = await cam(page);
    ok(Math.hypot(cw[0] - spot.px, cw[2] - spot.pz) < 1.5, 'the player really is held at the wall');
    await sleep(3500);
    const after = await page.evaluate(() => ({ no: window.__no, sent: window.__sent.filter((t) => t === 'stuck').length, rs: window.__rsReal, last: window.__lastRs }));
    await page.keyboard.up('KeyW');
    ok(after.sent === 1, `after ~7 s of pushing the client sent exactly one {t:'stuck'} (${after.sent})`);
    ok(after.rs === rs0 + 1 && after.last, `the real server answered with an rs (respawn) message (${after.rs - rs0})`);
    ok(after.last && col.floorY(after.last.x, after.last.z, 3, 0) !== -Infinity && !col.isSolid(after.last.x, after.last.y, after.last.z), 'rescue spawn point is on a floor, not in a wall');
    ok(errors.length === 0, 'stuck rescue: no console errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
    await ctx.close();
  }

  // ---- 4. ?fly=1 stays collision free ----
  {
    const { ctx, page, errors } = await openPage(browser, '?fly=1&at=0,12,28,0,-0.6');
    await join(page, 'flyer');
    await sleep(500);
    const c0 = await cam(page);
    ok(Math.abs(c0[1] - (12 + 1.6)) < 0.05 && c0[2] === 28, `?fly=1&at=... places the camera (${c0.map((v) => v.toFixed(1)).join(',')})`);
    await page.keyboard.down('KeyW');
    await sleep(1000);
    await page.keyboard.up('KeyW');
    const c1 = await cam(page);
    ok(Math.hypot(c1[0] - c0[0], c1[2] - c0[2]) > 5, 'fly mode moves freely');
    ok(errors.length === 0, '?fly=1: no console errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
    await ctx.close();
  }

  await browser.close();
  sp.ws.close();
  ok(!/Error|Unhandled/.test(srvLog.replace(/\[collision\].*/g, '')), 'no server errors in the log');
  srv.kill(); srvFlat.kill(); try { fs.rmSync(FLAT_DIR, { recursive: true, force: true }); } catch {}
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.log('TEST CRASH', e); srv.kill(); srvFlat.kill(); process.exit(1); });
