# Builds public/models/noob.glb from the Sketchfab "roblox Noob rig" (a STATIC model: 6 rigid blocks, no skin, no clips).
# Usage (from the project root):  python3 tools/build-noob.py path/to/roblox_noob_rig.glb [public/models/noob.glb]
# Needs numpy only. What it does (all documented in CREDITS.md):
#   * finds the 6 parts (torso, head, 2 arms, 2 legs) through the node hierarchy and bakes them into one frame:
#     metres, 1.8 m tall, feet on y=0, centred, FACING +z with the character's right side at -x (what the game expects;
#     the original faces -x, so it is turned 90 degrees about Y, nothing is mirrored)
#   * rebuilds them as a joint hierarchy with the pivots at the real joints (neck, shoulders, hips):
#       Noob > Hips > { Leg_R, Leg_L, Torso > { Body, Head, Arm_R, Arm_L } }
#   * bakes two looping animation clips, "idle" (breathing, head sway, left arm sways) and "walk" (run-style cycle:
#     legs and left arm swing, torso twist, body bounce). The RIGHT arm is raised holding the gun (Roblox "tool hold" pose).
#     The game finds the clips by name (idle / walk), see public/models/README.md.
# The geometry, UVs and texture are untouched (the texture PNG is copied byte for byte).
import json, struct, sys, math
import numpy as np

src = sys.argv[1] if len(sys.argv) > 1 else 'roblox_noob_rig.glb'
dst = sys.argv[2] if len(sys.argv) > 2 else 'public/models/noob.glb'

# ---------- read ----------
b = open(src, 'rb').read()
assert struct.unpack('<I', b[0:4])[0] == 0x46546C67, 'not a glb'
jl = struct.unpack('<I', b[12:16])[0]
J = json.loads(b[20:20 + jl])
off = 20 + jl
bl = struct.unpack('<I', b[off:off + 4])[0]
BIN = b[off + 8:off + 8 + bl]
CT = {5126: np.float32, 5123: np.uint16, 5125: np.uint32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}

def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]
    dt = np.dtype(CT[a['componentType']]); n = NC[a['type']]
    start = bv.get('byteOffset', 0) + a.get('byteOffset', 0); stride = bv.get('byteStride', dt.itemsize * n)
    out = np.zeros((a['count'], n), dtype=dt)
    for k in range(a['count']): out[k] = np.frombuffer(BIN, dtype=dt, count=n, offset=start + k * stride)
    return out

nodes = J['nodes']
def local(n): return np.array(n['matrix'], dtype=np.float64).reshape(4, 4).T if 'matrix' in n else np.eye(4)
W = {}
def rec(i, P):
    M = P @ local(nodes[i]); W[i] = M
    for c in nodes[i].get('children', []): rec(c, M)
for r in J['scenes'][0]['nodes']: rec(r, np.eye(4))

parts = []   # world-space positions / normals / uvs / indices of every mesh
for i, n in enumerate(nodes):
    if 'mesh' not in n: continue
    p = J['meshes'][n['mesh']]['primitives'][0]
    pos = acc(p['attributes']['POSITION']).astype(np.float64); nrm = acc(p['attributes']['NORMAL']).astype(np.float64)
    uv = acc(p['attributes']['TEXCOORD_0']).astype(np.float32); idx = acc(p['indices']).reshape(-1).astype(np.uint16)
    wp = (W[i] @ np.c_[pos, np.ones(len(pos))].T).T[:, :3]
    wn = (W[i][:3, :3] @ nrm.T).T; wn /= np.linalg.norm(wn, axis=1, keepdims=True)
    parts.append(dict(pos=wp, nrm=wn, uv=uv, idx=idx))

# ---------- identify the parts by their world bounds (original frame: y up, width along z, the face looks to -x) ----------
for q in parts: q['min'] = q['pos'].min(0); q['max'] = q['pos'].max(0); q['c'] = (q['min'] + q['max']) / 2
head = max(parts, key=lambda q: len(q['pos']))                                   # the cylinder (517 vertices)
rest = [q for q in parts if q is not head]
torso = max(rest, key=lambda q: q['max'][2] - q['min'][2])                        # the widest block (2 studs wide, arms/legs are 1)
others = [q for q in rest if q is not torso]
legs = sorted([q for q in others if q['max'][1] < 30], key=lambda q: q['c'][2])  # sorted by z
arms = sorted([q for q in others if q['min'][1] > 20], key=lambda q: q['c'][2])
assert len(legs) == 2 and len(arms) == 2, 'unexpected model layout'
# the face (vertices whose UVs are not the plain-colour corner) must be on the -x side; right side of a -x facing character is -z
corner = np.array([0.8809, 0.9844]); var = np.abs(head['uv'] - corner).max(1) > 0.002
assert (head['pos'][var] - head['c']).mean(0)[0] < -1, 'face is not on the -x side: this script expects the Sketchfab file'
armR, armL = arms[0], arms[1]; legR, legL = legs[0], legs[1]                      # lower z = the character's right

# ---------- bake into the game frame: x' = z - cz, z' = -(x - cx) (turn 90 deg about Y), metres, feet on y = 0 ----------
ymin = min(q['min'][1] for q in parts); ymax = max(q['max'][1] for q in parts)
cx, cz = torso['c'][0], torso['c'][2]
k = 1.8 / (ymax - ymin)
def bake(P):  return np.c_[(P[:, 2] - cz) * k, (P[:, 1] - ymin) * k, -(P[:, 0] - cx) * k]
def bakeN(N): return np.c_[N[:, 2], N[:, 1], -N[:, 0]]

hipY = (legR['max'][1] - ymin) * k                                               # top of the legs = bottom of the torso
neckY = (torso['max'][1] - ymin) * k
shY = (armR['max'][1] - 0.5 * (armR['max'][0] - armR['min'][0]) - ymin) * k      # shoulder = half a block (0.5 stud) under the arm top
armX = abs((armR['c'][2] - cz) * k)
legX = abs((legR['c'][2] - cz) * k)
print(f'height 1.8 m (scale {k:.5f}), hip y {hipY:.3f}, shoulder y {shY:.3f}, neck y {neckY:.3f}, arm x +-{armX:.3f}, leg x +-{legX:.3f}')

# ---------- node hierarchy (translations relative to the parent, mesh vertices relative to their own pivot) ----------
def T(x, y, z): return np.array([x, y, z])
HIPS = T(0, hipY, 0)
# name: (parent, translation relative to parent, pivot in absolute coords (to subtract from vertices) or None, source part)
NODES = [
    ('Noob',    None,    T(0, 0, 0),                 None,                None),
    ('Hips',    'Noob',  HIPS,                       None,                None),
    ('Leg_R',   'Hips',  T(-legX, 0, 0),             T(-legX, hipY, 0),   legR),
    ('Leg_L',   'Hips',  T(+legX, 0, 0),             T(+legX, hipY, 0),   legL),
    ('Torso',   'Hips',  T(0, 0, 0),                 None,                None),
    ('Body',    'Torso', T(0, 0, 0),                 HIPS,                torso),
    ('Head',    'Torso', T(0, neckY - hipY, 0),      T(0, neckY, 0),      head),
    ('Arm_R',   'Torso', T(-armX, shY - hipY, 0),    T(-armX, shY, 0),    armR),
    ('Arm_L',   'Torso', T(+armX, shY - hipY, 0),    T(+armX, shY, 0),    armL),
]
names = [n[0] for n in NODES]; NI = {n: i for i, n in enumerate(names)}

# ---------- binary buffer ----------
chunks = []   # (bytes, target) ; every one becomes a bufferView
accessors = []; bviews = []; blob = bytearray()
def add_view(data, target=None):
    while len(blob) % 4: blob.append(0)
    bv = {'buffer': 0, 'byteOffset': len(blob), 'byteLength': len(data)}
    if target: bv['target'] = target
    blob.extend(data); bviews.append(bv); return len(bviews) - 1
def add_acc(arr, ctype, typ, target=None, minmax=False):
    v = add_view(arr.tobytes(), target)
    a = {'bufferView': v, 'componentType': ctype, 'count': int(len(arr)), 'type': typ}
    if minmax: a['min'] = arr.min(0).astype(float).tolist(); a['max'] = arr.max(0).astype(float).tolist()
    accessors.append(a); return len(accessors) - 1

meshes = []; gnodes = []
mesh_of = {}
for name, parent, tr, pivot, part in NODES:
    if part is None: continue
    P = bake(part['pos']) - pivot; N = bakeN(part['nrm'])
    attr = {'POSITION': add_acc(P.astype(np.float32), 5126, 'VEC3', 34962, True),
            'NORMAL': add_acc(N.astype(np.float32), 5126, 'VEC3', 34962),
            'TEXCOORD_0': add_acc(part['uv'].astype(np.float32), 5126, 'VEC2', 34962)}
    ind = add_acc(part['idx'].astype(np.uint16).reshape(-1, 1), 5123, 'SCALAR', 34963)
    meshes.append({'name': 'Mesh_' + name, 'primitives': [{'attributes': attr, 'indices': ind, 'material': 0, 'mode': 4}]})
    mesh_of[name] = len(meshes) - 1

# texture: copy the PNG bytes as they are
img_bv = J['bufferViews'][J['images'][0]['bufferView']]
png = BIN[img_bv.get('byteOffset', 0):img_bv.get('byteOffset', 0) + img_bv['byteLength']]
png_view = add_view(png)

# ---------- animation ----------
def qx(a): h = a / 2; return np.array([math.sin(h), 0, 0, math.cos(h)])
def qy(a): h = a / 2; return np.array([0, math.sin(h), 0, math.cos(h)])
def qz(a): h = a / 2; return np.array([0, 0, math.sin(h), math.cos(h)])
def qmul(a, c):
    x1, y1, z1, w1 = a; x2, y2, z2, w2 = c
    return np.array([w1*x2 + x1*w2 + y1*z2 - z1*y2, w1*y2 - x1*z2 + y1*w2 + z1*x2, w1*z2 + x1*y2 - y1*x2 + z1*w2, w1*w2 - x1*x2 - y1*y2 - z1*z2])
D = math.radians
# Positive rotation about X swings a hanging limb BACKWARDS (toward -z), negative = forward (+z). Yaw = about Y.
def pose_idle(ph):
    s = math.sin(ph)
    return {
        'Hips':  (T(0, hipY + 0.004 * s, 0), qy(0)),
        'Torso': (None, qmul(qy(D(1.0) * math.sin(ph + 1.0)), qx(D(0.8) * s))),
        'Head':  (None, qmul(qy(D(5) * math.sin(ph)), qx(D(1.2) * math.sin(ph + 0.5)))),
        'Arm_R': (None, qmul(qx(D(-90) + D(0.7) * s), qy(D(0)))),                         # raised, holding the gun
        'Arm_L': (None, qmul(qz(D(-3.5) + D(0.8) * math.sin(ph + 0.6)), qx(D(2.5) * math.sin(ph + 0.6)))),
        'Leg_R': (None, qx(0)), 'Leg_L': (None, qx(0)),
    }
LEG, ARM = D(32), D(35)
def pose_walk(ph):
    s = math.sin(ph)
    return {
        'Hips':  (T(0, hipY - 0.025 + 0.025 * math.cos(2 * ph), 0), qy(0)),            # highest when the legs pass, lowest at full stride
        'Torso': (None, qmul(qy(D(3) * s), qx(D(4)))),                                  # small twist + forward lean
        'Head':  (None, qmul(qy(D(-3) * s), qx(D(-4)))),                                # keeps looking ahead
        'Arm_R': (None, qx(D(-94) + D(1.5) * math.sin(2 * ph))),                        # raised (-94 cancels the 4 degree lean)
        'Arm_L': (None, qmul(qz(D(-3.5)), qx(-ARM * s))),
        'Leg_R': (None, qx(-LEG * s)),
        'Leg_L': (None, qx(+LEG * s)),
    }
def bake_clip(name, dur, n, fn):
    times = np.array([dur * i / n for i in range(n + 1)], dtype=np.float32)          # last key == first key (seamless loop)
    t_acc = add_acc(times.reshape(-1, 1), 5126, 'SCALAR', None, True)
    poses = [fn(2 * math.pi * i / n) for i in range(n + 1)]
    samplers = []; channels = []
    for nm in ['Hips', 'Torso', 'Head', 'Arm_R', 'Arm_L', 'Leg_R', 'Leg_L']:
        qs = np.array([p[nm][1] for p in poses], dtype=np.float32)
        for i in range(1, len(qs)):                                                  # shortest-path continuity for slerp
            if np.dot(qs[i], qs[i - 1]) < 0: qs[i] = -qs[i]
        samplers.append({'input': t_acc, 'output': add_acc(qs, 5126, 'VEC4'), 'interpolation': 'LINEAR'})
        channels.append({'sampler': len(samplers) - 1, 'target': {'node': NI[nm], 'path': 'rotation'}})
        if poses[0][nm][0] is not None:
            ts = np.array([p[nm][0] for p in poses], dtype=np.float32)
            samplers.append({'input': t_acc, 'output': add_acc(ts, 5126, 'VEC3'), 'interpolation': 'LINEAR'})
            channels.append({'sampler': len(samplers) - 1, 'target': {'node': NI[nm], 'path': 'translation'}})
    return {'name': name, 'samplers': samplers, 'channels': channels}
animations = [bake_clip('idle', 2.4, 24, pose_idle), bake_clip('walk', 0.8, 24, pose_walk)]

# ---------- assemble json ----------
gl_nodes = []
for name, parent, tr, pivot, part in NODES:
    n = {'name': name}
    if name != 'Noob': n['translation'] = [float(v) for v in tr]
    if part is not None: n['mesh'] = mesh_of[name]
    gl_nodes.append(n)
for name, parent, *_ in NODES:
    if parent: gl_nodes[NI[parent]].setdefault('children', []).append(NI[name])
# the mesh of a part hangs directly on its joint node (pivot = joint), except Body/Torso which share the hips pivot: Body is its own child of Torso
out = {
    'asset': {'version': '2.0', 'generator': 'tools/build-noob.py', 'extras': J['asset'].get('extras', {})},
    'scene': 0, 'scenes': [{'name': 'Scene', 'nodes': [0]}],
    'nodes': gl_nodes, 'meshes': meshes,
    'materials': J['materials'], 'textures': J['textures'], 'samplers': J.get('samplers', []),
    'images': [{'bufferView': png_view, 'mimeType': 'image/png'}],
    'accessors': accessors, 'bufferViews': bviews, 'animations': animations,
    'buffers': [{'byteLength': len(blob)}],
}
js = json.dumps(out, separators=(',', ':')).encode()
while len(js) % 4: js += b' '
bb = bytes(blob)
while len(bb) % 4: bb += b'\0'
total = 12 + 8 + len(js) + 8 + len(bb)
with open(dst, 'wb') as f:
    f.write(struct.pack('<III', 0x46546C67, 2, total))
    f.write(struct.pack('<II', len(js), 0x4E4F534A)); f.write(js)
    f.write(struct.pack('<II', len(bb), 0x004E4942)); f.write(bb)
print(f'wrote {dst}: {total} bytes, {len(meshes)} meshes, {len(animations)} clips ({", ".join(a["name"] for a in animations)})')
print('suggested gun position [x right, y up, z -forward]:', [round(float(armX), 3), round(float(shY), 3), -0.55])
