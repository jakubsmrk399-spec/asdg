'use strict';
// Unit tests for col.raycast / col.visible (public/shared/collision.js) against the real map.   node tools/test-ray.js
const fs = require('fs');
const path = require('path');
const Collision = require('../public/shared/collision.js');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8'));
const col = Collision.create(data);
let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const near = (a, b, e = 0.02) => Math.abs(a - b) <= e;
const EYE = Collision.EYE;

// ---- 1. straight down = floor height ----
for (const [n, x, z, y] of [['A site', 19.7, -17.2, 1.28], ['B site', -17.4, -20.9, 0.0], ['mid', -1, 5, 0.0], ['CT block', -4, -15, -1.71], ['T area', -17, 23, 1.707]]) {
  const t = col.raycast(x, y + 3, z, 0, -1, 0, 50);
  ok(near(y + 3 - t, y, 0.03), `down ray at ${n} hits floor y ${(y + 3 - t).toFixed(3)} (expected ${y})`);
}
ok(col.raycast(0, 20, 0, 0, 1, 0, 50) === Infinity, 'straight up into the sky: no hit');
ok(col.raycast(500, 1, 500, 1, 0, 0, 100) === Infinity, 'ray starting far outside the grid: no hit, no throw');
ok(col.raycast(0, 1, 0, 1, 0, 0, 0) === Infinity, 'maxT 0: no hit');

// ---- 2. walls block, open sand does not ----
const seg = (a, b) => col.visible(a[0], a[1], a[2], b[0], b[1], b[2]);
{
  const f = (x, z) => col.floorY(x, z, 10, 0);
  const eye = (x, z) => [x, f(x, z) + EYE, z];
  ok(seg(eye(-17, 23), eye(-13, 26)), 'open T sand (-17,23) -> (-13,26): visible');
  ok(seg(eye(-17, 23), eye(-17, 26)) && seg(eye(-13, 23), eye(-13, 26)), 'more open T sand pairs visible');
  ok(!seg(eye(-17.4, -20.9), eye(19.7, -17.2)), 'B site -> A site is blocked by the CT block walls');
  ok(!seg(eye(-4, -15), eye(-17, 23)), 'CT block -> T area is blocked');
  ok(!seg(eye(19.7, -17.2), eye(-17, 23)), 'A site -> T area is blocked');
  // mid corridor: a long open line down the middle
  ok(seg(eye(0, 14), eye(0, 2)), 'down mid (0,14) -> (0,2): visible');
  ok(seg(eye(-17, 23), eye(-17, 23)), 'zero length segment: visible');
}
// the 4 old outer walls are gone, the mesh has its own boundary; a ray from inside the map to far outside is fine
ok(Number.isFinite(col.raycast(0, 10, 0, 1, 0, 0, 1000)) || col.raycast(0, 10, 0, 1, 0, 0, 1000) === Infinity, 'long horizontal ray returns a number or Infinity');

// ---- 3. cross-check against a brute-force ray vs all triangles ----
const verts = data.verts, tris = data.tris, nT = tris.length / 3;
function brute(ox, oy, oz, dx, dy, dz, maxT) {
  let best = Infinity;
  for (let t = 0; t < nT; t++) {
    const a = tris[t * 3] * 3, b = tris[t * 3 + 1] * 3, c = tris[t * 3 + 2] * 3;
    const e1x = verts[b] - verts[a], e1y = verts[b + 1] - verts[a + 1], e1z = verts[b + 2] - verts[a + 2];
    const e2x = verts[c] - verts[a], e2y = verts[c + 1] - verts[a + 1], e2z = verts[c + 2] - verts[a + 2];
    const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
    const det = e1x * px + e1y * py + e1z * pz;
    if (det > -1e-12 && det < 1e-12) continue;
    const inv = 1 / det;
    const sx = ox - verts[a], sy = oy - verts[a + 1], sz = oz - verts[a + 2];
    const u = (sx * px + sy * py + sz * pz) * inv;
    if (u < -1e-7 || u > 1 + 1e-7) continue;
    const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
    const v = (dx * qx + dy * qy + dz * qz) * inv;
    if (v < -1e-7 || u + v > 1 + 1e-7) continue;
    const tt = (e2x * qx + e2y * qy + e2z * qz) * inv;
    if (tt >= 0 && tt < best) best = tt;
  }
  return best <= maxT ? best : Infinity;
}
let seed = 12345;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
function randRay(inside) {
  const ox = (rnd() * 2 - 1) * (inside ? 30 : 45), oz = (rnd() * 2 - 1) * (inside ? 35 : 45), oy = -2 + rnd() * 8;
  let dx = rnd() * 2 - 1, dy = (rnd() * 2 - 1) * 0.6, dz = rnd() * 2 - 1;
  const L = Math.hypot(dx, dy, dz) || 1;
  return [ox, oy, oz, dx / L, dy / L, dz / L];
}
{
  let mism = 0, hits = 0, n = 6000;
  for (let i = 0; i < n; i++) {
    const r = randRay(i % 3 !== 0), maxT = i % 2 ? 150 : 8 + rnd() * 40;
    const a = col.raycast(r[0], r[1], r[2], r[3], r[4], r[5], maxT), b = brute(r[0], r[1], r[2], r[3], r[4], r[5], maxT);
    if (b < Infinity) hits++;
    if (!(a === b || Math.abs(a - b) < 1e-6)) { mism++; if (mism < 5) console.log('  mismatch', r.map((v) => v.toFixed(3)).join(','), 'grid', a, 'brute', b); }
  }
  ok(mism === 0, `${n} random rays: grid DDA == brute force over all ${nT} triangles (${hits} hits, ${mism} mismatches)`);
}
{ // axis-aligned and near-axis rays (DDA edge cases)
  let mism = 0, n = 0;
  const dirs = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, 1, 0], [0, -1, 0], [1e-13, 0, 1], [0, 1e-9, -1]];
  for (let i = 0; i < 300; i++) for (const d of dirs) {
    const ox = (rnd() * 2 - 1) * 30, oz = (rnd() * 2 - 1) * 35, oy = -2 + rnd() * 8;
    const L = Math.hypot(...d);
    const a = col.raycast(ox, oy, oz, d[0] / L, d[1] / L, d[2] / L, 100), b = brute(ox, oy, oz, d[0] / L, d[1] / L, d[2] / L, 100);
    n++; if (!(a === b || Math.abs(a - b) < 1e-6)) { mism++; if (mism < 5) console.log('  mismatch', ox, oy, oz, d, a, b); }
  }
  ok(mism === 0, `${n} axis-aligned rays match brute force (${mism} mismatches)`);
}

// ---- 4. robustness + timing ----
{
  let bad = 0;
  const N = 1000000;
  const t0 = process.hrtime.bigint();
  for (let i = 0; i < N; i++) {
    const r = randRay(i % 2 === 0);
    const t = col.raycast(r[0], r[1], r[2], r[3], r[4], r[5], 150);
    if (Number.isNaN(t) || t < 0) bad++;
  }
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  ok(bad === 0, `1,000,000 random rays: no NaN / negative (${bad} bad)`);
  ok(ms / N < 0.05, `timing ${(ms / N * 1000).toFixed(2)} us per ray (limit 50 us)`);
}
{ // nasty inputs must not throw
  let threw = false;
  try {
    for (const v of [NaN, Infinity, -Infinity, 1e30]) { col.raycast(v, 0, 0, 1, 0, 0, 10); col.raycast(0, 0, 0, v, 0, 0, 10); col.raycast(0, 0, 0, 1, 0, 0, v); }
    col.visible(NaN, 0, 0, 1, 1, 1);
  } catch (e) { threw = true; console.log(e); }
  ok(!threw, 'NaN / Infinity inputs do not throw');
}

console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
process.exit(fails ? 1 : 0);
