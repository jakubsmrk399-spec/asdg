#!/usr/bin/env python3
"""Repack the Sketchfab "RIFLE | M4A1-S Weapon Model (CS2)" glb for the game.
   python3 tools/build-m4a1.py rifle__m4a1-s_weapon_model_cs2.glb public/models/m4a1-s.glb
What it does (geometry, skeleton and bind pose are untouched):
  * the skinned mesh node is moved to the scene root (its own parent chain carried a 0.0254 scale + axis swap that
    three.js would apply on top of the skin, the skeleton already contains it);
  * keeps only POSITION / NORMAL / TEXCOORD_0 / JOINTS_0 / WEIGHTS_0 (drops tangents and 5 extra UV sets);
  * keeps only the base colour texture, 1024 px JPEG (normal / ORM maps are not used by the game's simple materials);
  * keeps 2 first-person clips: firstperson_draw and firstperson_reload (firstperson_lookat01 does not move anything, inspect is done in code). The original
    *_additive clips (shoot) are deltas, not absolute bone poses, so they are dropped; the recoil kick is done in code.
"""
import struct, json, sys, io
import numpy as np
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
b = open(src, 'rb').read()
jl = struct.unpack('<I', b[12:16])[0]
j = json.loads(b[20:20 + jl])
bin0 = 20 + jl + 8
CT = {5126: '<f4', 5123: '<u2', 5125: '<u4', 5121: 'u1', 5120: 'i1', 5122: '<i2'}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}

def read(i):
    a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
    dt = np.dtype(CT[a['componentType']]); nc = NC[a['type']]
    stride = bv.get('byteStride') or dt.itemsize * nc
    off = bin0 + bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    raw = np.frombuffer(b, dtype='u1', count=stride * (a['count'] - 1) + dt.itemsize * nc, offset=off)
    rows = np.lib.stride_tricks.as_strided(raw, shape=(a['count'], dt.itemsize * nc), strides=(stride, 1))
    return np.ascontiguousarray(rows).view(dt).reshape(a['count'], nc), a

out = bytearray(); bvs = []; accs = []
def add(arr, a, target=None, minmax=False):
    while len(out) % 4: out.append(0)
    data = np.ascontiguousarray(arr).tobytes()
    bvs.append({'buffer': 0, 'byteOffset': len(out), 'byteLength': len(data), **({'target': target} if target else {})})
    out.extend(data)
    na = {'bufferView': len(bvs) - 1, 'componentType': a['componentType'], 'count': a['count'], 'type': a['type']}
    if a.get('normalized'): na['normalized'] = True
    if minmax or 'min' in a:
        f = np.asarray(arr, dtype=np.float64).reshape(a['count'], -1)
        na['min'] = f.min(0).tolist(); na['max'] = f.max(0).tolist()
    accs.append(na); return len(accs) - 1

prim = j['meshes'][0]['primitives'][0]
attrs = {}
for k in ['POSITION', 'NORMAL', 'TEXCOORD_0', 'JOINTS_0', 'WEIGHTS_0']:
    arr, a = read(prim['attributes'][k]); attrs[k] = add(arr, a, 34962, minmax=(k == 'POSITION'))
arr, a = read(prim['indices']); idx = add(arr, a, 34963)
ibm_arr, a = read(j['skins'][0]['inverseBindMatrices']); ibm = add(ibm_arr, a)

# texture
bc = j['materials'][0]['pbrMetallicRoughness']['baseColorTexture']['index']
im = j['images'][j['textures'][bc]['source']]; bv = j['bufferViews'][im['bufferView']]
o = bin0 + bv.get('byteOffset', 0)
img = Image.open(io.BytesIO(b[o:o + bv['byteLength']])).convert('RGB').resize((1024, 1024), Image.LANCZOS)
buf = io.BytesIO(); img.save(buf, 'JPEG', quality=86, optimize=True)
while len(out) % 4: out.append(0)
bvs.append({'buffer': 0, 'byteOffset': len(out), 'byteLength': len(buf.getvalue())}); out.extend(buf.getvalue())
img_bv = len(bvs) - 1

# animations
want = {'firstperson_draw': 'firstperson_draw', 'firstperson_reload': 'firstperson_reload'}
anims = []
HAND = 8
for an in j['animations']:
    if an['name'] not in want: continue
    chans, samps, smap = [], [], {}
    for c in an['channels']:
        node = c['target']['node']
        sidx = c['sampler']
        if sidx not in smap:
            s = an['samplers'][sidx]
            tin, ta = read(s['input']); tout, oa = read(s['output'])
            smap[sidx] = len(samps)
            samps.append({'input': add(tin, ta, minmax=True), 'output': add(tout, oa), 'interpolation': s.get('interpolation', 'LINEAR')})
        chans.append({'sampler': smap[sidx], 'target': {'node': node, 'path': c['target']['path']}})
    anims.append({'name': want[an['name']], 'channels': chans, 'samplers': samps})

nodes = json.loads(json.dumps(j['nodes']))
nodes[4]['children'] = [x for x in nodes[4]['children'] if x != 7]     # mesh node leaves the scaled chain ...
nodes[7].pop('matrix', None)
scene = {'nodes': [0, 7]}                                               # ... and sits at the scene root (identity)
newj = {
    'asset': {'version': '2.0', 'generator': 'tools/build-m4a1.py', 'extras': j['asset'].get('extras', {})},
    'scene': 0, 'scenes': [scene], 'nodes': nodes,
    'skins': [{'inverseBindMatrices': ibm, 'joints': j['skins'][0]['joints'], 'skeleton': j['skins'][0]['skeleton']}],
    'meshes': [{'name': 'm4a1s', 'primitives': [{'attributes': attrs, 'indices': idx, 'material': 0, 'mode': 4}]}],
    'materials': [{'name': 'weapon_rif_m4a1_silencer', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0.3, 'roughnessFactor': 0.7}}],
    'textures': [{'sampler': 0, 'source': 0}],
    'samplers': j.get('samplers', [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 10497, 'wrapT': 10497}]),
    'images': [{'bufferView': img_bv, 'mimeType': 'image/jpeg'}],
    'animations': anims, 'accessors': accs, 'bufferViews': bvs, 'buffers': [{'byteLength': len(out)}],
}
js = json.dumps(newj, separators=(',', ':')).encode()
while len(js) % 4: js += b' '
while len(out) % 4: out.append(0)
total = 12 + 8 + len(js) + 8 + len(out)
open(dst, 'wb').write(struct.pack('<III', 0x46546C67, 2, total) + struct.pack('<II', len(js), 0x4E4F534A) + js + struct.pack('<II', len(out), 0x004E4942) + bytes(out))
print(f'{dst}: {total/1048576:.2f} MB, clips: {[a["name"] for a in anims]}')
