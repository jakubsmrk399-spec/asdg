# Software preview of public/maps/dust2.glb (numpy + Pillow only, no browser/three.js needed).
# Usage: cd tools && python3 -c "import importlib.util as u; s=u.spec_from_file_location('p','preview-render.py'); m=u.module_from_spec(s); s.loader.exec_module(m); m.topdown('/tmp/top.png'); m.persp('/tmp/v.png',(0,22,45),(0,0,-5))"
# Used in Part 2 to verify orientation (x right, z down in topdown). Affine UVs, no lighting accuracy: a sanity tool only.
import struct, json, io, sys
import numpy as np
from PIL import Image

import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GLB=os.path.join(ROOT,'public/maps/dust2.glb')
meta=json.load(open(os.path.join(ROOT,'public/maps/dust2.meta.json')))
OFF=np.array(meta['offset'])
b=open(GLB,'rb').read()
off=12; chunks={}
while off<len(b):
    l,t=struct.unpack('<I4s',b[off:off+8]); chunks[t]=(off+8,l); off+=8+l
j=json.loads(b[chunks[b'JSON'][0]:chunks[b'JSON'][0]+chunks[b'JSON'][1]])
bin0=chunks[b'BIN\x00'][0]
CT={5126:np.float32,5123:np.uint16,5125:np.uint32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def acc(i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    n=a['count']; c=NC[a['type']]; dt=CT[a['componentType']]
    o=bin0+bv.get('byteOffset',0)+a.get('byteOffset',0)
    stride=bv.get('byteStride')
    if stride and stride!=c*np.dtype(dt).itemsize:
        raw=np.frombuffer(b,dtype=np.uint8,count=n*stride,offset=o).reshape(n,stride)
        return np.frombuffer(raw[:,:c*np.dtype(dt).itemsize].tobytes(),dtype=dt).reshape(n,c)
    return np.frombuffer(b,dtype=dt,count=n*c,offset=o).reshape(n,c)
# textures
imgs=[]
for im in j['images']:
    bv=j['bufferViews'][im['bufferView']]
    o=bin0+bv.get('byteOffset',0)
    imgs.append(np.array(Image.open(io.BytesIO(b[o:o+bv['byteLength']])).convert('RGB')))
tex_of_mat=[]
for m in j['materials']:
    t=m['pbrMetallicRoughness']['baseColorTexture']['index']
    tex_of_mat.append(imgs[j['textures'][t]['source']])
# node matrix
M=np.array(j['nodes'][0]['matrix']).reshape(4,4).T
# gather triangles
V=[];N=[];UV=[];MAT=[]
for ni,n in enumerate(j['nodes']):
    if 'mesh' not in n: continue
    for p in j['meshes'][n['mesh']]['primitives']:
        pos=acc(p['attributes']['POSITION']).astype(np.float64)
        uv=acc(p['attributes']['TEXCOORD_0']).astype(np.float64)
        idx=acc(p['indices']).reshape(-1).astype(np.int64)
        ph=np.c_[pos,np.ones(len(pos))]@M.T
        pw=ph[:,:3]+OFF
        V.append(pw[idx].reshape(-1,3,3)); UV.append(uv[idx].reshape(-1,3,2)); MAT.append(np.full(len(idx)//3,p['material']))
V=np.concatenate(V);UV=np.concatenate(UV);MAT=np.concatenate(MAT)
nrm=np.cross(V[:,1]-V[:,0],V[:,2]-V[:,0]); nl=np.linalg.norm(nrm,axis=1,keepdims=True); nl[nl==0]=1; nrm/=nl
print('tris',len(V),'bounds',V.reshape(-1,3).min(0),V.reshape(-1,3).max(0))

def raster(P,depth,W,H,ids=None,shade_dir=np.array([0.3,0.8,0.4])):
    if ids is None: ids=np.arange(len(P))
    """P: (T,3,2) screen px; depth: (T,3) larger=nearer for ortho (use -dist)"""
    img=np.zeros((H,W,3),np.uint8); img[:]=(170,196,220); zb=np.full((H,W),-1e18)
    ld=shade_dir/np.linalg.norm(shade_dir)
    for k in range(len(P)):
        t=ids[k]; p=P[k]; x0=int(max(0,np.floor(p[:,0].min()))); x1=int(min(W-1,np.ceil(p[:,0].max())))
        y0=int(max(0,np.floor(p[:,1].min()))); y1=int(min(H-1,np.ceil(p[:,1].max())))
        if x1<x0 or y1<y0: continue
        d=(p[1,1]-p[2,1])*(p[0,0]-p[2,0])+(p[2,0]-p[1,0])*(p[0,1]-p[2,1])
        if abs(d)<1e-9: continue
        xs,ys=np.meshgrid(np.arange(x0,x1+1)+0.5,np.arange(y0,y1+1)+0.5)
        w0=((p[1,1]-p[2,1])*(xs-p[2,0])+(p[2,0]-p[1,0])*(ys-p[2,1]))/d
        w1=((p[2,1]-p[0,1])*(xs-p[2,0])+(p[0,0]-p[2,0])*(ys-p[2,1]))/d
        w2=1-w0-w1
        m=(w0>=-1e-6)&(w1>=-1e-6)&(w2>=-1e-6)
        if not m.any(): continue
        z=w0*depth[k,0]+w1*depth[k,1]+w2*depth[k,2]
        sub=zb[y0:y1+1,x0:x1+1]
        m&=z>sub
        if not m.any(): continue
        u=(w0*UV[t,0,0]+w1*UV[t,1,0]+w2*UV[t,2,0]); v=(w0*UV[t,0,1]+w1*UV[t,1,1]+w2*UV[t,2,1])
        tx=tex_of_mat[MAT[t]]; th,tw=tx.shape[:2]
        iu=(np.floor((u%1.0)*tw).astype(int))%tw; iv=(np.floor((v%1.0)*th).astype(int))%th
        col=tx[iv,iu].astype(np.float32)
        sh=0.45+0.55*abs(float(np.dot(nrm[t],ld)))
        col*=sh
        sub[m]=z[m]
        im=img[y0:y1+1,x0:x1+1]; im[m]=np.clip(col[m],0,255).astype(np.uint8)
    return img

def topdown(path,s=14,flipx=False):
    xmin,xmax=-31,31; zmin,zmax=-37,37
    W=int((xmax-xmin)*s);H=int((zmax-zmin)*s)
    P=np.empty((len(V),3,2)); P[:,:,0]=(V[:,:,0]-xmin)*s; P[:,:,1]=(V[:,:,2]-zmin)*s
    if flipx: P[:,:,0]=W-P[:,:,0]
    img=raster(P,V[:,:,1].copy(),W,H)
    Image.fromarray(img).save(path); print('saved',path,W,H)

def persp(path,eye,target,fov=75,W=900,H=560,s=None):
    eye=np.array(eye,float);target=np.array(target,float)
    f=target-eye;f/=np.linalg.norm(f); r=np.cross(f,[0,1,0]);r/=np.linalg.norm(r); u=np.cross(r,f)
    rel=V-eye; xc=rel@r; yc=rel@u; zc=rel@f
    ok=(zc>0.1).all(axis=1)
    foc=(H/2)/np.tan(np.radians(fov)/2)
    P=np.empty((len(V),3,2)); P[:,:,0]=W/2+foc*xc/np.maximum(zc,0.1); P[:,:,1]=H/2-foc*yc/np.maximum(zc,0.1)
    depth=-zc
    sel=np.where(ok)[0]
    img=raster(P[sel],depth[sel],W,H,ids=sel)
    Image.fromarray(img).save(path); print('saved',path)
    # patch UV/MAT/nrm indexing: raster uses global t index; redo mapping
    return img
