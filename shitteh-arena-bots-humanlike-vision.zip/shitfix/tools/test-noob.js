'use strict';
// Checks public/models/noob.glb (built by tools/build-noob.py) and its entry in characters.json. No dependencies:
//   node tools/test-noob.js
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
let fails = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { fails++; console.log('FAIL ' + m); } else console.log('ok   ' + m); };

const chars = JSON.parse(fs.readFileSync(path.join(ROOT, 'public/models/characters.json'), 'utf8'));
const def = chars.models.noob;
ok(!!def, 'characters.json has a "noob" model');
ok(Object.entries(chars.players || {}).some(([k, v]) => k.trim().toLowerCase() === 'noob' && v === 'noob'), 'player name "noob" (any case) maps to the noob model');
ok(/modelsforgame/i.test(def.credit || ''), 'CC-BY credit line is set');
ok(Array.isArray(def.gun) && def.gun.length === 3 && def.gun.every(Number.isFinite), 'gun is [x,y,z]');
const file = path.join(ROOT, 'public/models', def.file);
ok(fs.existsSync(file), `model file ${def.file} exists`);

const buf = fs.readFileSync(file);
ok(buf.readUInt32LE(0) === 0x46546c67, 'is a glb');
const jl = buf.readUInt32LE(12); const j = JSON.parse(buf.slice(20, 20 + jl).toString());
const bin = buf.slice(20 + jl + 8);
ok(buf.readUInt32LE(8) === buf.length, 'glb length header is right');
ok(buf.length < 3 * 1048576, `small file (${(buf.length / 1024).toFixed(0)} KB)`);

const CT = { 5126: Float32Array, 5123: Uint16Array };
const NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
function acc(i) {
  const a = j.accessors[i], bv = j.bufferViews[a.bufferView], c = NC[a.type], T = CT[a.componentType];
  const o = (bv.byteOffset || 0) + (a.byteOffset || 0);
  if (o % T.BYTES_PER_ELEMENT) throw new Error('unaligned accessor ' + i);
  return new T(bin.buffer.slice(bin.byteOffset + o, bin.byteOffset + o + a.count * c * T.BYTES_PER_ELEMENT));
}

const nodes = j.nodes, names = nodes.map((x) => x.name);
ok(new Set(names).size === names.length, 'node names are unique (the mixer binds clips by name)');
ok(!names.some((x) => /[\s.\[\]:\/]/.test(x)), 'node names contain nothing the loader would rename');
const want = ['Hips', 'Torso', 'Head', 'Arm_R', 'Arm_L', 'Leg_R', 'Leg_L'];
ok(want.every((x) => names.includes(x)), 'joint nodes exist: ' + want.join(', '));
ok((j.skins || []).length === 0, 'no skin (plain node animation)');

// clips
const clipNames = (j.animations || []).map((a) => a.name);
ok(clipNames.includes(def.anims.idle) && clipNames.includes(def.anims.walk), `clips named in characters.json exist (${clipNames.join(', ')})`);
for (const a of j.animations) {
  let loop = true, inc = true, unit = true, targets = true, dur = 0;
  for (const ch of a.channels) {
    if (!(ch.target.node >= 0 && ch.target.node < nodes.length)) targets = false;
    const s = a.samplers[ch.sampler], t = acc(s.input), v = acc(s.output), c = ch.target.path === 'rotation' ? 4 : 3;
    dur = Math.max(dur, t[t.length - 1]);
    for (let i = 1; i < t.length; i++) if (!(t[i] > t[i - 1])) inc = false;
    for (let k = 0; k < c; k++) if (Math.abs(v[k] - v[(t.length - 1) * c + k]) > 1e-5) loop = false;   // last key == first key
    if (c === 4) for (let i = 0; i < t.length; i++) if (Math.abs(Math.hypot(v[i * 4], v[i * 4 + 1], v[i * 4 + 2], v[i * 4 + 3]) - 1) > 1e-4) unit = false;
  }
  ok(targets && inc && unit && loop, `clip "${a.name}" (${dur.toFixed(2)} s, ${a.channels.length} tracks): valid targets, increasing times, unit quaternions, loops seamlessly`);
}

// bind pose: forward kinematics of translations only (the bind pose has no rotations)
const parent = {}; nodes.forEach((x, i) => (x.children || []).forEach((c) => (parent[c] = i)));
const wpos = (i) => { let p = [0, 0, 0]; for (let k = i; k !== undefined; k = parent[k]) { const t = nodes[k].translation || [0, 0, 0]; p = [p[0] + t[0], p[1] + t[1], p[2] + t[2]]; } return p; };
let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9]; const partBox = {};
nodes.forEach((x, i) => {
  if (x.mesh === undefined) return;
  const pos = acc(j.meshes[x.mesh].primitives[0].attributes.POSITION), o = wpos(i);
  const bmn = [1e9, 1e9, 1e9], bmx = [-1e9, -1e9, -1e9];
  for (let v = 0; v < pos.length; v += 3) for (let k = 0; k < 3; k++) { const w = pos[v + k] + o[k]; bmn[k] = Math.min(bmn[k], w); bmx[k] = Math.max(bmx[k], w); }
  partBox[x.name] = [bmn, bmx]; for (let k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], bmn[k]); mx[k] = Math.max(mx[k], bmx[k]); }
});
ok(Math.abs(mx[1] - mn[1] - 1.8) < 0.01, `1.8 m tall (${(mx[1] - mn[1]).toFixed(3)})`);
ok(Math.abs(mn[1]) < 0.005, `feet on y=0 (${mn[1].toFixed(4)})`);
ok(Math.abs((mn[0] + mx[0]) / 2) < 0.01 && Math.abs((mn[2] + mx[2]) / 2) < 0.01, 'centred on x and z');
const cx = (b) => (b[0][0] + b[1][0]) / 2;
ok(cx(partBox.Arm_R) < -0.3 && cx(partBox.Arm_L) > 0.3 && cx(partBox.Leg_R) < 0 && cx(partBox.Leg_L) > 0, "character's right side is at -x (game convention)");
ok(partBox.Head[0][1] > partBox.Body[0][1] && partBox.Head[1][1] > 1.75, 'head on top');
// the face: head vertices whose UV is not the plain-colour corner must be on the +z side (character faces +z)
const hp = acc(j.meshes[nodes[names.indexOf('Head')].mesh === undefined ? nodes[names.indexOf('Head')].mesh : nodes[names.indexOf('Head')].mesh].primitives[0].attributes.POSITION);
const hu = acc(j.meshes[nodes[names.indexOf('Head')].mesh].primitives[0].attributes.TEXCOORD_0);
let sz = 0, cnt = 0; for (let v = 0; v < hu.length / 2; v++) if (Math.abs(hu[v * 2] - 0.8809) > 0.002 || Math.abs(hu[v * 2 + 1] - 0.9844) > 0.002) { sz += hp[v * 3 + 2]; cnt++; }
ok(cnt > 50 && sz / cnt > 0.1, `face is on the +z side (${cnt} face vertices, mean z ${(sz / cnt).toFixed(2)})`);
ok(j.images.length === 1 && j.images[0].mimeType === 'image/png', 'one embedded png texture');

console.log(`\n${n - fails}/${n} checks passed`);
process.exit(fails ? 1 : 0);
