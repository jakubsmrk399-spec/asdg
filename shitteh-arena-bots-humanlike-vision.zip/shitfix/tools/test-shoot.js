'use strict';
// Hitscan / aim assist / spawns on the real map, with a real server and ws bots.   NODE_PATH=<dir with ws> node tools/test-shoot.js
// The server runs IN this process (so the test can place players exactly: it sets the server's player state and the
// bot then claims that very pose, which the server accepts unchanged). Everything else goes over real websockets.
const path = require('path');
const fs = require('fs');
const PORT = 29000 + Math.floor(Math.random() * 900);
process.env.PORT = String(PORT); process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'x';
const WebSocket = require('ws');
const Collision = require('../public/shared/collision.js');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const { players } = require('../server.js');
const { T_SPAWNS, CT_SPAWNS, SITES } = require('../map.js');

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EYE = Collision.EYE;

function connect(name) {
  const b = { name, id: 0, seq: 0, welcome: null, dmg: [], hm: [], tr: [], kills: [], rs: [], ready: false, closed: false };
  b.ws = new WebSocket('ws://127.0.0.1:' + PORT);
  b.ws.on('open', () => b.ws.send(JSON.stringify({ t: 'join', name })));
  b.ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.t === 'welcome') { b.id = m.id; b.seq = m.you.seq; b.welcome = m; b.ready = true; }
    else if (m.t === 'dmg') b.dmg.push(m);
    else if (m.t === 'hm') b.hm.push(m);
    else if (m.t === 'tr') b.tr.push(m);
    else if (m.t === 'kill') b.kills.push(m);
    else if (m.t === 'rs') { b.rs.push(m); b.seq = m.seq; }
  });
  b.ws.on('close', () => { b.closed = true; });
  return b;
}
async function ready(b) { for (let i = 0; i < 300 && !b.ready; i++) await sleep(10); if (!b.ready) throw new Error('bot not ready'); }
const P = (b) => players.get(b.id);
const floor = (x, z) => col.floorY(x, z, 3, 0);
// put a player somewhere (server state) and make it alive and full hp
function place(b, x, z, y = floor(x, z)) {
  const p = P(b);
  Object.assign(p, { x, y, z, gy: y, air: 0, dead: false, hp: 100, lastMove: Date.now(), lastFire: 0 });
  b.pose = { x, y, z };
}
function dirTo(from, to) { const d = [to[0] - from[0], to[1] - from[1], to[2] - from[2]]; const L = Math.hypot(...d); return d.map((v) => v / L); }
const angles = (d) => ({ yaw: Math.atan2(-d[0], -d[2]), pitch: Math.asin(d[1]) });
function shoot(b, yaw, pitch) {
  b.ws.send(JSON.stringify({ t: 'f', x: b.pose.x, y: b.pose.y, z: b.pose.z, yaw, pitch, seq: b.seq }));
}
// shooter aims at a point (world coords) and fires once; returns what the target received
async function shootAt(sh, tg, aimPt, label) {
  const before = { dmg: tg.dmg.length, hm: sh.hm.length, tr: sh.tr.length };
  P(sh).lastFire = 0;
  const eye = [sh.pose.x, sh.pose.y + EYE, sh.pose.z];
  const { yaw, pitch } = angles(dirTo(eye, aimPt));
  shoot(sh, yaw, pitch);
  await sleep(120);
  return { hit: tg.dmg.length > before.dmg, dmg: tg.dmg[tg.dmg.length - 1], hm: sh.hm.length > before.hm ? sh.hm[sh.hm.length - 1] : null, tr: sh.tr.length > before.tr ? sh.tr[sh.tr.length - 1] : null };
}
async function admin(b, mode) {
  b.ws.send(JSON.stringify({ t: 'admin', pw: 'x' })); await sleep(60);
  b.ws.send(JSON.stringify({ t: 'aset', mode, strength: 0.5 })); await sleep(80);
}

async function main() {
  for (let i = 0; i < 100 && !/x/.test('x'); i++) await sleep(10);
  await sleep(300);

  // ---- 1. spawns ----
  {
    const bots = [];
    for (let i = 0; i < 16; i++) { const b = connect('sp' + i); await ready(b); bots.push(b); }
    let onFloor = 0, inWall = 0, minGap = Infinity;
    const pts = bots.map((b) => b.welcome.you);
    for (const s of pts) {
      const f = col.floorY(s.x, s.z, s.y + 0.5, 0);
      if (Math.abs(f - s.y) < 0.01) onFloor++;
      if (col.isSolid(s.x, s.y, s.z)) inWall++;
    }
    for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) minGap = Math.min(minGap, Math.hypot(pts[i].x - pts[j].x, pts[i].z - pts[j].z));
    ok(onFloor === 16 && inWall === 0, `16 bots (the server max): all spawned exactly on a floor (${onFloor}/16), none in a wall (${inWall})`);
    ok(minGap >= 1.5, `no two of the 16 spawned bots closer than 1.5 m (min gap ${minGap.toFixed(2)} m)`);
    const tSide = pts.filter((s) => s.z > 0).length, ctSide = pts.filter((s) => s.z < 0).length;
    ok(tSide > 0 && ctSide > 0, `both areas are used (T side ${tSide}, CT side ${ctSide})`);
    ok(bots.every((b) => b.welcome.world.map === 'dust2' && !('boxes' in b.welcome.world)), "welcome: world.map 'dust2', no world.boxes");
    // the 20 verified spawn points themselves (including those not used by the 16 bots)
    const all = T_SPAWNS.concat(CT_SPAWNS);
    let good = 0; for (const [x, z] of all) { const y = floor(x, z); if (y > -Infinity && !col.isSolid(x, y, z)) good++; }
    ok(good === all.length, `all ${all.length} spawn candidates in map.js are on a floor and not in a wall (${good})`);
    ok(bots[0].welcome.world.sites.length === 2, 'welcome carries 2 site markers');
    for (const [label, x, y, z] of bots[0].welcome.world.sites) {
      const f = floor(x, z); ok(Math.abs(f - y) < 0.05 && f > -Infinity, `site ${label} marker (${x}, ${y.toFixed(2)}, ${z}) stands on the floor (floor y ${f.toFixed(2)})`);
    }
    bots.forEach((b) => b.ws.close()); await sleep(300);
  }

  // ---- 2. hitscan ----
  const A = connect('shooter'), B = connect('target');
  await ready(A); await ready(B); await sleep(100);
  const body = (b) => [b.pose.x, b.pose.y + 0.85, b.pose.z], head = (b) => [b.pose.x, b.pose.y + 1.55, b.pose.z];
  {
    // (a) open T plateau
    place(A, -16.5, 24); place(B, -11.5, 26.5);
    ok(col.visible(A.pose.x, A.pose.y + EYE, A.pose.z, B.pose.x, B.pose.y + 1.0, B.pose.z), 'setup (a): the two spots see each other');
    let r = await shootAt(A, B, body(B));
    ok(r.hit && r.dmg.hp === 75 && r.hm && r.hm.h === 0, `(a) open floor, body shot: hit, hp 100 -> ${r.dmg && r.dmg.hp} (25 damage), not a headshot`);
    place(B, -11.5, 26.5);
    r = await shootAt(A, B, head(B));
    ok(r.hit && r.dmg.hp === 50 && r.hm && r.hm.h === 1, `(a) open floor, head shot: hp 100 -> ${r.dmg && r.dmg.hp} (50 damage), headshot flag ${r.hm && r.hm.h}`);
    place(B, -11.5, 26.5);
    r = await shootAt(A, B, [B.pose.x, B.pose.y + 4, B.pose.z]);
    ok(!r.hit, '(a) shot 3 m over the target: miss');

    // (b) through a real wall
    place(A, -5.5, -14); place(B, -2, -10);
    ok(!col.visible(A.pose.x, A.pose.y + EYE, A.pose.z, B.pose.x, B.pose.y + 1.0, B.pose.z), 'setup (b): a real wall is between the two (mesh says not visible)');
    r = await shootAt(A, B, body(B));
    ok(!r.hit && r.tr, '(b) aimed straight at the body through the real wall: NO hit');
    const dTr = r.tr ? Math.hypot(r.tr.e[0] - r.tr.f[0], r.tr.e[1] - r.tr.f[1], r.tr.e[2] - r.tr.f[2]) : 0;
    const dTg = Math.hypot(B.pose.x - A.pose.x, B.pose.z - A.pose.z);
    ok(r.tr && dTr < dTg - 0.3, `(b) tracer ends at the wall (${dTr.toFixed(1)} m) before the target (${dTg.toFixed(1)} m)`);
    place(B, -2, -10); r = await shootAt(A, B, head(B));
    ok(!r.hit, '(b) head shot through the wall: NO hit');

    // (c) where an old invisible box used to be (x -2..0, z -18..-14), but no real wall
    place(A, -5.5, -17); place(B, 0.5, -13.5);
    ok(col.visible(A.pose.x, A.pose.y + EYE, A.pose.z, B.pose.x, B.pose.y + 1.0, B.pose.z), 'setup (c): clear line of sight across the old box position');
    r = await shootAt(A, B, body(B));
    ok(r.hit && r.dmg.hp === 75, `(c) shot across the old invisible box: HIT (hp ${r.dmg && r.dmg.hp})`);

    // (d) player a wall-top / floor: shooting into the ground ends at the floor
    place(A, -16.5, 24); place(B, -11.5, 26.5);
    r = await shootAt(A, B, [A.pose.x + 1, A.pose.y - 5, A.pose.z]);
    ok(!r.hit && r.tr && r.tr.e[1] > A.pose.y - 0.2, `(d) shot into the ground ends on the floor (tracer end y ${r.tr && r.tr.e[1]}, floor ${A.pose.y.toFixed(2)})`);
  }

  // ---- 3. aim modes ----
  {
    const tracerDir = (tr) => { const d = [tr.e[0] - tr.f[0], tr.e[1] - tr.f[1], tr.e[2] - tr.f[2]]; const L = Math.hypot(...d); return d.map((v) => v / L); };
    const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    await admin(A, 'aimbot');
    // aimbot, target behind the wall, shooter looks the OTHER way: must not lock through the wall
    place(A, -5.5, -14); place(B, -2, -10);
    const eyeA = [A.pose.x, A.pose.y + EYE, A.pose.z];
    const away = [-1, 0, 0.3]; const L = Math.hypot(...away); const awayD = away.map((v) => v / L);
    P(A).lastFire = 0;
    let ang = angles(awayD); shoot(A, ang.yaw, ang.pitch); await sleep(120);
    let tr = A.tr[A.tr.length - 1]; const dmgBefore = B.dmg.length;
    ok(tr && dot(tracerDir(tr), awayD) > 0.99 && B.dmg.length === dmgBefore, `aimbot: target behind a wall is NOT locked (bullet kept the aimed direction, dot ${tr ? dot(tracerDir(tr), awayD).toFixed(3) : 'n/a'}, no damage)`);
    // aimbot, target in the open, shooter looks away: locks and hits
    place(A, -16.5, 24); place(B, -11.5, 26.5); P(A).lastFire = 0;
    const n0 = B.dmg.length; shoot(A, 0.2, 0.0); await sleep(120);
    ok(B.dmg.length === n0 + 1 && B.dmg[B.dmg.length - 1].hp === 50, `aimbot: target in the open is locked and head-shot from a wrong view direction (hp ${B.dmg[B.dmg.length - 1].hp})`);
    // assist with the target behind the wall: aimed through the wall, no bend
    await admin(A, 'assist');
    place(A, -5.5, -14); place(B, -2, -10); P(A).lastFire = 0;
    const eye2 = [A.pose.x, A.pose.y + EYE, A.pose.z];
    const d2 = dirTo(eye2, body(B)); ang = angles(d2); shoot(A, ang.yaw, ang.pitch); await sleep(120);
    tr = A.tr[A.tr.length - 1];
    ok(tr && dot(tracerDir(tr), d2) > 0.99999, `assist: target behind a wall does not bend the shot (dot ${tr ? dot(tracerDir(tr), d2).toFixed(6) : 'n/a'})`);
    // assist with the target in the open and the crosshair slightly off: the shot bends toward the target
    place(A, -16.5, 24); place(B, -11.5, 26.5); P(A).lastFire = 0;
    const eye3 = [A.pose.x, A.pose.y + EYE, A.pose.z];
    const dt3 = dirTo(eye3, [B.pose.x, B.pose.y + 1.0, B.pose.z]); ang = angles(dt3);
    shoot(A, ang.yaw + 0.05, ang.pitch); await sleep(120);
    tr = A.tr[A.tr.length - 1];
    ok(tr && dot(tracerDir(tr), dt3) > Math.cos(0.05) + 1e-6, `assist: shot 0.05 rad off an open target bends toward it (cos to target ${tr ? dot(tracerDir(tr), dt3).toFixed(5) : 'n/a'} > ${Math.cos(0.05).toFixed(5)})`);
    await admin(A, 'off');
  }

  // ---- 4. kill + respawn ----
  {
    place(A, -16.5, 24); place(B, -11.5, 26.5);
    const k0 = B.kills.length;
    await shootAt(A, B, head(B));                 // 100 -> 50
    const r2 = await shootAt(A, B, head(B));      // 50 -> 0
    ok(r2.hit && r2.hm && r2.hm.k === 1, 'second head shot reports a kill (hm.k = 1)');
    await sleep(100);
    ok(P(B).dead || B.kills.length > k0, 'two head shots (hp 100) kill the target');
    const rs0 = B.rs.length; await sleep(3400);
    const rs = B.rs[B.rs.length - 1];
    ok(B.rs.length > rs0 && P(B).hp === 100 && !P(B).dead, 'respawn after 3 s: hp restored and alive');
    ok(rs && Math.abs(col.floorY(rs.x, rs.z, rs.y + 0.5, 0) - rs.y) < 0.01 && !col.isSolid(rs.x, rs.y, rs.z), `respawn point (${rs && rs.x}, ${rs && rs.y.toFixed(2)}, ${rs && rs.z}) is on a floor, not in a wall`);
  }

  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
