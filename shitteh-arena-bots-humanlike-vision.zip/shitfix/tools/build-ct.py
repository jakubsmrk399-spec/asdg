#!/usr/bin/env python3
"""Repack the Sketchfab "CT Gign" glb for the game.
   python3 tools/build-ct.py ct_gign.glb public/models/ct_gign.glb
The downloaded file REQUIRES the KHR_materials_pbrSpecularGlossiness extension, which the three.js version used by the game (r160)
no longer supports: loaded as-is every material would come out untextured. What this does (geometry, skeleton and bind pose are untouched):
  * each material is turned into a plain metallic-roughness one: the diffuse texture / colour become the base colour texture / colour
    (including the 49 % opacity of the visor), the extension is removed from extensionsUsed / extensionsRequired;
  * keeps only the two base colour textures; the specular-glossiness map and the normal map are dropped (the game uses simple lit materials);
  * the 1024 px body texture is re-encoded as JPEG (it has no alpha): 2.6 MB -> about 0.5 MB.
"""
import struct, json, sys, io
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
b = open(src, 'rb').read()
jl = struct.unpack('<I', b[12:16])[0]
j = json.loads(b[20:20 + jl])
bin0 = 20 + jl + 8
EXT = 'KHR_materials_pbrSpecularGlossiness'

# 1. materials: spec-gloss -> metal-rough, remember which textures stay
keep_tex = []
for m in j['materials']:
    sg = (m.get('extensions') or {}).pop(EXT, None)
    if not m.get('extensions'): m.pop('extensions', None)
    m.pop('normalTexture', None)
    pbr = {'metallicFactor': 0.0, 'roughnessFactor': 0.6}
    if sg:
        if 'diffuseFactor' in sg: pbr['baseColorFactor'] = sg['diffuseFactor']
        if 'diffuseTexture' in sg:
            t = sg['diffuseTexture']['index']
            if t not in keep_tex: keep_tex.append(t)
            pbr['baseColorTexture'] = {'index': t}
    m['pbrMetallicRoughness'] = pbr
for k in ('extensionsUsed', 'extensionsRequired'):
    if k in j:
        j[k] = [e for e in j[k] if e != EXT]
        if not j[k]: del j[k]

# 2. textures / images: keep only the base colour ones, renumbered
tex_map = {t: i for i, t in enumerate(keep_tex)}
old_tex, old_img = j['textures'], j['images']
new_tex, new_img, img_of_tex = [], [], {}
for t in keep_tex:
    s = old_tex[t]['source']
    if s not in img_of_tex:
        img_of_tex[s] = len(new_img); new_img.append(old_img[s])
    nt = dict(old_tex[t]); nt['source'] = img_of_tex[s]; new_tex.append(nt)
for m in j['materials']:
    bc = m['pbrMetallicRoughness'].get('baseColorTexture')
    if bc: bc['index'] = tex_map[bc['index']]

# 3. rebuild the binary chunk: every buffer view except the dropped images', textures re-encoded
img_views = {im['bufferView'] for im in old_img}
kept_views = {im['bufferView'] for im in new_img}
out = bytearray(); new_bvs = []; remap = {}
for i, bv in enumerate(j['bufferViews']):
    if i in img_views and i not in kept_views: continue
    while len(out) % 4: out.append(0)
    o = bin0 + bv.get('byteOffset', 0)
    data = b[o:o + bv['byteLength']]
    nb = {k: v for k, v in bv.items() if k not in ('byteOffset', 'byteLength', 'buffer')}
    if i in kept_views:
        img = Image.open(io.BytesIO(data))
        has_alpha = img.mode == 'RGBA' and img.getextrema()[3][0] < 255
        if not has_alpha:                           # real alpha would be lost in a JPEG: those stay PNG
            buf = io.BytesIO(); img.convert('RGB').save(buf, 'JPEG', quality=88, optimize=True); data = buf.getvalue()
            for im in new_img:
                if im['bufferView'] == i: im['mimeType'] = 'image/jpeg'
    remap[i] = len(new_bvs)
    new_bvs.append({'buffer': 0, 'byteOffset': len(out), 'byteLength': len(data), **nb}); out.extend(data)
for a in j['accessors']:
    if 'bufferView' in a: a['bufferView'] = remap[a['bufferView']]
for im in new_img: im['bufferView'] = remap[im['bufferView']]
j['bufferViews'] = new_bvs; j['textures'] = new_tex; j['images'] = new_img
while len(out) % 4: out.append(0)
j['buffers'] = [{'byteLength': len(out)}]

jb = json.dumps(j, separators=(',', ':')).encode()
while len(jb) % 4: jb += b' '
total = 12 + 8 + len(jb) + 8 + len(out)
with open(dst, 'wb') as f:
    f.write(struct.pack('<III', 0x46546C67, 2, total))
    f.write(struct.pack('<II', len(jb), 0x4E4F534A)); f.write(jb)
    f.write(struct.pack('<II', len(out), 0x004E4942)); f.write(bytes(out))
print(f'{src} ({len(b) / 1e6:.2f} MB) -> {dst} ({total / 1e6:.2f} MB), textures kept: {len(new_img)}')
