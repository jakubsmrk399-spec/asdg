'use strict';
// Model-accurate hit areas through a real server + ws bots (server runs in this process).   NODE_PATH=<dir with ws> node tools/test-hitmodel.js
// The shooter always stands on the target's forward axis, so "local x" below is straight sideways across the target's screen.
const path = require('path');
const PORT = 29000 + Math.floor(Math.random() * 900);
process.env.PORT = String(PORT); process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'x';
const WebSocket = require('ws');
const Collision = require('../public/shared/collision.js');
const fs = require('fs');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const { players } = require('../server.js');
const HB = require('../hitboxes.js');
let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function connect(name) {
  const b = { name, id: 0, seq: 0, ready: false, dmg: [], hm: [] };
  b.ws = new WebSocket('ws://127.0.0.1:' + PORT);
  b.ws.on('open', () => b.ws.send(JSON.stringify({ t: 'join', name })));
  b.ws.on('message', (raw) => { const m = JSON.parse(raw); if (m.t === 'welcome') { b.id = m.id; b.seq = m.you.seq; b.ready = true; b.world = m.world; } else if (m.t === 'dmg') b.dmg.push(m); else if (m.t === 'hm') b.hm.push(m); else if (m.t === 'rs') b.seq = m.seq; });
  return b;
}
const ready = async (b) => { for (let i = 0; i < 300 && !b.ready; i++) await sleep(10); if (!b.ready) throw new Error('bot not ready'); };
const P = (b) => players.get(b.id);

async function main() {
  await sleep(300);
  const D = Collision.dims(), H = 1.8 * D.s, EYE = Collision.EYE;   // metres per model unit
  const A = connect('shooter'), N = connect('NOOB'), F = connect('target');   // NOOB -> noob.glb, "target" -> default phoenix
  for (const b of [A, N, F]) await ready(b);
  const floor = (x, z) => col.floorY(x, z, 3, 0);
  const AX = -16.5, AZ = 24;
  async function trial(tg, lx, ly, crouch) {
    // target 5 m from the shooter, turned to face the shooter; aim at (lx, ly) in the target's own frame (units of its height)
    const TX = -11.5, TZ = 26.5;
    const f = [AX - TX, AZ - TZ]; const L = Math.hypot(...f); f[0] /= L; f[1] /= L;
    const yaw = Math.atan2(-f[0], -f[1]), c = Math.cos(yaw), s = Math.sin(yaw);
    const ty = floor(TX, TZ), ay = floor(AX, AZ);
    for (const b of [N, F]) if (b !== tg) Object.assign(P(b), { x: 60, z: 60, dead: true });   // park the others: nobody may stand in the line of fire
    const pt = P(tg), pa = P(A);
    Object.assign(pt, { x: TX, y: ty, z: TZ, gy: ty, air: 0, dead: false, hp: 100, yaw, crouch: crouch ? 1 : 0, lastMove: Date.now() });
    Object.assign(pa, { x: AX, y: ay, z: AZ, gy: ay, air: 0, dead: false, hp: 100, pitch: 0, lastMove: Date.now(), lastFire: 0 });
    const k = crouch ? 0.64 : 1;
    const lxm = lx * H, lzm = 0;
    const world = [TX + lxm * c + lzm * s, ty + ly * H * k, TZ - lxm * s + lzm * c];
    const eye = [AX, ay + EYE, AZ];
    const d = [world[0] - eye[0], world[1] - eye[1], world[2] - eye[2]]; const dl = Math.hypot(...d);
    const before = tg.dmg.length, hm0 = A.hm.length;
    A.ws.send(JSON.stringify({ t: 'f', x: AX, y: ay, z: AZ, yaw: Math.atan2(-d[0], -d[2]), pitch: Math.asin(d[1] / dl), seq: A.seq }));
    await sleep(110);
    const hit = tg.dmg.length > before;
    return { hit, head: hit && A.hm.length > hm0 ? A.hm[A.hm.length - 1].h === 1 : null };
  }

  // noob: blocky body, arms hang at 0.20..0.39 of its height to each side, head is a box above 0.76
  let r = await trial(N, 0.30, 0.60);   ok(r.hit && !r.head, `noob: shot at the arm (0.30 H to the side) hits, body damage`);
  r = await trial(N, 0.46, 0.60);       ok(!r.hit, 'noob: shot just outside the arm (0.46 H) misses');
  r = await trial(N, 0.0, 0.92);        ok(r.hit && r.head, 'noob: shot at the middle of the head is a headshot');
  r = await trial(N, 0.20, 0.92);       ok(!r.hit, 'noob: shot beside the head (0.20 H, head is +-0.12 H) misses');
  r = await trial(N, 0.0, 1.03);        ok(!r.hit, 'noob: shot above the head misses');
  r = await trial(N, 0.0, 0.40, true); ok(r.hit && !r.head, 'noob crouching: torso shot (0.40 of the crouched height) hits');
  r = await trial(N, 0.0, 0.92, true); ok(r.hit && r.head, 'noob crouching: the head comes down with the player (headshot)');
  // default model (phoenix): slim, no wide arms in the hit shape
  r = await trial(F, 0.0, 0.50);        ok(r.hit && !r.head, 'phoenix: chest shot hits');
  r = await trial(F, 0.24, 0.55);       ok(!r.hit, 'phoenix: shot 0.24 H beside the chest misses (the old 0.30 m sphere would have hit it)');
  r = await trial(F, 0.0, 0.93);        ok(r.hit && r.head, 'phoenix: shot at the head is a headshot');

  // aimbot locks onto the middle of the model's head, whatever model it is
  A.ws.send(JSON.stringify({ t: 'admin', pw: 'x' })); await sleep(60);
  A.ws.send(JSON.stringify({ t: 'aset', mode: 'aimbot', strength: 0.5 })); await sleep(80);
  for (const [tg, nm] of [[N, 'noob'], [F, 'phoenix']]) {
    const TX = -11.5, TZ = 26.5, ty = floor(TX, TZ), ay = floor(AX, AZ);
    Object.assign(P(N), { x: 60, z: 60, dead: true }); Object.assign(P(F), { x: 60, z: 60, dead: true });
    Object.assign(P(tg), { x: TX, y: ty, z: TZ, gy: ty, air: 0, dead: false, hp: 100, yaw: 0.7, crouch: 0 });
    Object.assign(P(A), { x: AX, y: ay, z: AZ, gy: ay, air: 0, dead: false, pitch: 0, lastMove: Date.now(), lastFire: 0 });
    const before = tg.dmg.length;
    A.ws.send(JSON.stringify({ t: 'f', x: AX, y: ay, z: AZ, yaw: 2.9, pitch: 0.2, seq: A.seq }));   // looking nowhere near it
    await sleep(120);
    ok(tg.dmg.length > before && tg.dmg[tg.dmg.length - 1].hp === 50, `aimbot vs ${nm}: locked and landed a headshot (hp ${tg.dmg[tg.dmg.length - 1] && tg.dmg[tg.dmg.length - 1].hp})`);
  }
  console.log(fails ? `\n${fails} FAILED` : '\nall passed');
  process.exit(fails ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
