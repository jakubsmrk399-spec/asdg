'use strict';
// Full playtest + performance: the REAL server in a child process, 16 ws bots for 60 s.
//   NODE_PATH=<dir with ws> node tools/test-playtest.js [seconds=60]
// Bots walk with the shared mover (same code as the browser), shoot the nearest player (also through walls), use the
// stuck rescue like the client does. An admin bot switches aim off -> assist -> aimbot -> off. Checks: no server error,
// kills/deaths consistent with 'kill' messages, spawns on a floor, aim messages reach everybody, reconnect, 17th player
// refused, rate limit, CPU / memory of the server process.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const Collision = require('../public/shared/collision.js');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const { T_SPAWNS, CT_SPAWNS } = require('../map.js');

const DURATION = (parseInt(process.argv[2], 10) || 60) * 1000;
const PORT = 29000 + Math.floor(Math.random() * 900);
let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EYE = Collision.EYE, SPEED = Collision.SPEED;
const WAYPOINTS = T_SPAWNS.concat(CT_SPAWNS);

// ---- server child + /proc CPU sampling ----
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', ADMIN_PASSWORD: 'x' } });
let srvLog = '', srvDead = false;
srv.stdout.on('data', (d) => { srvLog += d; });
srv.stderr.on('data', (d) => { srvLog += d; });
srv.on('exit', () => { srvDead = true; });
const TICKS = 100; // clock ticks per second on Linux
function cpuTicks() { const f = fs.readFileSync(`/proc/${srv.pid}/stat`, 'utf8').split(') ')[1].split(' '); return +f[11] + +f[12]; } // utime + stime
function rssMB() { return +(/VmRSS:\s+(\d+)/.exec(fs.readFileSync(`/proc/${srv.pid}/status`, 'utf8'))[1]) / 1024; }

// ---- bots ----
const bots = [];
const snap = new Map(); // id -> latest broadcast entry [id,x,y,z,yaw,pitch,hp,kills,deaths]
const killMsgs = [];    // every 'kill' message seen by the observer (bot 0)
const stats = { shots: 0, stuckSent: 0, stuckRescued: 0, stuckRefused: 0, rsLost: 0, badSpawn: 0, spawnsChecked: 0, aimMsgs: {}, tracers: 0 };
const lastBroadcastAt = { t: 0 };

function makeBot(i, opts = {}) {
  const b = { i, id: 0, seq: 0, ready: false, closed: false, closeCode: 0, full: false, s: { x: 0, y: 0, z: 0, vy: 0, ground: false }, yaw: 0, pitch: 0,
              wp: null, wpT: 0, hp: 100, aim: null, isAdmin: false, stuckT: 0, sax: 0, say: 0, saz: 0, stuckSent: -1e9, lastRs: 0, fireAt: 0, stopped: false };
  b.ws = new WebSocket('ws://127.0.0.1:' + PORT);
  b.ws.on('open', () => { b.ws.send(JSON.stringify({ t: 'join', name: 'bot' + i })); if (opts.admin) setTimeout(() => b.ws.send(JSON.stringify({ t: 'admin', pw: 'x' })), 150); });
  b.ws.on('close', (code) => { b.closed = true; b.closeCode = code; });
  b.ws.on('error', () => {});
  b.ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    switch (m.t) {
      case 'welcome':
        b.id = m.id; b.seq = m.you.seq; b.ready = true; Object.assign(b.s, { x: m.you.x, y: m.you.y, z: m.you.z, vy: 0, ground: false });
        b.yaw = m.you.yaw; b.sax = m.you.x; b.say = m.you.y; b.saz = m.you.z;
        stats.spawnsChecked++; if (!spawnOk(m.you.x, m.you.y, m.you.z)) stats.badSpawn++;
        b.welcomeWorld = m.world; b.aim = m.aim.mode;
        break;
      case 'full': b.full = true; break;
      case 'rs':
        b.seq = m.seq; Object.assign(b.s, { x: m.x, y: m.y, z: m.z, vy: 0, ground: false }); b.yaw = m.yaw; b.hp = m.hp == null ? 100 : m.hp; b.lastRs = Date.now();
        b.stuckT = 0; b.sax = m.x; b.say = m.y; b.saz = m.z;
        stats.spawnsChecked++; if (!spawnOk(m.x, m.y, m.z)) stats.badSpawn++;
        if (b.expectStuck) { stats.stuckRescued++; b.expectStuck = false; }
        break;
      case 'stuckno': stats.stuckRefused++; b.expectStuck = false; break;
      case 'dmg': b.hp = m.hp; break;
      case 'aim': b.aim = m.mode; (stats.aimMsgs[m.mode] = stats.aimMsgs[m.mode] || new Set()).add(b.i); break;
      case 'admin': if (m.ok) b.isAdmin = true; break;
      case 'tr': stats.tracers++; break;
      case 'kill': if (b.i === 0) killMsgs.push({ ...m, t: Date.now(), kp: snap.get(m.k) && snap.get(m.k).slice(), vp: snap.get(m.v) && snap.get(m.v).slice() }); break;
      case 's': if (b.i === 0) { snap.clear(); for (const e of m.p) snap.set(e[0], e); lastBroadcastAt.t = Date.now(); } break;
    }
  });
  return b;
}
const spawnOk = (x, y, z) => { const f = col.floorY(x, z, 3, 0); return f !== -Infinity && Math.abs(f - y) < 0.1 && !col.isSolid(x, y, z); };

let last = Date.now();
function simulate() {
  const now = Date.now(), dt = Math.min((now - last) / 1000, 0.05); last = now;
  for (const b of bots) {
    if (!b.ready || b.closed || b.stopped) continue;
    const me = snap.get(b.id);
    if (me && me[6] <= 0) continue; // dead: wait for the respawn
    if (!b.wp || now > b.wpT) { const w = WAYPOINTS[Math.floor(Math.random() * WAYPOINTS.length)]; b.wp = w; b.wpT = now + 1000 + Math.random() * 3000; }
    let dx = b.wp[0] - b.s.x, dz = b.wp[1] - b.s.z; const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L;
    if (L < 1) { b.wpT = 0; }
    const jump = Math.random() < 0.01;
    col.step(b.s, dt, dx, dz, jump);
    // aim at the nearest other player from the latest broadcast
    let best = null, bd = Infinity;
    for (const [id, e] of snap) { if (id === b.id || e[6] <= 0) continue; const d = Math.hypot(e[1] - b.s.x, e[3] - b.s.z); if (d < bd) { bd = d; best = e; } }
    if (best) { const ex = best[1] - b.s.x, ey = best[2] + 1.0 - (b.s.y + EYE), ez = best[3] - b.s.z; b.yaw = Math.atan2(-ex, -ez); b.pitch = Math.asin(ey / Math.hypot(ex, ey, ez)); }
    // stuck detection, same rule as the browser client
    const moving = true;
    if (moving) {
      if (Math.hypot(b.s.x - b.sax, b.s.z - b.saz) > 0.2 || Math.abs(b.s.y - b.say) > 0.2) { b.sax = b.s.x; b.say = b.s.y; b.saz = b.s.z; b.stuckT = 0; } else b.stuckT += dt;
      if ((b.stuckT >= 5 || (b.stuckT >= 2 && col.penetration(b.s.x, b.s.y, b.s.z) > 0.01)) && now - b.stuckSent >= 10000) {
        b.stuckSent = now; b.stuckT = 0; b.expectStuck = true; stats.stuckSent++; b.ws.send(JSON.stringify({ t: 'stuck' }));
      }
    }
    if (b.s.lost) { stats.rsLost++; b.s.lost = false; }
    // shoot
    if (best && bd < 60 && now >= b.fireAt && !b.noFire) { b.fireAt = now + 150; stats.shots++; b.ws.send(JSON.stringify({ t: 'f', ...pose(b) })); }
  }
}
const r2 = (v) => Math.round(v * 100) / 100;
const pose = (b) => ({ x: r2(b.s.x), y: r2(b.s.y), z: r2(b.s.z), yaw: Math.round(b.yaw * 1000) / 1000, pitch: Math.round(b.pitch * 1000) / 1000, seq: b.seq });
function sendPoses() { for (const b of bots) if (b.ready && !b.closed && !b.stopped && (!snap.get(b.id) || snap.get(b.id)[6] > 0)) b.ws.send(JSON.stringify({ t: 'm', ...pose(b) })); }

(async () => {
  for (let i = 0; i < 100 && !/running on/.test(srvLog); i++) await sleep(100);
  ok(/running on/.test(srvLog), 'server started');
  for (let i = 0; i < 16; i++) { bots.push(makeBot(i, { admin: i === 0 })); await sleep(30); }
  for (let i = 0; i < 300 && !bots.every((b) => b.ready); i++) await sleep(10);
  ok(bots.every((b) => b.ready) && new Set(bots.map((b) => b.id)).size === 16, '16 bots joined with distinct ids');
  ok(bots.every((b) => b.welcomeWorld && b.welcomeWorld.map === 'dust2'), 'welcome says world.map dust2');
  await sleep(300);
  ok(bots[0].isAdmin, 'admin bot logged in');
  const adminBot = bots[0];

  const simT = setInterval(simulate, 16), poseT = setInterval(sendPoses, 50);
  const t0 = Date.now(); const cpu0 = cpuTicks(); const rss0 = rssMB();
  let cpuWin = null;
  const sample = { a: null };
  const modes = [[0.33, 'assist'], [0.58, 'aimbot'], [0.83, 'off']];
  let mi = 0, reconnected = false, fullChecked = false, modeResults = [];
  while (Date.now() - t0 < DURATION) {
    const el = (Date.now() - t0) / DURATION;
    if (el >= 0.08 && !sample.a) sample.a = { t: Date.now(), c: cpuTicks() };
    if (el >= 0.42 && sample.a && !cpuWin) { const t = Date.now(), c = cpuTicks(); cpuWin = { pct: ((c - sample.a.c) / TICKS) / ((t - sample.a.t) / 1000) * 100, secs: (t - sample.a.t) / 1000 }; }
    if (mi < modes.length && el >= modes[mi][0]) {
      const mode = modes[mi][1]; mi++;
      stats.aimMsgs[mode] = new Set();
      adminBot.ws.send(JSON.stringify({ t: 'aset', mode, strength: 0.5 }));
      await sleep(400);
      modeResults.push([mode, bots.filter((b) => !b.closed && b.aim === mode).length, bots.filter((b) => !b.closed).length]);
    }
    if (!reconnected && el >= 0.62) { // disconnect + reconnect one bot
      reconnected = true;
      const old = bots[5]; const oldId = old.id; old.stopped = true; old.ws.close(); await sleep(600);
      ok(!snap.has(oldId), `disconnected bot #${oldId} disappears from the state broadcast`);
      const nb = makeBot(5); bots[5] = nb;
      for (let i = 0; i < 300 && !nb.ready; i++) await sleep(10);
      ok(nb.ready && nb.id !== oldId, `bot reconnected with a new id (#${nb.id}) and got a welcome`);
      await sleep(300);
      ok(snap.has(nb.id), 'reconnected bot is in the state broadcast');
    }
    if (reconnected && !fullChecked && el >= 0.7) {
      fullChecked = true;
      const x = makeBot(99); await sleep(500);
      ok(x.full && !x.ready, '17th connection gets "full" (MAX_PLAYERS 16)'); x.ws.close();
    }
    await sleep(100);
  }
  ok(!!cpuWin, 'CPU window measured');
  const cpuAll = ((cpuTicks() - cpu0) / TICKS) / ((Date.now() - t0) / 1000) * 100;
  const rss1 = rssMB();

  // stop shooting, let everyone respawn, then compare the counters
  for (const b of bots) b.noFire = true;
  await sleep(3800);
  clearInterval(simT); clearInterval(poseT);
  await sleep(400);
  const present = [...snap.keys()];
  ok(present.length === 16, `16 players in the final broadcast (${present.length})`);
  const tk = new Map(), td = new Map();
  for (const k of killMsgs) { tk.set(k.k, (tk.get(k.k) || 0) + 1); td.set(k.v, (td.get(k.v) || 0) + 1); }
  let bad = 0, sumK = 0, sumD = 0;
  for (const id of present) { const e = snap.get(id); sumK += e[7]; sumD += e[8]; if ((tk.get(id) || 0) !== e[7] || (td.get(id) || 0) !== e[8]) { bad++; console.log('   mismatch id', id, 'kill msgs', tk.get(id) || 0, td.get(id) || 0, 'scoreboard', e[7], e[8]); } }
  ok(bad === 0, `scoreboard kills/deaths match the 'kill' messages for all ${present.length} players (${killMsgs.length} kills seen)`);
  const killsByPresent = killMsgs.filter((k) => present.includes(k.k)).length, deathsByPresent = killMsgs.filter((k) => present.includes(k.v)).length;
  ok(sumK === killsByPresent && sumD === deathsByPresent, `sum of kills ${sumK} / deaths ${sumD} equals the kill messages involving the present players (${killsByPresent}/${deathsByPresent})`);
  ok(killMsgs.length >= 20, `plenty of fighting: ${killMsgs.length} kills, ${stats.shots} shots, ${stats.tracers} tracers`);
  ok(snap.size && [...snap.values()].every((e) => e[6] > 0), 'everybody is alive again after the respawn delay (respawn works)');

  // through-the-wall kills: line of sight from killer eye to victim body/head at the last known positions
  // (positions come from the 20 Hz broadcast, so allow some slack: only report the share, fail above 25%)
  let los = 0, noLos = 0;
  for (const k of killMsgs) {
    if (!k.kp || !k.vp) continue;
    const eye = [k.kp[1], k.kp[2] + EYE, k.kp[3]];
    const vis = col.visible(eye[0], eye[1], eye[2], k.vp[1], k.vp[2] + 0.85, k.vp[3]) || col.visible(eye[0], eye[1], eye[2], k.vp[1], k.vp[2] + 1.55, k.vp[3]) || Math.hypot(k.kp[1] - k.vp[1], k.kp[3] - k.vp[3]) < 1.5;
    if (vis) los++; else noLos++;
  }
  ok(noLos <= 0.25 * (los + noLos), `kills with NO line of sight at the broadcast positions: ${noLos} of ${los + noLos} (slack: positions are 50-100 ms stale; bots shoot through walls all the time, the server must not let it count)`);
  // raycast cost on realistic shots (player eye -> another player's body, positions from the broadcast)
  {
    const ps = [...snap.values()]; let n = 0; const t = process.hrtime.bigint();
    for (let r = 0; r < 20; r++) for (const a of ps) for (const c of ps) { if (a === c) continue; const dx = c[1] - a[1], dy = c[2] + 0.85 - (a[2] + EYE), dz = c[3] - a[3]; const L = Math.hypot(dx, dy, dz); col.raycast(a[1], a[2] + EYE, a[3], dx / L, dy / L, dz / L, 150); n++; }
    stats.rayUs = Number(process.hrtime.bigint() - t) / 1000 / n;
    console.log(`   raycast on realistic player-to-player rays: ${stats.rayUs.toFixed(1)} us each (${n} rays)`);
  }
  ok(stats.badSpawn === 0, `no spawn inside a wall or off the floor (${stats.spawnsChecked} welcomes/respawns checked)`);
  console.log(`   stuck rescue: ${stats.stuckSent} requests, ${stats.stuckRescued} rescued, ${stats.stuckRefused} refused; falls off the map seen client-side: ${stats.rsLost}`);
  for (const [mode, n, total] of modeResults) ok(n === total, `aim mode '${mode}' reached ${n}/${total} bots after the admin switch`);
  ok(stats.aimMsgs.aimbot && stats.aimMsgs.aimbot.size >= 15, 'aimbot period: every bot got the aim message');

  // rate limit: a flood from one connection is closed with 1008
  const fl = new WebSocket('ws://127.0.0.1:' + PORT); let flCode = 0; fl.on('close', (c) => { flCode = c; }); fl.on('error', () => {});
  await new Promise((r) => fl.on('open', r));
  for (let i = 0; i < 400; i++) fl.send(JSON.stringify({ t: 'm', x: 0, y: 0, z: 0, yaw: 0, pitch: 0, seq: 0 }));
  await sleep(500);
  ok(flCode === 1008, `message flood is closed with 1008 (code ${flCode})`);

  ok(!srvDead, 'server process still running');
  ok(!/Error|Exception|Unhandled|TypeError|RangeError|at .*\.js:\d+/.test(srvLog.replace(/ERROR/g, '')), 'no exception in the server log');
  const logTail = srvLog.split('\n').filter((l) => /stuck|ERROR|dropped/.test(l));
  console.log(`   server log: ${logTail.length} stuck/error lines`);
  console.log(`\nPERFORMANCE (server process, 16 bots walking + shooting): CPU ${cpuWin.pct.toFixed(1)}% of one core over ${cpuWin.secs.toFixed(0)} s window, ${cpuAll.toFixed(1)}% over the whole ${(DURATION / 1000)} s run; RSS ${rss0.toFixed(0)} MB at start, ${rss1.toFixed(0)} MB at end`);
  ok(cpuWin.pct < 10, `server CPU ${cpuWin.pct.toFixed(1)}% of one core < 10%`);

  for (const b of bots) { try { b.ws.close(); } catch {} }
  srv.kill();
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); srv.kill(); process.exit(1); });
