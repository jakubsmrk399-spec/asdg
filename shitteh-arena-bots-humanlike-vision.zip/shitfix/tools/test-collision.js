'use strict';
// Unit tests for public/shared/collision.js against the real map.   node tools/test-collision.js
const fs = require('fs');
const path = require('path');
const Collision = require('../public/shared/collision.js');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8'));
let t0 = process.hrtime.bigint();
const col = Collision.create(data);
console.log('index build ms', Number(process.hrtime.bigint() - t0) / 1e6, 'tris', col.triangles);

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const near = (a, b, e = 0.02) => Math.abs(a - b) <= e;

// ---- 1. floors at known points ----
const F = (x, z, y = 100) => col.floorY(x, z, y, 0);
const floorCases = [['A site', 19.7, -17.2, 1.28], ['B site', -17.4, -20.9, 0.0], ['mid', -1, 5, 0.0], ['CT block', -4, -15, -1.71]];
for (const [n, x, z, y] of floorCases) { const f = F(x, z, y + 0.6); ok(near(f, y, 0.05), `floor ${n} (${x},${z}) = ${f.toFixed(3)} expected ${y}`); }
{
  const lo = col.floorY(-18, -3, 1.0, 0.5), hi = col.floorY(-18, -3, 3.0, 0.5);
  ok(near(lo, 0.43, 0.05), `tunnel lower floor ${lo.toFixed(3)} (0.43)`);
  ok(near(hi, 2.56, 0.05), `tunnel upper floor ${hi.toFixed(3)} (2.56)`);
}

// ---- 2. simulated walks ----
const sim = (x, y, z) => ({ x, y, z, vy: 0, ground: false });
function walk(s, wx, wz, seconds, opt = {}) {
  const dt = opt.dt || 1 / 60, n = Math.round(seconds / dt);
  let l = Math.hypot(wx, wz) || 1;
  for (let i = 0; i < n; i++) {
    col.step(s, dt, wx / l, wz / l, opt.jump && i % 40 === 0);
    if (col.penetration(s.x, s.y, s.z) > 0.06) return { bad: `inside wall at (${s.x.toFixed(2)},${s.y.toFixed(2)},${s.z.toFixed(2)}) after ${i} steps` };
    if (s.lost) return { lost: true };
    if (!Number.isFinite(s.x + s.y + s.z)) return { bad: 'NaN' };
  }
  return {};
}
function settle(s) { for (let i = 0; i < 30; i++) col.step(s, 1 / 60, 0, 0, false); return s; }

{
  // standing: settles on the floor and stays
  const s = settle(sim(-1, 3, 5)); ok(s.ground && near(s.y, 0, 0.05), `drop to floor at mid y=${s.y.toFixed(3)} ground=${s.ground}`);
  // jump: apex ~1.33 and lands again
  let apex = -9; const j = settle(sim(-1, 0, 5));
  col.step(j, 1 / 60, 0, 0, true); for (let i = 0; i < 120; i++) { col.step(j, 1 / 60, 0, 0, false); apex = Math.max(apex, j.y); }
  ok(near(apex, 1.33, 0.12) && j.ground && near(j.y, 0, 0.02), `jump apex ${apex.toFixed(2)} lands y=${j.y.toFixed(3)}`);
  // walls block: walk long A west->east and hard into the east edge
  const e = settle(sim(-1, 0.1, 5)); const r = walk(e, -1, 0, 3); ok(!r.bad && !col.isSolid(e.x, e.y, e.z), `walk west from mid (-1,5) stops at x=${e.x.toFixed(2)} y=${e.y.toFixed(2)} ${r.bad || r.lost ? 'LOST' : ''}`);
  // route: T spawn -> mid -> A (via long) etc
  const routes = {
    'T spawn north to mid and CT': [[-20, 20], [[0, -1, 2], [1, 0, 1], [0, -1, 6]]],
    'long A to A site': [[22, 25], [[0, -1, 9]]],
  };
  const s2 = settle(sim(22, 0.5, 8)); const r2 = walk(s2, 0, -1, 4); console.log('   long A walk ->', s2.x.toFixed(2), s2.y.toFixed(2), s2.z.toFixed(2), r2.bad || 'no problems');
  ok(!r2.bad && !r2.lost && s2.y > -3, 'long A walk north stays on the map');
}

// random walkers: never inside a wall, never fall out, always finite
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
{
  const R = rng(7); const b = col.bounds; let bad = 0, total = 0, maxPen = 0, lostN = 0, squeeze = 0;
  for (let w = 0; w < 400; w++) {
    // find a free start on a floor
    let s = null;
    for (let k = 0; k < 200 && !s; k++) {
      const x = b.minx + R() * (b.maxx - b.minx), z = b.minz + R() * (b.maxz - b.minz);
      const f = col.floorY(x, z, 1.5, 0.5);
      if (f > -Infinity && !col.isSolid(x, f, z)) s = sim(x, f, z);
    }
    if (!s) continue;
    let ang = R() * 6.283, prevY = s.y;
    for (let i = 0; i < 1500; i++) {
      if (i % 40 === 0) ang += (R() - 0.5) * 2.5;
      prevY = s.y;
      col.step(s, i % 7 === 0 ? 0.05 : 1 / 60, Math.cos(ang), Math.sin(ang), R() < 0.02);
      total++;
      if (s.lost) { lostN++; break; } // walked off the map edge: the server respawns the player
      const pen = col.penetration(s.x, s.y, s.z); if (pen > maxPen) maxPen = pen;
      if (pen > 0.06 && s.y !== prevY) { squeeze++; break; }   // a vertical move made the body band overlap a wall in a too-narrow gap
      if (pen > 0.06 || !(s.y >= -3) || !Number.isFinite(s.x + s.y + s.z)) { bad++; break; }
    }
  }
  ok(bad === 0, `400 random walkers x 1500 steps: walked into a wall=${bad}, maxPenetration=${maxPen.toFixed(3)} (${total} steps; ${lostN} walked off the map edge; ${squeeze} wedged by a vertical move in a gap narrower than the body)`);
}

// ---- 3. robustness + speed ----
{
  const R = rng(99); let nan = 0; const b = col.bounds; const N = 1000000; const o = { x: 0, z: 0, hit: false };
  const t = process.hrtime.bigint();
  for (let i = 0; i < N; i++) {
    const x = b.minx - 5 + R() * (b.maxx - b.minx + 10), z = b.minz - 5 + R() * (b.maxz - b.minz + 10), y = -5 + R() * 12;
    const f = col.floorY(x, z, y, 0.5), c = col.ceilY(x, z, y, y + 2), p = col.penetration(x, y, z);
    col.moveXZ(x, y, z, x + (R() - 0.5) * 0.3, z + (R() - 0.5) * 0.3, o);
    if (Number.isNaN(f) || Number.isNaN(c) || Number.isNaN(p) || Number.isNaN(o.x) || Number.isNaN(o.z)) nan++;
  }
  const ms = Number(process.hrtime.bigint() - t) / 1e6;
  ok(nan === 0, `1,000,000 random queries (floorY+ceilY+penetration+moveXZ): NaN=${nan}`);
  console.log(`   avg per query set (4 queries) ${(ms / N * 1000).toFixed(2)} us`);
  const s = sim(-1, 0, 5); const t2 = process.hrtime.bigint(); const M = 200000;
  for (let i = 0; i < M; i++) col.step(s, 1 / 60, Math.cos(i * 0.01), Math.sin(i * 0.01), i % 100 === 0);
  const per = Number(process.hrtime.bigint() - t2) / 1e6 / M;
  ok(per < 0.1, `step() avg ${(per * 1000).toFixed(1)} us (< 100 us)`);
  const v = { x: 0, y: 0, z: 0, corrected: false }, st = { x: -1, y: 0, z: 5, gy: 0, air: 0 }; const t3 = process.hrtime.bigint();
  for (let i = 0; i < M; i++) { st.x = -1; st.z = 5; col.validatePose(st, -1 + Math.cos(i) * 0.4, 0, 5 + Math.sin(i) * 0.4, 0.05, v); }
  const per3 = Number(process.hrtime.bigint() - t3) / 1e6 / M;
  ok(per3 < 0.1, `validatePose() avg ${(per3 * 1000).toFixed(1)} us (< 100 us)`);
}

// ---- 4. server validation: legit clients are never corrected, cheaters are ----
{
  // legit: client moves with step() at 60fps (dt jittered), sends a pose every 50 ms; server validates each claim
  const R = rng(5); const b = col.bounds; let msgs = 0, corrected = 0, big = 0, maxDev = 0, maxYDev = 0;
  for (let w = 0; w < 300; w++) {
    let s = null;
    for (let k = 0; k < 200 && !s; k++) {
      const x = b.minx + R() * (b.maxx - b.minx), z = b.minz + R() * (b.maxz - b.minz);
      const f = col.floorY(x, z, 1.5, 0.5);
      if (f > -Infinity && !col.isSolid(x, f, z)) s = sim(x, f, z);
    }
    if (!s) continue;
    settle(s);
    const st = { x: s.x, y: s.y, z: s.z, gy: s.y, air: 0 }; const out = {};
    let ang = R() * 6.283, acc = 0, tsend = 0;
    for (let i = 0; i < 2400; i++) {
      if (i % 30 === 0) ang += (R() - 0.5) * 3;
      const dt = Math.min(0.05, (1 / 60) * (0.7 + R() * 0.9)); // jittery frame times
      col.step(s, dt, Math.cos(ang), Math.sin(ang), R() < 0.015);
      if (s.lost) break; // fell off the map: server respawns, not a movement-validation case
      tsend += dt;
      if (tsend >= 0.05) {
        const W = Collision.wirePrecision(); const rx = Math.round(s.x * W) / W, ry = Math.round(s.y * W) / W, rz = Math.round(s.z * W) / W; // wire rounding (same as the client)
        // server also applies its max-distance limit first: SPEED*1.5*dt+1
        col.validatePose(st, rx, ry, rz, tsend + (R() - 0.5) * 0.01, out);
        msgs++;
        const dev = Math.hypot(out.x - rx, out.z - rz), dy = Math.abs(out.y - ry);
        if (dev > maxDev) maxDev = dev; if (dy > maxYDev) maxYDev = dy;
        if (Math.hypot(out.x - rx, out.z - rz) > 0.3) big++;
        if (out.corrected) { corrected++; if (corrected <= 5) console.log('   corrected:', JSON.stringify({ claim: [rx, ry, rz], got: [out.x, out.y, out.z], prev: [st.x, st.y, st.z] })); }
        st.x = out.x; st.y = out.y; st.z = out.z; tsend = 0;
      }
    }
  }
  ok(big / msgs < 0.0001 && corrected / msgs < 0.001, `legit walkers: ${msgs} poses, corrected(>5cm)=${corrected}, corrected(>30cm)=${big}, max xz deviation ${maxDev.toFixed(3)} m, max y deviation ${maxYDev.toFixed(3)} m`);
}
{
  // cheaters
  const out = {};
  const probe = (name, st, cx, cy, cz, dt, expectFn) => { col.validatePose(st, cx, cy, cz, dt, out); ok(expectFn(out), `${name} -> (${out.x.toFixed(2)},${out.y.toFixed(2)},${out.z.toFixed(2)}) corrected=${out.corrected}`); };
  // standing in the open next to the east outer wall of long A: claim x far inside/through the wall
  const edge = settle(sim(22, 0.1, 20));
  const st = { x: edge.x, y: edge.y, z: edge.z, gy: edge.y, air: 0 };
  // find a wall by walking east until blocked, then try to claim through it
  const w = sim(-1, 0, 5); settle(w); walk(w, -1, 0, 4); w.x = w.x; // west wall of mid; claims go further west
  const wall = { x: w.x, y: w.y, z: w.z, gy: w.y, air: 0 };
  probe('cheater claims 1.2 m through the wall', wall, w.x - 1.2, w.y, w.z, 0.05, (o) => o.x >= w.x - 0.06 && o.corrected);
  probe('cheater claims 0.9 m through the wall', wall, w.x - 0.9, w.y, w.z, 0.05, (o) => o.x >= w.x - 0.06 && o.corrected);
  // teleport 20 m
  const open = { x: -1, y: 0, z: 5, gy: 0, air: 0 };
  // (server clamps distance before validatePose; emulate the 1.0+SPEED*1.5*dt clamp here)
  const maxD = 9 * 1.5 * 0.05 + 1; probe('teleport clamp keeps it near', open, -1 + maxD, 0, 5, 0.05, (o) => Math.hypot(o.x + 1, o.z - 5) <= maxD + 1e-6);
  // flying: claim y=4 above open floor
  probe('fly up 4 m in one message', open, -1, 4, 5, 0.05, (o) => o.y <= 1.05 && o.corrected);
  const fl = { x: -1, y: 0, z: 5, gy: 0, air: 0 };
  let y = 0; for (let i = 0; i < 40; i++) { col.validatePose(fl, -1, fl.y + 0.35, 5, 0.05, out); fl.x = out.x; fl.y = out.y; fl.z = out.z; y = out.y; }
  ok(y < 2.2, `slow climbing hack (0.35 m per message) is capped at y=${y.toFixed(2)}`);
  let hy = 0; const hv = { x: -1, y: 1.3, z: 5, gy: 0, air: 0 };
  for (let i = 0; i < 60; i++) { col.validatePose(hv, -1, 1.3, 5, 0.05, out); hv.x = out.x; hv.y = out.y; hv.z = out.z; hy = out.y; }
  ok(hy < 0.9, `hovering at 1.3 m for 3 s falls back toward the floor (y=${hy.toFixed(2)})`);
  // below the floor
  probe('claim y below the floor', open, -1, -2, 5, 0.05, (o) => near(o.y, 0, 0.05));
  probe('claim y way below the world', open, -1, -50, 5, 0.05, (o) => o.y >= -3 && Number.isFinite(o.y));
  // tunnel stacked floor: standing on 0.43 can't claim the 2.56 floor
  const tun = { x: -18, y: 0.43, z: -3, gy: 0.43, air: 0 };
  probe('tunnel: claim upper floor from lower', tun, -18, 2.56, -3, 0.05, (o) => o.y < 1.5);
}

// ---- 5. falling off the map edge -> lost flag on both the client mover and the server validator ----
{
  const R = rng(31); const b = col.bounds; let found = null;
  for (let w = 0; w < 2000 && !found; w++) {
    let s = null;
    for (let k = 0; k < 200 && !s; k++) {
      const x = b.minx + R() * (b.maxx - b.minx), z = b.minz + R() * (b.maxz - b.minz);
      const f = col.floorY(x, z, 1.5, 0.5);
      if (f > -Infinity && !col.isSolid(x, f, z)) s = sim(x, f, z);
    }
    if (!s) continue;
    let ang = R() * 6.283; const poses = [];
    for (let i = 0; i < 1500 && !found; i++) {
      if (i % 40 === 0) ang += (R() - 0.5) * 2.5;
      col.step(s, 1 / 60, Math.cos(ang), Math.sin(ang), false);
      if (i % 3 === 0) poses.push({ x: +s.x.toFixed(2), y: +s.y.toFixed(2), z: +s.z.toFixed(2) }); // a pose every 50 ms
      if (s.lost) { poses.push({ x: +s.x.toFixed(2), y: +s.y.toFixed(2), z: +s.z.toFixed(2) }); found = { poses, at: { x: s.x, y: s.y, z: s.z } }; }
    }
  }
  ok(!!found, 'found a walk that falls off the map edge (client mover sets s.lost, y = MIN_Y)');
  if (found) {
    // the server follows the walk pose by pose; it must flag the fall
    const st = { x: found.poses[0].x, y: found.poses[0].y, z: found.poses[0].z, gy: found.poses[0].y, air: 0 };
    const out = {}; let lostAt = -1;
    for (let i = 1; i < found.poses.length && lostAt < 0; i++) {
      col.validatePose(st, found.poses[i].x, found.poses[i].y, found.poses[i].z, 0.05, out);
      st.x = out.x; st.y = out.y; st.z = out.z;
      if (process.env.DBG) console.log(i, JSON.stringify(found.poses[i]), '->', out.x.toFixed(2), out.y.toFixed(2), out.z.toFixed(2), 'lost', out.lost);
      if (out.lost) lostAt = i;
    }
    ok(lostAt > 0 && lostAt === found.poses.length - 1, `server validatePose reports lost when the walk reaches the safety floor (pose ${lostAt} of ${found.poses.length}, at (${found.at.x.toFixed(1)},${found.at.z.toFixed(1)}))`);
    const ok2 = {}; col.validatePose({ x: -1, y: 0, z: 5, gy: 0, air: 0 }, -1, 0, 5, 0.05, ok2);
    ok(ok2.lost === false, 'standing on a floor is never reported lost');
  }
}

console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
process.exit(fails ? 1 : 0);
