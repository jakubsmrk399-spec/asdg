'use strict';
// Look inside a .glb before adding it to public/models/characters.json (no dependencies):
//   node tools/inspect-glb.js public/models/phoenix.glb
// Prints: size, embedded credit (Sketchfab files carry author/license/title), animation clips, bones (names exactly as the game sees
// them), whether the bones are recognised for the in-code pose (valve / mixamo), and a suggested entry for characters.json.
const fs = require('fs');
const file = process.argv[2];
if (!file) { console.log('usage: node tools/inspect-glb.js <file.glb>'); process.exit(1); }
const buf = fs.readFileSync(file);
if (buf.readUInt32LE(0) !== 0x46546c67) { console.log('not a .glb file (export "glTF Binary" / download the GLB version)'); process.exit(1); }
const jl = buf.readUInt32LE(12);
const j = JSON.parse(buf.slice(20, 20 + jl).toString('utf8'));
const sanitize = (n) => String(n || '').replace(/\s/g, '_').replace(/[\[\]\.:\/]/g, '');   // what three.js GLTFLoader does to node names
const nodes = j.nodes || [];
const MB = (n) => (n / 1048576).toFixed(2) + ' MB';

console.log(`file: ${file}  (${MB(buf.length)})`);
if (buf.length > 4 * 1048576) console.log('  note: big file. Downscale the textures (512 px is plenty) or download the "1k" version; it is sent to every player.');
const ex = (j.asset && j.asset.extras) || {};
if (ex.title || ex.author || ex.license) console.log(`credit: "${ex.title || '?'}" by ${ex.author || '?'}, ${ex.license || 'license unknown'}\n  source: ${ex.source || '?'}`);
console.log(`meshes: ${(j.meshes || []).length}, materials: ${(j.materials || []).length}, images: ${(j.images || []).length}, skins: ${(j.skins || []).length}`);

const clips = (j.animations || []).map((a, i) => {
  let dur = 0;
  for (const s of a.samplers || []) { const acc = j.accessors[s.input]; if (acc && acc.max) dur = Math.max(dur, acc.max[0]); }
  return { name: a.name || `clip${i}`, dur };
});
console.log(`animation clips: ${clips.length ? clips.map((c) => `${c.name} (${c.dur.toFixed(2)}s)`).join(', ') : 'none'}`);

const joints = new Set();
for (const s of j.skins || []) for (const n of s.joints) joints.add(sanitize(nodes[n].name));
const names = [...joints];
console.log(`bones: ${names.length}`);
if (names.length) console.log('  ' + names.slice(0, 60).join(', ') + (names.length > 60 ? ', ...' : ''));

const RIGS = {
  valve: (S) => ({ armUp: `^arm_upper_${S}(_\\d+)?$`, armLo: `^arm_lower_${S}(_\\d+)?$`, hand: `^hand_${S}(_\\d+)?$`, legUp: `^leg_upper_${S}(_\\d+)?$`, legLo: `^leg_lower_${S}(_\\d+)?$`, foot: `^ankle_${S}(_\\d+)?$`, toe: `^ball_${S}(_\\d+)?$` }),
  mixamo: (S, W) => ({ armUp: `^mixamorig\\d*:?${W}Arm$`, armLo: `^mixamorig\\d*:?${W}ForeArm$`, hand: `^mixamorig\\d*:?${W}Hand$`, legUp: `^mixamorig\\d*:?${W}UpLeg$`, legLo: `^mixamorig\\d*:?${W}Leg$`, foot: `^mixamorig\\d*:?${W}Foot$`, toe: `^mixamorig\\d*:?${W}ToeBase$` }),
};
let rig = null;
for (const p of Object.keys(RIGS)) {
  let all = true;
  for (const [S, W] of [['R', 'Right'], ['L', 'Left']]) for (const re of Object.values(RIGS[p](S, W))) if (!names.some((n) => new RegExp(re, 'i').test(n))) all = false;
  if (all) { rig = p; break; }
}
let kind;
if (clips.length) kind = 'clips';
else if (rig) kind = `posed in code (${rig} skeleton recognised)`;
else if (names.length) kind = 'static (skeleton not recognised: add "bones" to the entry, see public/models/README.md)';
else kind = 'static (no skeleton: it will just bob while walking)';
console.log(`\nin the game this model would be: ${kind}`);
console.log('facing: models should face +z (glTF standard); if yours faces the other way add "facing": "-z". Height and floor level are measured by the game.');

const id = require('path').basename(file, '.glb').toLowerCase().replace(/[^a-z0-9]+/g, '_');
const entry = { file: require('path').basename(file) };
if (clips.length) {
  const idle = clips.find((c) => /idle|stand|breath/i.test(c.name)), walk = clips.find((c) => /walk/i.test(c.name)) || clips.find((c) => /run|jog/i.test(c.name));
  if (idle || walk) entry.anims = { ...(idle ? { idle: idle.name } : {}), ...(walk ? { walk: walk.name } : {}) };
}
if (ex.title) entry.credit = `Model: "${ex.title}" by ${String(ex.author || '?').replace(/\s*\(.*\)/, '')} (${String(ex.license || '').replace(/\s*\(.*\)/, '')})`;
console.log('\nsuggested entry for public/models/characters.json  ("models" section):');
console.log(JSON.stringify({ [id]: entry }, null, 2));
