'use strict';
// Builds the hit shape of every character in public/models/characters.json and draws what a bullet would hit.
//   node tools/test-hitboxes.js          (front + side view, '#' = body, 'H' = head, '.' = miss)
const fs = require('fs'), path = require('path');
const HB = require('../hitboxes.js');
const dir = path.join(__dirname, '..', 'public', 'models');
const cfg = JSON.parse(fs.readFileSync(path.join(dir, 'characters.json'), 'utf8'));
let bad = 0;
const only = process.argv[2];
for (const [id, def] of Object.entries(cfg.models)) {
  if (only && only !== id) continue;
  let hb;
  try { hb = HB.build(path.join(dir, def.file), def); } catch (e) { console.log(`${id}: FAILED ${e.message}`); bad++; continue; }
  console.log(`\n=== ${id}  ${JSON.stringify(hb.info)}`);
  console.log(`bbox x ${hb.bbox[0].toFixed(2)}..${hb.bbox[1].toFixed(2)}  z ${hb.bbox[4].toFixed(2)}..${hb.bbox[5].toFixed(2)}  (1 = player height)  headAim ${hb.headAim.map((v) => v.toFixed(2))}  bodyAim ${hb.bodyAim.map((v) => v.toFixed(2))}`);
  for (const view of ['front', 'side']) {
    console.log(`-- ${view} view (shooter looks along the model's forward axis${view === 'side' ? ' from the side' : ''})`);
    const ROWS = 36, COLS = 40, span = 0.8;
    for (let r = 0; r < ROWS; r++) {
      const y = 1.02 - (r + 0.5) * (1.04 / ROWS);
      let line = '';
      for (let c = 0; c < COLS; c++) {
        const u = (c + 0.5) / COLS * 2 * span - span;
        // front: ray from the front (player forward is -z, so a shooter in front stands at z = -5 and shoots toward +z)
        const res = view === 'front' ? HB.rayModel(hb, u, y, -5, 0, 0, 1, 20) : HB.rayModel(hb, -5, y, u, 1, 0, 0, 20);
        line += res ? (res.head ? 'H' : '#') : '.';
      }
      console.log(line + '  ' + (r % 6 === 0 ? y.toFixed(2) : ''));
    }
  }
  // sanity: the point above the head and a point far to the side must miss; the body aim point must hit
  const topMiss = HB.rayModel(hb, 0, 1.05, -5, 0, 0, 1, 20);
  const aimHit = HB.rayModel(hb, hb.bodyAim[0], hb.bodyAim[1], -5, 0, 0, 1, 20);
  const headHit = HB.rayModel(hb, hb.headAim[0], hb.headAim[1], -5, 0, 0, 1, 20);
  const ok = !topMiss && aimHit && headHit && headHit.head;
  console.log(`sanity: above-head ray misses=${!topMiss}, body aim hits=${!!aimHit}, head aim is a headshot=${!!(headHit && headHit.head)}  ${ok ? 'OK' : 'CHECK'}`);
  if (!ok) bad++;
}
process.exit(bad ? 1 : 0);
