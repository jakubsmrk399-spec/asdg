'use strict';
// Reads public/maps/dust2.glb (the ONLY map source of truth), bakes the node transforms,
// recentres it on the arena origin and writes:
//   public/maps/dust2.collision.json  { verts:[x,y,z,...], tris:[a,b,c,...] }  world space, Y-up, metres
//   public/maps/dust2.meta.json       transform + bounds the client/server must agree on
// Part 5: also REMOVES the stray floating box (STRAY_BOX below) from BOTH the collision json and the glb itself
// (the glb index buffers are compacted in place, so the file layout/textures are untouched). Idempotent: running it again
// on an already cleaned glb removes nothing and writes identical output. The game offset is always computed from the
// ORIGINAL vertex bounds (orphaned box vertices stay in the glb), so the offset never changes.
// Run: node tools/build-map.js
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, '..', 'public', 'maps', 'dust2.glb');
const OUT = path.join(__dirname, '..', 'public', 'maps');
// Stray white box that floats alone in the void north of the CT block (game coords, see PROGRESS.md). Triangles of
// these glb materials that lie completely inside this box (+ TOL) are dropped.
const STRAY_BOX = { min: [-2.56, 0, -32.85], max: [-0.85, 1.71, -29.44], materials: [17, 23], tol: 0.02 };
const FLOOR_Y = 1008; // raw mesh y=0 (main floor level) lands here after the root matrix; subtracted so floor = y 0

const buf = fs.readFileSync(SRC);
const jsonLen = buf.readUInt32LE(12);
const gltf = JSON.parse(buf.slice(20, 20 + jsonLen).toString('utf8'));
const binStart = 20 + jsonLen + 8;
const bin = buf.slice(binStart);

// column-major 4x4 multiply / point transform
const mul = (a, b) => { const o = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) for (let k = 0; k < 4; k++) o[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k]; return o; };
const I4 = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
const tp = (m, x, y, z) => [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]];
function nodeMatrix(n) {
  if (n.matrix) return n.matrix;
  if (n.translation || n.rotation || n.scale) throw new Error('TRS nodes not supported by this script');
  return I4;
}
function readAccessor(i) {
  const a = gltf.accessors[i], bv = gltf.bufferViews[a.bufferView];
  const off = (bv.byteOffset || 0) + (a.byteOffset || 0);
  const comps = { SCALAR: 1, VEC2: 2, VEC3: 3 }[a.type];
  const stride = bv.byteStride || comps * ({ 5126: 4, 5123: 2, 5125: 4 }[a.componentType]);
  const out = [];
  for (let k = 0; k < a.count; k++) for (let c = 0; c < comps; c++) {
    const p = off + k * stride + c * ({ 5126: 4, 5123: 2, 5125: 4 }[a.componentType]);
    out.push(a.componentType === 5126 ? bin.readFloatLE(p) : a.componentType === 5123 ? bin.readUInt16LE(p) : bin.readUInt32LE(p));
  }
  return out;
}

const verts = [], tris = [], triPrim = []; // triPrim[t] = index into prims for triangle t
const prims = []; // { prim, material, indexAccessor }
(function walk(ni, parent) {
  const n = gltf.nodes[ni];
  const m = mul(parent, nodeMatrix(n));
  if (n.mesh !== undefined) for (const prim of gltf.meshes[n.mesh].primitives) {
    if (prim.mode !== undefined && prim.mode !== 4) continue;
    const pos = readAccessor(prim.attributes.POSITION), idx = readAccessor(prim.indices);
    const base = verts.length / 3;
    for (let k = 0; k < pos.length; k += 3) verts.push(...tp(m, pos[k], pos[k + 1], pos[k + 2]));
    for (const i of idx) tris.push(base + i);
    prims.push({ prim, material: prim.material, indexAccessor: prim.indices, first: tris.length / 3 - idx.length / 3, count: idx.length / 3 });
  }
  (n.children || []).forEach((c) => walk(c, m));
})(gltf.scenes[gltf.scene || 0].nodes[0], I4);

let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
for (let k = 0; k < verts.length; k += 3) for (let a = 0; a < 3; a++) { mn[a] = Math.min(mn[a], verts[k + a]); mx[a] = Math.max(mx[a], verts[k + a]); }
const cx = (mn[0] + mx[0]) / 2, cz = (mn[2] + mx[2]) / 2;
const offset = [-cx, -FLOOR_Y, -cz]; // add this to the glb's baked world position to get game coordinates
for (let k = 0; k < verts.length; k += 3) for (let a = 0; a < 3; a++) verts[k + a] = Math.round((verts[k + a] + offset[a]) * 1000) / 1000;
mn = mn.map((v, a) => Math.round((v + offset[a]) * 1000) / 1000);
mx = mx.map((v, a) => Math.round((v + offset[a]) * 1000) / 1000);

// ---- remove the stray box (decided per triangle, in game coordinates) ----
const inBox = (t) => {
  for (let c = 0; c < 3; c++) for (let a = 0; a < 3; a++) {
    const v = verts[tris[t * 3 + c] * 3 + a];
    if (v < STRAY_BOX.min[a] - STRAY_BOX.tol || v > STRAY_BOX.max[a] + STRAY_BOX.tol) return false;
  }
  return true;
};
const drop = new Uint8Array(tris.length / 3);
let dropped = 0;
for (const p of prims) if (STRAY_BOX.materials.includes(p.material)) for (let t = p.first; t < p.first + p.count; t++) if (inBox(t)) { drop[t] = 1; dropped++; }
console.log('stray box triangles dropped:', dropped, '(expected 26 on the first run, 0 on later runs)');

// collision json: kept triangles + only the vertices they use (offset/bounds above were computed from ALL vertices)
const remap = new Map(), cverts = [], ctris = [];
for (let t = 0; t < tris.length / 3; t++) {
  if (drop[t]) continue;
  for (let c = 0; c < 3; c++) {
    const vi = tris[t * 3 + c];
    if (!remap.has(vi)) { remap.set(vi, cverts.length / 3); cverts.push(verts[vi * 3], verts[vi * 3 + 1], verts[vi * 3 + 2]); }
    ctris.push(remap.get(vi));
  }
}
fs.writeFileSync(path.join(OUT, 'dust2.collision.json'), JSON.stringify({ verts: cverts, tris: ctris }));

// glb: compact the index buffer of every primitive that lost triangles (in place, same bin size), rewrite the JSON chunk
if (dropped) {
  const binOut = Buffer.from(bin); // copy
  for (const p of prims) {
    let any = false;
    for (let t = p.first; t < p.first + p.count; t++) if (drop[t]) { any = true; break; }
    if (!any) continue;
    const a = gltf.accessors[p.indexAccessor], bv = gltf.bufferViews[a.bufferView];
    const size = a.componentType === 5123 ? 2 : 4;
    const off = (bv.byteOffset || 0) + (a.byteOffset || 0);
    const read = (k) => (size === 2 ? binOut.readUInt16LE(off + k * 2) : binOut.readUInt32LE(off + k * 4));
    const write = (k, v) => (size === 2 ? binOut.writeUInt16LE(v, off + k * 2) : binOut.writeUInt32LE(v, off + k * 4));
    let w = 0, mi = Infinity, ma = -Infinity;
    for (let t = 0; t < p.count; t++) {
      if (drop[p.first + t]) continue;
      for (let c = 0; c < 3; c++) { const v = read(t * 3 + c); write(w++, v); mi = Math.min(mi, v); ma = Math.max(ma, v); }
    }
    for (let k = w; k < a.count; k++) write(k, 0);
    a.count = w;
    if (a.min) a.min = [mi]; if (a.max) a.max = [ma];
  }
  let js = Buffer.from(JSON.stringify(gltf), 'utf8');
  js = Buffer.concat([js, Buffer.alloc((4 - (js.length % 4)) % 4, 0x20)]);
  const head = Buffer.alloc(12); buf.copy(head, 0, 0, 12);
  const jh = Buffer.alloc(8); jh.writeUInt32LE(js.length, 0); jh.writeUInt32LE(0x4e4f534a, 4);
  const bh = Buffer.alloc(8); bh.writeUInt32LE(binOut.length, 0); bh.writeUInt32LE(0x004e4942, 4);
  const out = Buffer.concat([head, jh, js, bh, binOut]);
  out.writeUInt32LE(out.length, 8);
  fs.writeFileSync(SRC, out);
}
fs.writeFileSync(path.join(OUT, 'dust2.meta.json'), JSON.stringify({
  name: 'de_dust2', glb: 'dust2.glb', collision: 'dust2.collision.json',
  units: 'metres, Y-up, 1 unit = 1 game unit',
  // To place the glb in the game: after three.js loads it (its root node already has the 0.01333 scale/flip matrix),
  // set gltf.scene.position.set(offset[0], offset[1], offset[2]). Collision json already has the offset baked in.
  offset, bounds: { min: mn, max: mx }, triangles: ctris.length / 3,
  glbBytes: fs.statSync(SRC).size, // lets the client draw a real progress bar even when the transfer is compressed
  credit: 'This work is based on "de_dust2 - CS map" (https://sketchfab.com/3d-models/de-dust2-cs-map-056008d59eb849a29c0ab6884c0c3d87) by vrchris (https://sketchfab.com/vrchris) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)',
}, null, 2));
console.log('tris', ctris.length / 3, 'bounds', mn, mx, 'offset', offset);
