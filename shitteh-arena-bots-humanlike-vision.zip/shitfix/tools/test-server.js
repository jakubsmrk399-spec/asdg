'use strict';
// Real server + ws bots.   NODE_PATH=<dir with ws> node tools/test-server.js
// Legit bots walk with the shared mover exactly like the client does (60 fps frames, a pose every 50 ms) and must
// never be corrected by the server. A cheater bot walks through a wall, teleports, flies: the server must pull it back.
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const WebSocket = require('ws');
const Collision = require('../public/shared/collision.js');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));

const PORT = 28000 + Math.floor(Math.random() * 1000);
const srv = spawn('node', [path.join(__dirname, '../server.js')], { env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', ADMIN_PASSWORD: 'x' }, stdio: ['ignore', 'pipe', 'pipe'] });
let srvLog = '';
srv.stdout.on('data', (d) => { srvLog += d; });
srv.stderr.on('data', (d) => { srvLog += d; });

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// a bot: tracks server's view of itself from 's' broadcasts
function makeBot(name, port = PORT) {
  const bot = { name, id: 0, seq: 0, s: { x: 0, y: 0, z: 0, vy: 0, ground: false }, srv: null, rs: 0, welcome: null, worldMap: null, ready: false, err: [] };
  bot.ws = new WebSocket('ws://127.0.0.1:' + port);
  bot.ws.on('open', () => bot.ws.send(JSON.stringify({ t: 'join', name })));
  bot.ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.t === 'welcome') {
      bot.id = m.id; bot.seq = m.you.seq; bot.welcome = m; bot.worldMap = m.world.map;
      Object.assign(bot.s, { x: m.you.x, y: m.you.y, z: m.you.z, vy: 0, ground: false });
      bot.ready = true;
    } else if (m.t === 'rs') {
      bot.rs++; bot.seq = m.seq; Object.assign(bot.s, { x: m.x, y: m.y, z: m.z, vy: 0, ground: false, lost: false }); bot.lastRs = m;
    } else if (m.t === 's') {
      const me = m.p.find((q) => q[0] === bot.id); if (me) { bot.srv = { x: me[1], y: me[2], z: me[3] }; bot.srvNew = true; }
    }
  });
  bot.ws.on('error', (e) => bot.err.push(e.message));
  bot.send = (extra) => bot.ws.send(JSON.stringify({ t: 'm', x: +bot.s.x.toFixed(2), y: +bot.s.y.toFixed(2), z: +bot.s.z.toFixed(2), yaw: 0, pitch: 0, seq: bot.seq, ...extra }));
  return bot;
}

async function legit(seed, seconds) {
  const R = rng(seed), bot = makeBot('legit' + seed);
  while (!bot.ready) await sleep(10);
  await sleep(200);
  let ang = R() * 6.283, maxDev = 0, samples = 0, devSum = 0, lastSend = Date.now(), last = Date.now();
  const sent = []; let mismatches = 0, checks = 0, seenRs = 0, skipUntil = 0;
  const end = Date.now() + seconds * 1000;
  let frames = 0;
  while (Date.now() < end) {
    await sleep(16);
    const now = Date.now(); const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (bot.rs !== seenRs) { seenRs = bot.rs; sent.length = 0; skipUntil = now + 1000; bot.srvNew = false; } // fell off the map edge -> server respawned us: skip the checks for 1 s
    if (frames++ % 25 === 0) ang += (R() - 0.5) * 3;
    col.step(bot.s, dt, Math.cos(ang), Math.sin(ang), R() < 0.01);
    if (now - lastSend >= 50) { lastSend = now; bot.send(); sent.push({ x: +bot.s.x.toFixed(2), y: +bot.s.y.toFixed(2), z: +bot.s.z.toFixed(2) }); if (sent.length > 12) sent.shift(); }
    if (bot.srv && bot.srvNew && sent.length > 1 && now > skipUntil) {
      bot.srvNew = false; checks++;
      // every server position must equal one of the poses we recently sent (= the server accepted it unchanged)
      if (!sent.some((q) => Math.abs(q.x - bot.srv.x) < 0.02 && Math.abs(q.z - bot.srv.z) < 0.02 && Math.abs(q.y - bot.srv.y) < 0.02)) { mismatches++; if (mismatches <= 3) console.log('   mismatch: server', JSON.stringify(bot.srv), 'last sent', JSON.stringify(sent[sent.length - 1]), 'prev', JSON.stringify(sent[sent.length - 2])); }
    }
    if (bot.srv && frames % 10 === 0 && now > skipUntil) {
      const dev = Math.hypot(bot.srv.x - bot.s.x, bot.srv.z - bot.s.z) + Math.abs(bot.srv.y - bot.s.y) * 0;
      // the broadcast is up to ~100 ms old: allow for the distance walked in that time (0.9 m)
      if (dev > maxDev) maxDev = dev; devSum += dev; samples++;
    }
  }
  bot.ws.close();
  return { maxDev, avg: devSum / Math.max(1, samples), rs: bot.rs, samples, mismatches, checks };
}

async function main() {
  for (let i = 0; i < 50 && !/listening/.test(srvLog); i++) await sleep(100);
  console.log(srvLog.trim().split('\n').slice(0, 3).join('\n'));
  ok(/de_dust2 mesh loaded/.test(srvLog), 'server loaded the collision mesh');

  // ---- welcome / spawn ----
  const a = makeBot('spawn');
  while (!a.ready) await sleep(10);
  const w = a.welcome;
  ok(w.world.map === 'dust2' && !('boxes' in w.world) && w.world.sites.length === 2, `welcome: world.map=${w.world.map}, you=(${w.you.x},${w.you.y},${w.you.z}), no world.boxes, ${w.world.sites.length} sites`);
  ok(!col.isSolid(w.you.x, w.you.y, w.you.z) && Math.abs(col.floorY(w.you.x, w.you.z, w.you.y + 0.5, 0) - w.you.y) < 0.01, 'spawn is on a floor and not inside a wall');
  a.ws.close();

  // ---- legit bots in parallel (8 bots, 12 s each) ----
  const res = await Promise.all([1, 2, 3, 4, 5, 6, 7, 8].map((i) => legit(i * 11, 12)));
  const worst = Math.max(...res.map((r) => r.maxDev)), rsTotal = res.reduce((n, r) => n + r.rs, 0);
  console.log('   legit bots: max |server-client| xz', res.map((r) => r.maxDev.toFixed(2)).join(' '), ' respawns(off the map):', rsTotal);
  // compare: server position is the broadcast (<=50ms old + 50 ms send interval): at 9 m/s that is up to ~1 m of lag by itself
  const mis = res.reduce((n, r) => n + r.mismatches, 0), chk = res.reduce((n, r) => n + r.checks, 0);
  ok(worst < 1.6, `8 legit bots: server position tracks the client (worst gap ${worst.toFixed(2)} m, includes ~1 m network/broadcast lag)`);
  ok(mis / chk < 0.01, `legit bots are not corrected: ${mis} of ${chk} server position broadcasts did not equal a pose the bot had sent`);

  // ---- cheater: walk to a wall, then claim positions through it ----
  const c = makeBot('cheater');
  while (!c.ready) await sleep(10);
  // put the cheater in mid by a legit walk from spawn is slow; instead use a legal respawn position and walk toward a wall
  await sleep(200);
  const wallDir = [-1, 0];
  let tNow = Date.now(), ls = Date.now();
  // walk west from the spawn until blocked by a wall (shared mover)
  for (let i = 0; i < 400; i++) {
    await sleep(16); const n = Date.now(); const dt = Math.min(0.05, (n - tNow) / 1000); tNow = n;
    col.step(c.s, dt, wallDir[0], wallDir[1], false);
    if (n - ls >= 50) { ls = n; c.send(); }
  }
  await sleep(300);
  const blockedAt = { x: c.s.x, z: c.s.z, y: c.s.y };
  console.log('   cheater walked west and stopped at', blockedAt.x.toFixed(2), blockedAt.z.toFixed(2), 'server sees', c.srv && c.srv.x, c.srv && c.srv.z);
  // now cheat: keep claiming further west, 0.5 m per message (well under the speed limit), for 2 seconds
  let cx = c.s.x;
  for (let i = 0; i < 40; i++) { cx -= 0.5; c.ws.send(JSON.stringify({ t: 'm', x: +cx.toFixed(2), y: +c.s.y.toFixed(2), z: +c.s.z.toFixed(2), yaw: 0, pitch: 0, seq: c.seq })); await sleep(50); }
  await sleep(300);
  const throughWall = c.srv && c.srv.x < blockedAt.x - 0.3;
  ok(c.srv && !throughWall, `cheater walking through the wall is held at the wall (server x=${c.srv && c.srv.x}, wall contact x=${blockedAt.x.toFixed(2)}, claimed x=${cx.toFixed(1)})`);
  // teleport 15 m
  const before = { ...c.srv };
  c.ws.send(JSON.stringify({ t: 'm', x: +(before.x + 15).toFixed(2), y: before.y, z: before.z, yaw: 0, pitch: 0, seq: c.seq }));
  await sleep(150);
  ok(c.srv && Math.hypot(c.srv.x - before.x, c.srv.z - before.z) < 4.5, `teleport of 15 m is limited (max SPEED*1.5*0.25+1 = 4.4 m after an idle gap) to ${(c.srv ? Math.hypot(c.srv.x - before.x, c.srv.z - before.z) : -1).toFixed(2)} m`);
  // fly
  for (let i = 0; i < 20; i++) { c.ws.send(JSON.stringify({ t: 'm', x: c.srv.x, y: 6, z: c.srv.z, yaw: 0, pitch: 0, seq: c.seq })); await sleep(50); }
  await sleep(200);
  ok(c.srv.y < c.s.y + 2.2, `flying cheat limited: server y=${c.srv.y} (floor ${c.s.y.toFixed(2)})`);
  // fall off the map: claim y at the safety floor over a hole -> server respawns the player
  c.ws.close();
  // (walking off the map edge -> respawn is covered at module level in test-collision.js; no walk from the T spawn area
  //  reaches an edge, and the server's distance limit stops a bot from teleporting to one)

  // ---- the old 'mm' message is gone: sending it must change nothing ----
  {
    const m = makeBot('mm');
    while (!m.ready) await sleep(10);
    await sleep(200);
    const rs0 = m.rs;
    m.ws.send(JSON.stringify({ t: 'mm', old: 1 }));
    await sleep(400);
    ok(m.rs === rs0 && m.worldMap === 'dust2', "legacy 'mm' message is ignored (no respawn, still the real map)");
    m.ws.close();
  }

  // ---- failure path: a server whose de_dust2 data is missing runs the flat fallback arena ----
  {
    const root = path.join(__dirname, '..');
    const dir = path.join(require('os').tmpdir(), 'shitteh-srvflat-' + process.pid);
    fs.mkdirSync(path.join(dir, 'public', 'shared'), { recursive: true });
    for (const f of ['server.js', 'map.js']) fs.copyFileSync(path.join(root, f), path.join(dir, f));
    fs.copyFileSync(path.join(root, 'public', 'shared', 'collision.js'), path.join(dir, 'public', 'shared', 'collision.js'));
    const FP = PORT + 1000;
    const fsrv = spawn('node', [path.join(dir, 'server.js')], { env: { ...process.env, PORT: String(FP), HOST: '127.0.0.1', ADMIN_PASSWORD: 'x' }, stdio: ['ignore', 'pipe', 'pipe'] });
    let flog = ''; fsrv.stdout.on('data', (d) => { flog += d; }); fsrv.stderr.on('data', (d) => { flog += d; });
    for (let i = 0; i < 50 && !/listening/.test(flog); i++) await sleep(100);
    ok(/ERROR: could not load the de_dust2 collision mesh/.test(flog) && /FLAT FALLBACK/.test(flog), 'missing collision json: loud ERROR in the server log + flat fallback');
    const a1 = makeBot('f1', FP), a2 = makeBot('f2', FP);
    while (!a1.ready || !a2.ready) await sleep(10);
    ok(a1.worldMap === 'flat' && a1.welcome.world.boxes === undefined && a1.welcome.you.y === 0 && a2.welcome.you.y === 0, `flat server: world.map=${a1.worldMap}, spawn y=${a1.welcome.you.y}, no boxes`);
    // a shot across the open flat floor still works; a shot at the floor ends at y=0; a shot to the edge ends at the outer wall
    const p1 = a1.welcome.you, p2 = a2.welcome.you;
    // (the two spawn points are different; aim a1 at a2 using the server's own positions)
    await sleep(200);
    const tr = [];
    a1.ws.on('message', (raw) => { const m = JSON.parse(raw); if (m.t === 'tr') tr.push(m); });
    const dx = p2.x - p1.x, dz = p2.z - p1.z, dy = (0.85) - 1.6, L = Math.hypot(dx, dy, dz);
    let got = 0; a2.ws.on('message', (raw) => { const m = JSON.parse(raw); if (m.t === 'dmg') got++; });
    a1.ws.send(JSON.stringify({ t: 'f', x: p1.x, y: 0, z: p1.z, yaw: Math.atan2(-dx, -dz), pitch: Math.asin(dy / L), seq: a1.seq }));
    await sleep(200);
    ok(got === 1, 'flat server: hitscan across the open floor hits');
    await sleep(200);
    a1.ws.send(JSON.stringify({ t: 'f', x: p1.x, y: 0, z: p1.z, yaw: 0, pitch: -1.0, seq: a1.seq }));
    await sleep(200);
    const t1 = tr[tr.length - 1];
    ok(t1 && Math.abs(t1.e[1]) < 0.05, `flat server: a shot into the ground ends at y=0 (end y ${t1 && t1.e[1]})`);
    await sleep(200);
    const sx = p2.x < p1.x ? 1 : -1;   // shoot toward the side where the other bot is NOT standing
    a1.ws.send(JSON.stringify({ t: 'f', x: p1.x, y: 0, z: p1.z, yaw: sx > 0 ? -Math.PI / 2 : Math.PI / 2, pitch: 0, seq: a1.seq }));
    await sleep(200);
    const t2 = tr[tr.length - 1];
    ok(t2 && Math.abs(t2.e[0] - sx * 40) < 0.1, `flat server: a level shot ends at the outer wall x=${sx * 40} (end x ${t2 && t2.e[0]})`);
    a1.ws.close(); a2.ws.close();
    fsrv.kill();
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
  }

  await sleep(200);
  ok(!/Error|TypeError|ReferenceError/.test(srvLog.replace(/rate limit/g, '')), 'no server errors in the log');
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  srv.kill();
  process.exit(fails ? 1 : 0);
}
main().catch((e) => { console.error(e); srv.kill(); process.exit(1); });
