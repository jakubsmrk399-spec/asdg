'use strict';
// Stuck rescue (Part 5): {t:'stuck'} -> server respawn with hp kept, 10 s cooldown, refused after damage / while moving / dead.
//   NODE_PATH=<dir with ws> node tools/test-stuck.js        (server runs in-process, bots over real websockets)
const path = require('path');
const fs = require('fs');
const PORT = 29000 + Math.floor(Math.random() * 900);
process.env.PORT = String(PORT); process.env.HOST = '127.0.0.1'; process.env.ADMIN_PASSWORD = 'x';
const WebSocket = require('ws');
const Collision = require('../public/shared/collision.js');
const col = Collision.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const { players } = require('../server.js');

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('FAIL', msg); } else console.log('ok  ', msg); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function connect(name) {
  const b = { name, id: 0, seq: 0, rs: [], no: [], dmg: [], ready: false, pose: null, timer: null };
  b.ws = new WebSocket('ws://127.0.0.1:' + PORT);
  b.ws.on('open', () => b.ws.send(JSON.stringify({ t: 'join', name })));
  b.ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.t === 'welcome') { b.id = m.id; b.seq = m.you.seq; b.pose = { x: m.you.x, y: m.you.y, z: m.you.z }; b.ready = true; }
    else if (m.t === 'rs') { b.rs.push(m); b.seq = m.seq; b.pose = { x: m.x, y: m.y, z: m.z }; }
    else if (m.t === 'stuckno') b.no.push(m);
    else if (m.t === 'dmg') b.dmg.push(m);
  });
  // legit client: keeps sending its (unchanging or drifting) pose at 20 Hz
  b.drift = 0;
  b.timer = setInterval(() => {
    if (!b.ready || b.ws.readyState !== 1) return;
    b.pose.x += b.drift;
    b.ws.send(JSON.stringify({ t: 'm', x: b.pose.x, y: b.pose.y, z: b.pose.z, yaw: 0, pitch: 0, seq: b.seq }));
  }, 50);
  return b;
}
const P = (b) => players.get(b.id);
const stuck = async (b) => { b.ws.send(JSON.stringify({ t: 'stuck' })); await sleep(150); };

(async () => {
  await sleep(300);
  const a = connect('stuckA'), c = connect('shooter');
  for (let i = 0; i < 300 && !(a.ready && c.ready); i++) await sleep(10);
  ok(a.ready && c.ready, 'two bots joined');

  // 1. just spawned: the server has not seen the player stand still for 1.5 s -> refused 'moving'
  await stuck(a);
  ok(a.no.length === 1 && a.no[0].why === 'moving' && a.rs.length === 0, `a stuck request right after the spawn is refused (${a.no.map((n) => n.why)})`);

  // 2. wedged for 1.7 s (same pose over and over), hp 60, damaged long ago -> rescued, hp kept
  P(a).hp = 60; P(a).lastDamaged = 0;
  await sleep(1700);
  const before = { x: P(a).x, z: P(a).z };
  await stuck(a);
  ok(a.rs.length === 1, 'wedged for 1.7 s: server sends rs (respawn)');
  const rs = a.rs[0];
  ok(rs && rs.hp === 60 && P(a).hp === 60, `hp is kept by the rescue (rs.hp ${rs && rs.hp}, server ${P(a).hp})`);
  ok(rs && col.floorY(rs.x, rs.z, 3, 0) !== -Infinity && !col.isSolid(rs.x, rs.y, rs.z) && Math.abs(col.floorY(rs.x, rs.z, 3, 0) - rs.y) < 0.05, `rescue point (${rs.x}, ${rs.y}, ${rs.z}) is on a floor, not in a wall`);
  ok(Math.hypot(rs.x - before.x, rs.z - before.z) > 0.5, 'rescue moved the player to another spawn');

  // 3. cooldown: wedged again, 10 s not over -> refused
  await sleep(1700);
  await stuck(a);
  ok(a.rs.length === 1 && a.no.length === 2 && a.no[1].why === 'cooldown', `second request within 10 s is refused (${a.no.map((n) => n.why)})`);

  // 4. cooldown over but damaged 2 s ago -> refused; damaged 6 s ago -> accepted
  P(a).lastStuck = Date.now() - 11000; P(a).lastDamaged = Date.now() - 2000;
  await stuck(a);
  ok(a.rs.length === 1 && a.no[a.no.length - 1].why === 'damaged', `damaged 2 s ago: refused (${a.no[a.no.length - 1].why})`);
  P(a).lastDamaged = Date.now() - 6000;
  await stuck(a);
  ok(a.rs.length === 2, 'damaged 6 s ago (cooldown over): accepted');

  // 5. a REAL hit sets the damage timer: shooter hits a (open T plateau, 6 m apart), then a asks -> 'damaged'
  P(a).lastStuck = 0;
  Object.assign(P(a), { x: -16.5, y: 1.71, z: 24, gy: 1.71, air: 0, dead: false, hp: 100, lastMove: Date.now() });
  a.pose = { x: -16.5, y: 1.71, z: 24 };
  Object.assign(P(c), { x: -16.5, y: 1.71, z: 18, gy: 1.71, air: 0, dead: false, hp: 100, lastMove: Date.now(), lastFire: 0 });
  c.pose = { x: -16.5, y: 1.71, z: 18 };
  const eye = [-16.5, 1.71 + 1.6, 18], tgt = [-16.5, 1.71 + 0.85, 24];
  const d = [tgt[0] - eye[0], tgt[1] - eye[1], tgt[2] - eye[2]];
  c.ws.send(JSON.stringify({ t: 'f', x: -16.5, y: 1.71, z: 18, yaw: Math.atan2(-d[0], -d[2]), pitch: Math.asin(d[1] / Math.hypot(...d)), seq: c.seq }));
  await sleep(200);
  ok(a.dmg.length >= 1, 'bot a was really hit (dmg message)');
  const rsN = a.rs.length;
  await sleep(1700);
  await stuck(a);
  ok(a.rs.length === rsN && a.no[a.no.length - 1].why === 'damaged', `after a real hit the rescue is refused (${a.no[a.no.length - 1].why})`);

  // 6. dead players cannot use it
  P(a).lastStuck = 0; P(a).lastDamaged = 0; P(a).dead = true;
  await stuck(a);
  ok(a.rs.length === rsN && a.no[a.no.length - 1].why === 'dead', 'dead player: refused');
  P(a).dead = false;

  // 7. moving player (drifting pose) is refused as 'moving', garbage / spam does not crash
  a.drift = 0.05; P(a).lastStuck = 0; P(a).lastDamaged = 0;
  Object.assign(P(a), { x: -16.5, z: 24, y: 1.71 }); a.pose = { x: -16.5, y: 1.71, z: 24 };
  await sleep(600);
  await stuck(a);
  ok(a.no[a.no.length - 1].why === 'moving' && a.rs.length === rsN, 'player whose position keeps changing: refused (moving)');
  a.drift = 0;
  a.ws.send(JSON.stringify({ t: 'stuck', extra: { deep: [1, 2, 3] }, why: 'x'.repeat(100) })); await sleep(100);
  ok(players.has(a.id) && a.ws.readyState === 1, 'extra fields in the stuck message are ignored, connection fine');

  clearInterval(a.timer); clearInterval(c.timer);
  a.ws.close(); c.ws.close();
  await sleep(200);
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASSED');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
