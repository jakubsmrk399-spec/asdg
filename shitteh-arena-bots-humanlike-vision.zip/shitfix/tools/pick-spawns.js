'use strict';
// Generator for the spawn list in map.js (run it again if the collision mesh changes):   node tools/pick-spawns.js
// Flood fills (walk + jump, real client mover) from the T plateau, keeps reachable standing spots with clearance around
// them, then picks N_T spots in the T area and N_CT spots in the CT area by farthest-point sampling.
// Prints the lines to paste into map.js. The server re-verifies every spot at startup anyway.
const path = require('path'), fs = require('fs');
const C = require('../public/shared/collision.js');
const col = C.create(JSON.parse(fs.readFileSync(path.join(__dirname, '../public/maps/dust2.collision.json'), 'utf8')));
const N_T = 10, N_CT = 10, MIN_GAP = 1.6;
const key = (x, y, z) => Math.round(x / 0.5) + ',' + Math.round(z / 0.5) + ',' + Math.round(y / 0.25);
const start = { x: -17, y: col.floorY(-17, 26, 3, 0), z: 26 };
const seen = new Map([[key(start.x, start.y, start.z), start]]);
const queue = [start];
const dirs = []; for (let i = 0; i < 8; i++) dirs.push([Math.cos(i * Math.PI / 4), Math.sin(i * Math.PI / 4)]);
while (queue.length) {
  const q = queue.pop();
  for (const [dx, dz] of dirs) for (const jump of [false, true]) {
    const s = { x: q.x, y: q.y, z: q.z, vy: 0, ground: true, lost: false };
    const n = jump ? 12 : 4;
    for (let i = 0; i < n; i++) { col.step(s, 0.06, dx, dz, jump && i === 0); if (s.lost) break; }
    if (s.lost) continue;
    if (!s.ground) { for (let i = 0; i < 20 && !s.ground; i++) col.step(s, 0.05, dx, dz, false); if (!s.ground || s.lost) continue; }
    if (col.isSolid(s.x, s.y, s.z)) continue;
    const k = key(s.x, s.y, s.z);
    if (!seen.has(k)) { const r = { x: s.x, y: s.y, z: s.z }; seen.set(k, r); queue.push(r); }
  }
}
console.log('reachable states:', seen.size);
// a spot is good when it is on a real floor, in the open (a ring of free body positions around it) and has sky/ceiling >= 3 m
function good(x, z) {
  const y = col.floorY(x, z, 3, 0);
  if (y === -Infinity || col.isSolid(x, y, z)) return null;
  for (let i = 0; i < 12; i++) {
    const a = i * Math.PI / 6, px = x + Math.cos(a) * 0.9, pz = z + Math.sin(a) * 0.9;
    const fy = col.floorY(px, pz, y + 0.5, 0.5);
    if (fy === -Infinity || Math.abs(fy - y) > 0.3 || col.isSolid(px, fy, pz)) return null;
  }
  if (col.ceilY(x, z, y + 1.9, y + 4) < Infinity) return null;
  return y;
}
function pick(name, x0, x1, z0, z1, n, yRange) {
  const cand = [];
  for (const p of seen.values()) {
    if (p.x < x0 || p.x > x1 || p.z < z0 || p.z > z1) continue;
    const x = Math.round(p.x * 2) / 2, z = Math.round(p.z * 2) / 2;
    const y = good(x, z);
    if (y === null) continue;
    if (yRange && (y < yRange[0] || y > yRange[1])) continue;
    cand.push([x, z, y]);
  }
  const uniq = [...new Map(cand.map((c) => [c[0] + ',' + c[1], c])).values()];
  const chosen = [];
  if (!uniq.length) { console.log(name, 'no candidates'); return chosen; }
  let cx = 0, cz = 0; for (const c of uniq) { cx += c[0]; cz += c[1]; } cx /= uniq.length; cz /= uniq.length;
  uniq.sort((a, b) => Math.hypot(a[0] - cx, a[1] - cz) - Math.hypot(b[0] - cx, b[1] - cz));
  chosen.push(uniq[0]);
  while (chosen.length < n) {
    let best = null, bd = -1;
    for (const c of uniq) {
      const d = Math.min(...chosen.map((s) => Math.hypot(s[0] - c[0], s[1] - c[1])));
      if (d > bd) { bd = d; best = c; }
    }
    if (!best || bd < MIN_GAP) break;
    chosen.push(best);
  }
  console.log(`${name}: ${uniq.length} candidates, picked ${chosen.length}`);
  return chosen;
}
const T = pick('T', -26, -6, 10, 28, N_T, [1.5, 1.9]);
const CT = pick('CT', -8, 2, -20, -8, N_CT, [-1.8, -1.5]);
const fmt = (a) => '[' + a.map(([x, z]) => `[${x}, ${z}]`).join(', ') + ']';
console.log('\nT_SPAWNS  = ' + fmt(T));
console.log('CT_SPAWNS = ' + fmt(CT));
console.log('y values T :', T.map((s) => s[2].toFixed(2)).join(' '));
console.log('y values CT:', CT.map((s) => s[2].toFixed(2)).join(' '));
